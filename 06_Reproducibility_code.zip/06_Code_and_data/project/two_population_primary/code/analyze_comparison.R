# Additional exploratory analysis; original manuscript/data remain unchanged.
# Rscript analyze_comparison.R INPUT OUTPUT [CORES]
suppressPackageStartupMessages({library(survey);library(splines);library(jsonlite)})
args <- commandArgs(TRUE); infile<-args[1]; out<-args[2]
cores<-if(length(args)>2) as.integer(args[3]) else 6L
dir.create(out,recursive=TRUE,showWarnings=FALSE)
options(survey.lonely.psu='fail')
csv<-function(x,f) write.csv(x,file.path(out,f),row.names=FALSE,na='')
d<-read.csv(infile,stringsAsFactors=FALSE)
stopifnot(!anyDuplicated(d$SEQN),sum(d$eligible)==4034,sum(d$anemia[d$eligible==1])==553)
d$ch<-factor(ifelse(d$MCQ220==1,'cancer',ifelse(d$MCQ220==2,'no_cancer',NA)),levels=c('no_cancer','cancer'))
d$fi<-factor(d$FSDHH,levels=1:4)
d$cycle<-factor(d$cycle);d$race<-relevel(factor(d$race,levels=1:5),'3')
d$education<-factor(d$education,levels=1:3);d$smoking<-factor(d$smoking,levels=0:2)
d$extension_eligible<-with(d,RIDAGEYR>=20 & known_pregnant==0 & RIDSTATR==2 & weight>0 & !is.na(ch)&!is.na(fi)&!is.na(anemia))
d$extension_eligible[is.na(d$extension_eligible)]<-FALSE
v<-c('anemia','fi','ch','cycle','age10','female','race','education','pir','smoking')
d$cc2<-complete.cases(d[,v]);d$cc3<-complete.cases(d[,c(v,'bmi','log_creatinine','diabetes')])
d$age_band<-cut(d$RIDAGEYR,c(20,40,60,80,Inf),right=FALSE,labels=c('20-39','40-59','60-79','80+'))
mec<-subset(d,RIDSTATR==2 & weight>0 & !is.na(strata_id)&!is.na(psu_id))
des<-svydesign(ids=~psu_id,strata=~strata_id,weights=~weight,nest=TRUE,data=mec)
psus<-aggregate(psu_id~strata_id,mec,function(x) length(unique(x)))
stopifnot(all(psus$psu_id>=2))
desc<-subset(des,extension_eligible); a<-subset(des,extension_eligible & cc2)
ca<-subset(a,ch=='cancer');stopifnot(nrow(ca$variables)==3755,sum(ca$variables$anemia)==510)
counts<-list();prev<-list();support<-list()
for(pop in c('descriptive','M2_complete')){
 ad<-if(pop=='descriptive') desc else a
 for(g in levels(d$ch))for(k in levels(d$fi)){
  z<-ad[ad$variables$ch==g & ad$variables$fi==k,]
  counts[[paste(pop,g,k)]]<-data.frame(population=pop,cancer_history=g,fi=k,n=nrow(z$variables),anemia=sum(z$variables$anemia),nonanemia=sum(z$variables$anemia==0))
  est<-svyciprop(~anemia,z,method='logit',df=degf(z));ci<-confint(est)
  prev[[paste(pop,g,k)]]<-data.frame(population=pop,cancer_history=g,fi=k,n=nrow(z$variables),events=sum(z$variables$anemia),estimate=coef(est)[1],low=ci[1],high=ci[2],design_df=degf(z))
 }
}
csv(do.call(rbind,counts),'group_counts.csv');csv(do.call(rbind,prev),'crude_prevalence.csv')
for(g in levels(d$ch))for(k in levels(d$fi))for(band in levels(d$age_band))for(sex in 0:1){
 take<-with(a$variables,ch==g & fi==k & age_band==band & female==sex)
 take[is.na(take)]<-FALSE
 support[[paste(g,k,band,sex)]]<-data.frame(ch=g,fi=k,age_band=band,female=sex,n=sum(take),weighted_total=sum(weights(a)[take]))
}
csv(do.call(rbind,support),'common_support_counts.csv')
unknown<-subset(d,RIDAGEYR>=20 & known_pregnant==0 & RIDSTATR==2 & weight>0 & !is.na(fi)&!is.na(anemia)&!MCQ220%in%c(1,2))
flow<-data.frame(stage=c('All interviewed','Full MEC','Adult core eligible with explicit cancer history','M2 complete','Cancer descriptive','Cancer M2','Noncancer descriptive','Noncancer M2','Unknown cancer history excluded at core eligibility'),n=c(nrow(d),nrow(mec),nrow(desc$variables),nrow(a$variables),sum(desc$variables$ch=='cancer'),sum(a$variables$ch=='cancer'),sum(desc$variables$ch=='no_cancer'),sum(a$variables$ch=='no_cancer'),nrow(unknown)))
csv(flow,'flow.csv')
oldform<-anemia~fi+cycle+age10+female+race+education+pir+smoking
anchor<-svyglm(oldform,design=ca,family=quasibinomial())
stopifnot(max(abs(exp(coef(anchor)[paste0('fi',2:4)])-c(2.005519566,2.316594,4.088169)))<.005)
form<-anemia~ch*(fi+cycle+ns(age10,knots=c(4,6),Boundary.knots=c(2,8))+female+race+education+ns(pir,knots=c(1,3),Boundary.knots=c(0,5))+smoking)
fit<-svyglm(form,design=a,family=quasibinomial())
stopifnot(fit$converged,fit$rank==length(coef(fit)),fit$df.residual>0,all(is.finite(coef(fit))))
it<-regTermTest(fit,~ch:fi,method='Wald')
csv(data.frame(model='Flexible fully interacted covariates',F=as.numeric(it$Ftest),numerator_df=it$df,denominator_df=it$ddf,p=it$p),'interaction.csv')
cc<-summary(fit)$coefficients
csv(data.frame(term=rownames(cc),beta=cc[,1],se=cc[,2],stat=cc[,3],p=cc[,4]),'all_coefficients.csv')
crit<-qt(.975,fit$df.residual);mm<-function(z)model.matrix(delete.response(terms(fit)),z,contrasts.arg=fit$contrasts,xlev=fit$xlevels)
ors<-list()
for(g in levels(d$ch)) for(k in 2:4){
 z<-a$variables[1:2,];z$ch<-factor(rep(g,2),levels=levels(d$ch));z$fi<-factor(c(k,1),levels=levels(d$fi))
 # identical covariates, changing only food security within cancer history
 for(n in setdiff(names(z),c('fi','ch')))z[[n]][2]<-z[[n]][1]
 L<-mm(z)[1,]-mm(z)[2,];beta<-sum(L*coef(fit));se<-sqrt(drop(L%*%vcov(fit)%*%L))
 ors[[paste(g,k)]]<-data.frame(ch=g,fi=k,OR=exp(beta),low=exp(beta-crit*se),high=exp(beta+crit*se),p=2*pt(abs(beta/se),fit$df.residual,lower.tail=FALSE),beta=beta,se=se)
}
csv(do.call(rbind,ors),'conditional_OR.csv')
# Observed marginal group share: denominator = anemic survivors in FI2/3/4.
burden<-subset(desc,ch=='cancer' & anemia==1 & fi!='1')
burden<-update(burden,marginal=as.numeric(fi=='2'))
bs<-svyciprop(~marginal,burden,method='logit',df=degf(burden));bci<-confint(bs)
csv(data.frame(denominator='Anemic cancer survivors with FI2/3/4',n=nrow(burden$variables),marginal_n=sum(burden$variables$marginal),weighted_share=coef(bs)[1],low=bci[1],high=bci[2]),'marginal_burden_share.csv')

cat('POINT_MODELS_COMPLETE; preparing JKn replicates\n');flush.console()
# Generate replicate weights BEFORE domain restriction, preserving the full design.
rep_full<-as.svrepdesign(des,type='JKn',mse=TRUE)
rep_a<-subset(rep_full,extension_eligible & cc2)
stopifnot(identical(rep_a$variables$SEQN,a$variables$SEQN))
W<-weights(rep_a,type='analysis'); w0<-weights(a);X<-model.matrix(fit);y<-a$variables$anemia
target<-which(a$variables$ch=='cancer'); Tdata<-a$variables[target,]
grid<-expand.grid(fi=levels(d$fi),ch=levels(d$ch),stringsAsFactors=FALSE)
grid$key<-paste(grid$ch,grid$fi,sep='_'); TX<-lapply(seq_len(nrow(grid)),function(j){
 z<-Tdata;z$ch<-factor(rep(grid$ch[j],nrow(z)),levels=levels(d$ch));z$fi<-factor(rep(grid$fi[j],nrow(z)),levels=levels(d$fi));mm(z)
})
names(TX)<-grid$key
theta_from_beta<-function(beta,w){
 tw<-w[target];stopifnot(sum(tw)>0)
 p<-vapply(TX,function(mx)sum(plogis(drop(mx%*%beta))*tw)/sum(tw),numeric(1))
 pd<-c(p[2:4]-p[1],p[6:8]-p[5]);names(pd)<-paste0('pd_',c(grid$key[2:4],grid$key[6:8]))
 cd<-p[5:8]-p[1:4];names(cd)<-paste0('cancer_minus_control_',1:4)
 did<-cd[2:4]-cd[1];names(did)<-paste0('did_',2:4)
 c(setNames(p,paste0('p_',names(p))),setNames(qlogis(p),paste0('logit_',names(p))),pd,cd,did)
}
t0<-theta_from_beta(coef(fit),w0)
rep_job<-function(j){
 w<-W[,j];warn<-character()
 f<-withCallingHandlers(glm.fit(X,y,weights=w/mean(w),family=quasibinomial(),start=coef(fit),control=glm.control(maxit=40,epsilon=1e-9)),warning=function(e){warn<<-c(warn,conditionMessage(e));invokeRestart('muffleWarning')})
 if(!isTRUE(f$converged)||f$rank!=ncol(X)||any(!is.finite(f$coefficients)))stop(paste('Replicate failed',j))
 list(theta=theta_from_beta(f$coefficients,w),iterations=f$iter,rank=f$rank,warnings=paste(unique(warn),collapse=' | '))
}
cat('JKN_REPLICATES',ncol(W),'CORES',cores,'N',nrow(X),'P',ncol(X),'\n');flush.console()
rr<-parallel::mclapply(seq_len(ncol(W)),rep_job,mc.cores=cores,mc.preschedule=TRUE)
if(any(vapply(rr,inherits,logical(1),'try-error')))stop('At least one replicate failed; no replicate dropped')
R<-do.call(rbind,lapply(rr,'[[','theta'))
V<-svrVar(R,scale=rep_a$scale,rscales=rep_a$rscales,mse=TRUE,coef=t0)
se<-sqrt(diag(V));names(se)<-names(t0)
alltheta<-data.frame(term=names(t0),estimate=as.numeric(t0),se=as.numeric(se),low=as.numeric(t0-crit*se),high=as.numeric(t0+crit*se))
csv(alltheta,'standardized_all_contrasts.csv')
pred<-do.call(rbind,lapply(seq_len(nrow(grid)),function(j){
 key<-grid$key[j];idx<-paste0('logit_',key)
 data.frame(ch=grid$ch[j],fi=grid$fi[j],estimate=t0[paste0('p_',key)],low=plogis(t0[idx]-crit*se[idx]),high=plogis(t0[idx]+crit*se[idx]),se=se[paste0('p_',key)],target_n=length(target),target='Cancer-survivor M2 covariate distribution',ci_method='JKn refit plus target reweighting; logit CI')
}))
csv(pred,'standardized_prevalence.csv')
csv(alltheta[grepl('^(pd_|cancer_minus_control_|did_)',alltheta$term),],'standardized_differences.csv')
csv(data.frame(replicate=seq_along(rr),iterations=vapply(rr,'[[',numeric(1),'iterations'),rank=vapply(rr,'[[',numeric(1),'rank'),warnings=vapply(rr,'[[',character(1),'warnings')),'replicate_diagnostics.csv')
saveRDS(list(model=fit,anchor=anchor,theta=t0,replicate_estimates=R,covariance=V,replicate_scale=rep_a$scale,replicate_rscales=rep_a$rscales,grid=grid),file.path(out,'models_and_replicates.rds'))
meta<-list(status='executed',date='2026-10-18',formula=paste(deparse(form),collapse=' '),input=infile,n=nrow(a$variables),events=sum(y),cancer_n=length(target),cancer_events=sum(y[target]),noncancer_n=sum(a$variables$ch=='no_cancer'),design_df=degf(a),residual_df=fit$df.residual,rank=fit$rank,converged=fit$converged,full_MEC_strata=nrow(psus),full_MEC_PSUs=sum(psus$psu_id),replicates=ncol(W),all_replicates_finite=all(is.finite(R)),max_replicate_iterations=max(vapply(rr,'[[',numeric(1),'iterations')),target='Survey weighted empirical cancer-survivor M2 complete-case distribution; noncancer estimates are standardized comparators, not noncancer actual population prevalence',CI='JKn on fullMEC before domains; model refit and target reweighted in eachreplicate; tcrit residual design df, logit bounds for prevalence',unknown_history_excluded=nrow(unknown),global_interaction_p=it$p,original_linear_M2_OR=as.list(exp(coef(anchor)[paste0('fi',2:4)])),age_spline=list(knots=c(40,60),bounds=c(20,80),unit='years, divided by10 for age10 implementation'),pir_spline=list(knots=c(1,3),bounds=c(0,5)),exploratory=TRUE,new_cycle_run=FALSE)
write_json(meta,file.path(out,'comparison_summary.json'),pretty=TRUE,auto_unbox=TRUE,digits=12)
sink(file.path(out,'R_sessionInfo.txt'));sessionInfo();sink()
cat('COMPARISON_COMPLETE\n');print(meta);print(pred);print(alltheta[grepl('^(pd_|did_)',alltheta$term),])
