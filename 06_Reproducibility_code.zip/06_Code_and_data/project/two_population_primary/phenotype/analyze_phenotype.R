# Focused, exploratory MCV phenotype extension. Run on existing cleaned NHANES data.
# Rscript analyze_phenotype.R INPUT_CSV OUTPUT_DIR
suppressPackageStartupMessages(library(survey))
suppressPackageStartupMessages(library(jsonlite))
args <- commandArgs(trailingOnly=TRUE)
stopifnot(length(args)==2)
infile <- args[[1]]; out <- args[[2]]
dir.create(out, recursive=TRUE, showWarnings=FALSE)
options(survey.lonely.psu='fail')
d <- read.csv(infile, stringsAsFactors=FALSE)
required <- c('SEQN','RIDAGEYR','RIDSTATR','weight','cycle','strata_id','psu_id','cancer',
 'known_pregnant','food_insecure','anemia','age10','female','race','education','pir','smoking','FSDHH','LBXMCVSI','LBXHGB')
stopifnot(all(required %in% names(d)), !anyDuplicated(d$SEQN))
d$cycle <- factor(d$cycle)
d$race <- relevel(factor(d$race,levels=1:5),ref='3')
d$education <- factor(d$education,levels=1:3)
d$smoking <- factor(d$smoking,levels=0:2)
d$food_security_category <- factor(d$FSDHH,levels=1:4)
d$eligible <- as.integer(d$RIDAGEYR>=20 & d$cancer==1 & d$known_pregnant==0 &
 d$RIDSTATR==2 & d$weight>0 & !is.na(d$food_insecure) & !is.na(d$anemia))
d$eligible[is.na(d$eligible)] <- 0
v2 <- c('anemia','food_insecure','cycle','age10','female','race','education','pir','smoking')
d$complete2 <- as.integer(complete.cases(d[,v2]))
# Morphology is classified only after applying the original study anemia definition.
# The Merck/clinical source is used for MCV cutoffs only, not its Hb diagnostic thresholds.
d$microcytic <- as.integer(d$anemia==1 & d$LBXMCVSI<80)
d$normocytic <- as.integer(d$anemia==1 & d$LBXMCVSI>=80 & d$LBXMCVSI<=100)
d$macrocytic <- as.integer(d$anemia==1 & d$LBXMCVSI>100)
d$phenotype <- ifelse(d$anemia==0,'No anemia',ifelse(is.na(d$LBXMCVSI),NA,
 ifelse(d$LBXMCVSI<80,'Microcytic',ifelse(d$LBXMCVSI>100,'Macrocytic','Normocytic'))))
d$normo_comparison <- as.integer(d$phenotype %in% c('No anemia','Normocytic'))
stopifnot(all(!is.na(d$LBXMCVSI[d$eligible==1])),
 all(d$microcytic[d$eligible==1]+d$normocytic[d$eligible==1]+d$macrocytic[d$eligible==1]==d$anemia[d$eligible==1]))
mec <- subset(d,RIDSTATR==2 & weight>0 & !is.na(strata_id) & !is.na(psu_id))
des <- svydesign(ids=~psu_id,strata=~strata_id,weights=~weight,nest=TRUE,data=mec)
a <- subset(des,eligible==1)
a2 <- subset(des,eligible==1 & complete2==1)
stopifnot(nrow(a$variables)==4034,sum(a$variables$anemia)==553,
 nrow(a2$variables)==3755,sum(a2$variables$anemia)==510)
labels <- c('Fully food secure','Marginally food secure','Low food security','Very low food security')
ct <- do.call(rbind,lapply(list(Descriptive=a,M2_complete_case=a2),function(ad) {
 population <- if(nrow(ad$variables)==4034) 'Descriptive' else 'M2_complete_case'
 do.call(rbind,lapply(0:4,function(k) {
  g <- if(k==0) ad else subset(ad,FSDHH==k)
  v <- g$variables
  data.frame(population=population,category_code=k,category=if(k==0) 'All' else labels[k],
   n=nrow(v),no_anemia=sum(v$anemia==0),anemia=sum(v$anemia==1),
   microcytic=sum(v$microcytic),normocytic=sum(v$normocytic),macrocytic=sum(v$macrocytic),
   missing_MCV=sum(is.na(v$LBXMCVSI)),design_df=degf(g))
 }))
}))
write.csv(ct,file.path(out,'phenotype_counts.csv'),row.names=FALSE)
# All proportions are observed survey-weighted estimates with design-based logit 95% CIs.
# Descriptive precision flags are pragmatic warnings, not an official NCHS suppression decision.
prop_table <- function(ad,population,anemic_only=FALSE) {
 if(anemic_only) ad <- subset(ad,anemia==1)
 do.call(rbind,lapply(0:4,function(k) {
  g <- if(k==0) ad else subset(ad,FSDHH==k)
  do.call(rbind,lapply(c('microcytic','normocytic','macrocytic'),function(y) {
   f <- as.formula(paste0('~',y)); events <- sum(g$variables[[y]])
   if(events>0 && events<nrow(g$variables)) {
    pr <- svyciprop(f,g,method='logit',df=degf(g)); ci <- as.numeric(confint(pr))
    p <- as.numeric(coef(pr)); se <- as.numeric(SE(pr))
   } else {p <- events/nrow(g$variables);se <- NA_real_;ci <- c(NA_real_,NA_real_)}
   flags <- character()
   if(events<10) flags <- c(flags,'fewer_than_10_events')
   if(is.finite(se) && p>0 && se/p>.30) flags <- c(flags,'RSE_above_30_percent')
   if(degf(g)<8) flags <- c(flags,'design_df_below_8')
   if(nrow(g$variables)<30) flags <- c(flags,'denominator_below_30')
   if(length(flags)==0) flags <- 'none'
   data.frame(population=population,denominator=if(anemic_only) 'Anemic cancer survivors' else 'All eligible cancer survivors',
    category_code=k,category=if(k==0) 'All' else labels[k],phenotype=y,
    unweighted_denominator=nrow(g$variables),unweighted_events=events,
    weighted_proportion=p,CI_low=ci[1],CI_high=ci[2],SE=se,RSE=se/p,
    design_df=degf(g),precision_flags=paste(flags,collapse=';'))
  }))
 }))
}
prev <- rbind(prop_table(a,'Descriptive'),prop_table(a2,'M2_complete_case'))
comp <- rbind(prop_table(a,'Descriptive',TRUE),prop_table(a2,'M2_complete_case',TRUE))
write.csv(prev,file.path(out,'phenotype_prevalence_all_survivors.csv'),row.names=FALSE)
write.csv(comp,file.path(out,'phenotype_composition_among_anemic.csv'),row.names=FALSE)
# Only the common normocytic subtype is modeled. Other anemia subtypes are excluded,
# not incorrectly reclassified as controls; controls are all nonanemic survivors.
model_des <- subset(des,eligible==1 & complete2==1 & normo_comparison==1)
model_counts <- do.call(rbind,lapply(1:4,function(k) {
 g <- subset(model_des,FSDHH==k)
 data.frame(category_code=k,category=labels[k],n=nrow(g$variables),
  events=sum(g$variables$normocytic),non_events=sum(g$variables$normocytic==0),design_df=degf(g))
}))
stopifnot(nrow(model_des$variables)==3654,sum(model_des$variables$normocytic)==409,
 all(model_counts$events>=20),all(model_counts$non_events>0))
form <- normocytic ~ food_security_category + cycle + age10 + female + race + education + pir + smoking
fit <- svyglm(form,design=model_des,family=quasibinomial())
stopifnot(fit$converged,fit$rank==length(coef(fit)),all(is.finite(coef(fit))),
 all(is.finite(sqrt(diag(vcov(fit))))),fit$df.residual>0)
global <- regTermTest(fit,~food_security_category,method='Wald')
model <- model_counts
model$OR <- 1;model$CI_low <- NA_real_;model$CI_high <- NA_real_;model$p <- NA_real_
model$is_reference <- model$category_code==1
critical <- qt(.975,fit$df.residual)
for(k in 2:4) {
 term <- paste0('food_security_category',k);b <- unname(coef(fit)[term]);se <- unname(sqrt(diag(vcov(fit)))[term])
 i <- which(model$category_code==k);model$OR[i] <- exp(b)
 model$CI_low[i] <- exp(b-critical*se);model$CI_high[i] <- exp(b+critical*se)
 model$p[i] <- 2*pt(abs(b/se),fit$df.residual,lower.tail=FALSE)
}
write.csv(model,file.path(out,'normocytic_vs_no_anemia_M2.csv'),row.names=FALSE)
cc <- summary(fit)$coefficients
write.csv(data.frame(term=rownames(cc),cc,row.names=NULL,check.names=FALSE),
 file.path(out,'normocytic_M2_all_coefficients.csv'),row.names=FALSE)
summary <- list(status='executed',execution_date_user_timezone='2026-10-18',analysis='Exploratory MCV phenotype extension',
 source=infile,source_md5=unname(tools::md5sum(infile)),
 definition=list(anemia='Unchanged original study anemia variable; Hb <13 g/dL in men and <12 g/dL in women',
 microcytic='Anemia and MCV <80 fL',normocytic='Anemia and MCV >=80 and <=100 fL',
 macrocytic='Anemia and MCV >100 fL',not_etiologic='MCV morphology is not a diagnosis of iron deficiency, inflammation, or vitamin deficiency'),
 descriptive_n=4034,anemia_n=553,MCV_missing=0,subtype_counts=c(microcytic=75,normocytic=448,macrocytic=30),
 focused_model=list(outcome='Normocytic anemia',controls='No anemia',other_anemia_excluded=101,
 n=nrow(model_des$variables),events=sum(model_des$variables$normocytic),
 formula=paste(deparse(form),collapse=' '),model_rows=model,
 design_df=degf(model_des),residual_df=fit$df.residual,parameters=length(coef(fit)),converged=fit$converged,
 global_p=as.numeric(global$p),global_F=as.numeric(global$Ftest),
 global_df=as.numeric(global$df),global_denominator_df=as.numeric(global$ddf)),
 interpretation=list('Subtype prevalence denominator includes all eligible survivors.',
 'Subtype composition denominator includes only survivors with anemia.',
 'Observed weighted proportions are not covariate-standardized.',
 'No microcytic or macrocytic regression was fitted because the category event counts were sparse.',
 'Only one morphology association model was run; this is a post-primary exploratory extension.',
 'Continuous-Hb analyses from the existing manuscript remain unchanged; not rerun here.',
 'No patient-level data were exported from the server.'),
 precision_flags='Pragmatic descriptive warnings: fewer than 10 events, RSE >30%, denominator <30, or design df <8; not official NCHS suppression rules.',
 versions=list(R=R.version.string,survey=as.character(packageVersion('survey'))))
write_json(summary,file.path(out,'phenotype_summary.json'),pretty=TRUE,auto_unbox=TRUE,na='null',digits=12)
saveRDS(fit,file.path(out,'normocytic_M2_model.rds'))
sink(file.path(out,'R_sessionInfo.txt'));sessionInfo();sink()
print(ct);print(subset(prev,population=='Descriptive'));print(model)
cat('NORMOCYTIC_GLOBAL_P',as.numeric(global$p),'\nPHENOTYPE_ANALYSIS_COMPLETE\n')
