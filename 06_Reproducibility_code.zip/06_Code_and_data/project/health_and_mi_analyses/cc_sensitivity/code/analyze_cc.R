# Same-target complete-case robustness of the cancer-history interaction.
# All participant processing is run on the shared Python server.
suppressPackageStartupMessages({library(survey);library(splines);library(jsonlite)})
args<-commandArgs(TRUE);infile<-args[1];out<-args[2];cores<-if(length(args)>2)as.integer(args[3])else 3L
dir.create(out,recursive=TRUE,showWarnings=FALSE);options(survey.lonely.psu='fail')
csv<-function(x,f)write.csv(x,file.path(out,f),row.names=FALSE,na='')
d<-read.csv(infile,stringsAsFactors=FALSE)
stopifnot(!anyDuplicated(d$SEQN),sum(d$eligible)==4034,sum(d$anemia[d$eligible==1])==553)
d$ch<-factor(ifelse(d$MCQ220==1,'cancer',ifelse(d$MCQ220==2,'no_cancer',NA)),levels=c('no_cancer','cancer'))
d$fi<-factor(d$FSDHH,levels=1:4);d$cycle<-factor(d$cycle)
d$race<-relevel(factor(d$race,levels=1:5),'3');d$education<-factor(d$education,levels=1:3);d$smoking<-factor(d$smoking,levels=0:2)
d$extension_eligible<-with(d,RIDAGEYR>=20 & known_pregnant==0 & RIDSTATR==2 & weight>0 & !is.na(ch)&!is.na(fi)&!is.na(anemia))
d$extension_eligible[is.na(d$extension_eligible)]<-FALSE
v<-c('anemia','fi','ch','cycle','age10','female','race','education','pir','smoking')
d$cc2<-complete.cases(d[,v]);d$cc3<-complete.cases(d[,c(v,'bmi','log_creatinine','diabetes')])
mec<-subset(d,RIDSTATR==2 & weight>0 & !is.na(strata_id)&!is.na(psu_id))
des<-svydesign(ids=~psu_id,strata=~strata_id,weights=~weight,nest=TRUE,data=mec)
rep_full<-as.svrepdesign(des,type='JKn',mse=TRUE)
a2<-subset(des,extension_eligible & cc2);a3<-subset(des,extension_eligible & cc3)
target_ids<-a3$variables$SEQN[a3$variables$ch=='cancer']
stopifnot(nrow(a2$variables)==38929,length(target_ids)==3587)
form2<-anemia~ch*(fi+cycle+ns(age10,knots=c(4,6),Boundary.knots=c(2,8))+female+race+education+ns(pir,knots=c(1,3),Boundary.knots=c(0,5))+smoking)
form3<-update(form2,.~.+ch*(bmi+log_creatinine+diabetes))
models<-list(M2_all=list(design=a2,rep=subset(rep_full,extension_eligible&cc2),formula=form2),M2_same=list(design=a3,rep=subset(rep_full,extension_eligible&cc3),formula=form2),M3_same=list(design=a3,rep=subset(rep_full,extension_eligible&cc3),formula=form3))
flow<-do.call(rbind,lapply(names(models),function(nm){a<-models[[nm]]$design;do.call(rbind,lapply(levels(d$ch),function(g){z<-a$variables[a$variables$ch==g,];data.frame(model=nm,ch=g,n=nrow(z),events=sum(z$anemia),target_n=length(target_ids))}))}))
csv(flow,'sample_flow.csv')
missing<-subset(d,extension_eligible)
csv(data.frame(variable=c(v,'bmi','log_creatinine','diabetes'),missing=vapply(missing[,c(v,'bmi','log_creatinine','diabetes')],function(z)sum(is.na(z)),numeric(1)),total=nrow(missing)),'covariate_missingness.csv')
results<-list();ors<-list();interactions<-list();prevalences<-list();differences<-list();allcoefs<-list();diagnostics<-list();summaries<-list()
for(nm in names(models)){
 cat('MODEL_START',nm,'\n');flush.console()
 a<-models[[nm]]$design; rep_a<-models[[nm]]$rep; fml<-models[[nm]]$formula
 fit<-svyglm(fml,design=a,family=quasibinomial())
 stopifnot(fit$converged,fit$rank==length(coef(fit)),fit$df.residual>0,all(is.finite(coef(fit))),identical(rep_a$variables$SEQN,a$variables$SEQN))
 it<-regTermTest(fit,~ch:fi,method='Wald');crit<-qt(.975,fit$df.residual)
 interactions[[nm]]<-data.frame(model=nm,F=as.numeric(it$Ftest),numerator_df=it$df,denominator_df=it$ddf,p=it$p)
 co<-summary(fit)$coefficients;allcoefs[[nm]]<-data.frame(model=nm,term=rownames(co),beta=co[,1],se=co[,2],stat=co[,3],p=co[,4])
 mm<-function(z)model.matrix(delete.response(terms(fit)),z,contrasts.arg=fit$contrasts,xlev=fit$xlevels)
 for(g in levels(d$ch))for(k in 2:4){
  z<-a$variables[rep(1,2),];z$ch<-factor(rep(g,2),levels=levels(d$ch));z$fi<-factor(c(k,1),levels=levels(d$fi))
  L<-mm(z)[1,]-mm(z)[2,];b<-sum(L*coef(fit));s<-sqrt(drop(L%*%vcov(fit)%*%L))
  ors[[paste(nm,g,k)]]<-data.frame(model=nm,ch=g,fi=k,OR=exp(b),low=exp(b-crit*s),high=exp(b+crit*s),p=2*pt(abs(b/s),fit$df.residual,lower.tail=FALSE),beta=b,se=s)
 }
 W<-weights(rep_a,type='analysis');w0<-weights(a);X<-model.matrix(fit);y<-a$variables$anemia
 target<-match(target_ids,a$variables$SEQN);stopifnot(!anyNA(target));Tdata<-a$variables[target,]
 grid<-expand.grid(fi=levels(d$fi),ch=levels(d$ch),stringsAsFactors=FALSE);grid$key<-paste(grid$ch,grid$fi,sep='_')
 TX<-lapply(seq_len(nrow(grid)),function(j){z<-Tdata;z$ch<-factor(rep(grid$ch[j],nrow(z)),levels=levels(d$ch));z$fi<-factor(rep(grid$fi[j],nrow(z)),levels=levels(d$fi));mm(z)});names(TX)<-grid$key
 theta_from_beta<-function(beta,w){
  tw<-w[target];stopifnot(sum(tw)>0)
  p<-vapply(TX,function(mx)sum(plogis(drop(mx%*%beta))*tw)/sum(tw),numeric(1))
  pd<-c(p[2:4]-p[1],p[6:8]-p[5]);names(pd)<-paste0('pd_',c(grid$key[2:4],grid$key[6:8]))
  cd<-p[5:8]-p[1:4];names(cd)<-paste0('cancer_minus_control_',1:4)
  did<-cd[2:4]-cd[1];names(did)<-paste0('did_',2:4)
  c(setNames(p,paste0('p_',names(p))),setNames(qlogis(p),paste0('logit_',names(p))),pd,cd,did)
 }
 t0<-theta_from_beta(coef(fit),w0)
 rep_job<-function(j){
  w<-W[,j];warn<-character()
  r<-withCallingHandlers(glm.fit(X,y,weights=w/mean(w),family=quasibinomial(),start=coef(fit),control=glm.control(maxit=40,epsilon=1e-9)),warning=function(e){warn<<-c(warn,conditionMessage(e));invokeRestart('muffleWarning')})
  if(!isTRUE(r$converged)||r$rank!=ncol(X)||any(!is.finite(r$coefficients)))stop(paste(nm,'replicate failed',j))
  list(theta=theta_from_beta(r$coefficients,w),iterations=r$iter,rank=r$rank,warnings=paste(unique(warn),collapse=' | '))
 }
 cat('REPLICATES_START',nm,ncol(W),nrow(X),ncol(X),'\n');flush.console()
 rr<-parallel::mclapply(seq_len(ncol(W)),rep_job,mc.cores=cores,mc.preschedule=TRUE)
 if(any(vapply(rr,inherits,logical(1),'try-error')))stop(paste(nm,'replicate failed; none discarded'))
 R<-do.call(rbind,lapply(rr,'[[','theta'));V<-svrVar(R,scale=rep_a$scale,rscales=rep_a$rscales,mse=TRUE,coef=t0);se<-sqrt(diag(V));names(se)<-names(t0)
 theta<-data.frame(model=nm,term=names(t0),estimate=as.numeric(t0),se=as.numeric(se),low=as.numeric(t0-crit*se),high=as.numeric(t0+crit*se))
 differences[[nm]]<-theta[grepl('^(pd_|cancer_minus_control_|did_)',theta$term),]
 prevalences[[nm]]<-do.call(rbind,lapply(seq_len(nrow(grid)),function(j){key<-grid$key[j];idx<-paste0('logit_',key);data.frame(model=nm,ch=grid$ch[j],fi=grid$fi[j],estimate=t0[paste0('p_',key)],low=plogis(t0[idx]-crit*se[idx]),high=plogis(t0[idx]+crit*se[idx]),se=se[paste0('p_',key)],target_n=length(target),target='Fixed same M3-complete cancer-survivor empirical covariate distribution')}))
 diagnostics[[nm]]<-data.frame(model=nm,replicate=seq_along(rr),iterations=vapply(rr,'[[',numeric(1),'iterations'),rank=vapply(rr,'[[',numeric(1),'rank'),warnings=vapply(rr,'[[',character(1),'warnings'))
 summaries[[nm]]<-list(n=nrow(a$variables),events=sum(y),cancer_n=sum(a$variables$ch=='cancer'),cancer_events=sum(y[a$variables$ch=='cancer']),target_n=length(target),formula=paste(deparse(fml),collapse=' '),rank=fit$rank,design_df=degf(a),residual_df=fit$df.residual,converged=fit$converged,replicates=ncol(W),all_replicates_finite=all(is.finite(R)),interaction_p=it$p)
 saveRDS(list(fit=fit,theta=t0,replicates=R,covariance=V,grid=grid,target_ids=target_ids),file.path(out,paste0(nm,'_model_remote_only.rds')))
 csv(theta,paste0(nm,'_all_contrasts.csv'))
 cat('MODEL_COMPLETE',nm,'\n');flush.console()
}
csv(do.call(rbind,ors),'conditional_OR.csv');csv(do.call(rbind,interactions),'interaction.csv');csv(do.call(rbind,prevalences),'standardized_prevalence.csv');csv(do.call(rbind,differences),'standardized_differences.csv');csv(do.call(rbind,allcoefs),'all_coefficients.csv');csv(do.call(rbind,diagnostics),'replicate_diagnostics.csv')
meta<-list(status='executed',date='2026-10-18',input=infile,models=summaries,target='Same survey weighted M3-complete cancer-survivor covariate distribution across all three models',uncertainty='Full MEC JKn generated before domain subset; refit and target-reweight in every replicate; logit CIs for prevalence; t critical values at model residual design df',interpretation='M2_all versus M2_same isolates the complete-case restriction at a common target. M2_same versus M3_same changes health covariate adjustment with fixed sample and target. Neither comparison estimates causal effects.',manuscript_changed=FALSE)
write_json(meta,file.path(out,'summary.json'),pretty=TRUE,auto_unbox=TRUE,digits=12)
sink(file.path(out,'sessionInfo.txt'));sessionInfo();sink();cat('ALL_CC_COMPLETE\n')
