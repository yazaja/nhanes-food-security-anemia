suppressPackageStartupMessages({library(survey);library(mice);library(splines);library(jsonlite)})
options(survey.lonely.psu='fail',survey.adjust.domain.lonely=FALSE)
prepare_data <- function(infile) {
 d<-read.csv(infile,stringsAsFactors=FALSE);stopifnot(!anyDuplicated(d$SEQN))
 d$ch<-factor(ifelse(d$MCQ220==1,'cancer',ifelse(d$MCQ220==2,'no_cancer',NA)),levels=c('no_cancer','cancer'))
 d$fi<-factor(d$FSDHH,levels=1:4);d$cycle<-factor(d$cycle)
 d$race<-relevel(factor(d$race,levels=1:5),'3');d$education<-factor(d$education,levels=1:3);d$smoking<-factor(d$smoking,levels=0:2)
 d$extension_eligible<-with(d,RIDAGEYR>=20&known_pregnant==0&RIDSTATR==2&weight>0&!is.na(ch)&!is.na(fi)&!is.na(anemia));d$extension_eligible[is.na(d$extension_eligible)]<-FALSE
 mec<-subset(d,RIDSTATR==2&weight>0&!is.na(strata_id)&!is.na(psu_id)); ix<-which(mec$extension_eligible);a<-mec[ix,]
 stopifnot(sum(a$ch=='cancer')==4034,sum(a$anemia[a$ch=='cancer'])==553,nrow(a)==41972)
 list(mec=mec,ix=ix,a=a)
}
missing_vars<-c('education','pir','smoking','bmi','log_creatinine','diabetes')
ns_pir<-function(x)ns(x,knots=c(1,3),Boundary.knots=c(0,5))
make_spec <- function(a) {
 x<-a[,c('anemia','fi','female','race',missing_vars,'LBXHGB')]
 x$diabetes<-factor(x$diabetes,levels=0:1)
 agebasis<-ns(a$age10,knots=c(4,6),Boundary.knots=c(2,8)); for(j in 1:3)x[[paste0('age_ns',j)]]<-agebasis[,j]
 for(j in 1:3){x[[paste0('pir_ns',j)]]<-NA_real_;obs<-!is.na(a$pir);x[[paste0('pir_ns',j)]][obs]<-ns_pir(a$pir[obs])[,j]}
 for(k in 2:4)x[[paste0('anemia_fi',k)]]<-as.numeric(x$anemia==1&x$fi==as.character(k))
 x$log_weight<-log(a$weight);x$stratum<-droplevels(factor(a$strata_id))
 method<-make.method(x);method[]<-'';method[c('pir','bmi','log_creatinine')]<-'pmm';method[c('education','smoking')]<-'polyreg';method['diabetes']<-'logreg'
 for(j in 1:3)method[paste0('pir_ns',j)]<-paste0('~I(as.numeric(splines::ns(pir,knots=c(1,3),Boundary.knots=c(0,5))[,',j,']))')
 pred<-make.predictorMatrix(x);pred[!rownames(pred)%in%missing_vars,]<-0
 # Raw PIR is imputed once. Its deterministic descendants never predict PIR;
 # the three current fixed-knot basis columns predict other incomplete variables.
 pred[,'pir']<-0;pred['pir',paste0('pir_ns',1:3)]<-0
 where<-is.na(x);where[,method=='']<-FALSE
 visit<-c('pir',paste0('pir_ns',1:3),'education','smoking','bmi','log_creatinine','diabetes')
 stopifnot(!anyNA(x[,method=='']),all(!is.na(a$anemia)),all(!is.na(a$fi)))
 list(data=x,method=method,predictorMatrix=pred,where=where,visitSequence=visit)
}
run_imputation <- function(spec,m,maxit,seed,printFlag=TRUE) {
 mice(spec$data,m=m,maxit=maxit,method=spec$method,predictorMatrix=spec$predictorMatrix,where=spec$where,visitSequence=spec$visitSequence,donors=5,seed=seed,printFlag=printFlag,nnet.MaxNWts=20000,remove.collinear=FALSE)
}
forms<-list(M2=anemia~ch*(fi+cycle+ns(age10,knots=c(4,6),Boundary.knots=c(2,8))+female+race+education+ns(pir,knots=c(1,3),Boundary.knots=c(0,5))+smoking),M3=anemia~ch*(fi+cycle+ns(age10,knots=c(4,6),Boundary.knots=c(2,8))+female+race+education+ns(pir,knots=c(1,3),Boundary.knots=c(0,5))+smoking+bmi+log_creatinine+diabetes))

# mice3.19.0 ibind drops NULL entries when a custom visitSequence omits
# completely observed columns. Restore list positions by names; imputed cells
# are untouched. Verify each completed dataset against its original worker.
bind_mids_safely<-function(parts){
 imp<-Reduce(mice::ibind,parts)
 vals<-imp$imp;imp$imp<-setNames(lapply(names(imp$data),function(v)vals[[v]]),names(imp$data))
 stopifnot(identical(names(imp$imp),names(imp$data)))
 k<-0L
 for(part in parts)for(j in seq_len(part$m)){k<-k+1L;stopifnot(identical(complete(imp,k),complete(part,j)))}
 imp
}
