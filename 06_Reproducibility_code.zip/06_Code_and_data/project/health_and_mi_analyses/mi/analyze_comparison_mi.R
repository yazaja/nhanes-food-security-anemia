# Sensitivity only: two history-specific covariate-FCS models, then pooled survey inference.
# Rscript analyze_comparison_mi.R OUTDIR INPUT final
args<-commandArgs(TRUE);out<-args[1];infile<-args[2]
source(file.path(out,'prepare_mi.R'));source(file.path(out,'mi_diagnostics.R'))
suppressPackageStartupMessages(library(mitml))
writecsv<-function(x,n)write.csv(x,file.path(out,n),row.names=FALSE,na='')
start<-Sys.time();z<-prepare_data(infile);mec<-z$mec;ix<-z$ix;a<-z$a
full_design<-svydesign(ids=~psu_id,strata=~strata_id,weights=~weight,nest=TRUE,data=mec)
specs<-lapply(split(a,a$ch),make_spec)
for(g in names(specs)){
 s<-specs[[g]];writecsv(data.frame(ch=g,variable=names(s$data),missing=colSums(is.na(s$data)),n=nrow(s$data),method=s$method),paste0(g,'_missingness.csv'))
 writecsv(data.frame(variable=rownames(s$predictorMatrix),s$predictorMatrix,check.names=FALSE),paste0(g,'_predictor_requested.csv'))
}
total_m<-20L;maxit<-10L;cores<-6L
final_replay<-length(args)>2 && args[3]=='final'
protocol<-if(final_replay)read_json(file.path(out,'final_protocol.json'),simplifyVector=TRUE) else NULL
jobs<-expand.grid(worker=1:5,ch=names(specs),stringsAsFactors=FALSE)
seeds<-2026101810L+seq_len(nrow(jobs));m_per_worker<-4L
worker<-function(j){
 g<-jobs$ch[j];name<-paste0('worker_',g,'_',jobs$worker[j]);f<-file(file.path(out,paste0(name,'.log')),'wt');sink(f);on.exit({sink();close(f)})
 cat('START',format(Sys.time()),'seed',seeds[j],'n',nrow(specs[[g]]$data),'\n');flush.console()
 imp<-run_imputation(specs[[g]],m_per_worker,maxit,seeds[j],TRUE)
 if(final_replay){
  for(additional in protocol$continuation_blocks[[g]]){
   if(additional>0)imp<-mice::mice.mids(imp,maxit=additional,printFlag=TRUE,nnet.MaxNWts=20000,remove.collinear=FALSE)
  }
 }
 path<-file.path(out,paste0(name,'_server_only.rds'));saveRDS(imp,path)
 cat('COMPLETE',format(Sys.time()),'\n');flush.console();path
}
cat('LAUNCH_STRATIFIED_FCS jobs',nrow(jobs),'max_workers6 m_per_group20 maxit10\n');flush.console()
# Resume completed worker batches after a postprocessing failure without repeating FCS.
expected_paths<-file.path(out,paste0('worker_',jobs$ch,'_',jobs$worker,'_server_only.rds'))
if(length(args)>2 && args[3]=='resume'){
 extended_paths<-file.path(out,paste0('extended20_worker_',jobs$ch,'_',jobs$worker,'_server_only.rds'))
 expected_paths[file.exists(extended_paths)]<-extended_paths[file.exists(extended_paths)]
 extended30_paths<-file.path(out,paste0('extended30_worker_',jobs$ch,'_',jobs$worker,'_server_only.rds'))
 expected_paths[file.exists(extended30_paths)]<-extended30_paths[file.exists(extended30_paths)]
 stopifnot(all(file.exists(expected_paths)));paths<-as.list(expected_paths)
}else paths<-parallel::mclapply(seq_len(nrow(jobs)),worker,mc.cores=cores,mc.preschedule=FALSE,mc.set.seed=FALSE)
if(any(vapply(paths,inherits,logical(1),'try-error')))stop('A FCS worker failed; retain completed work for recovery')
imps<-list();diags<-list();events<-list();dists<-list();checks<-list()
for(g in names(specs)){
 parts<-lapply(paths[jobs$ch==g],readRDS);imps[[g]]<-bind_mids_safely(parts);imp<-imps[[g]];s<-specs[[g]]
 stopifnot(imp$m==total_m,imp$iteration>=maxit);saveRDS(imp,file.path(out,paste0('imputed_',g,'_server_only.rds')))
 writecsv(data.frame(variable=rownames(imp$predictorMatrix),imp$predictorMatrix,check.names=FALSE),paste0(g,'_predictor_used.csv'))
 for(j in seq_along(parts))if(!is.null(parts[[j]]$loggedEvents)){ev<-parts[[j]]$loggedEvents;ev$ch<-g;ev$worker<-j;events[[length(events)+1]]<-ev}
 dg<-mi_trace_diagnostics(imp);dg$ch<-g;diags[[g]]<-dg
 pdf(file.path(out,paste0(g,'_trace.pdf')),width=11,height=8);print(plot(imp));dev.off()
 obsunchanged<-TRUE;passive_error<-0;rangeok<-TRUE
 completed<-lapply(seq_len(total_m),function(k){
  zz<-complete(imp,k);stopifnot(!anyNA(zz))
  for(v in names(s$data)){take<-!is.na(s$data[[v]]);if(!identical(as.character(zz[[v]][take]),as.character(s$data[[v]][take])))obsunchanged<<-FALSE}
  for(v in c('pir','bmi','log_creatinine'))rangeok<<-rangeok&&all(zz[[v]]>=min(s$data[[v]],na.rm=TRUE)&zz[[v]]<=max(s$data[[v]],na.rm=TRUE))
  passive_error<<-max(passive_error,max(abs(as.matrix(zz[paste0('pir_ns',1:3)])-ns_pir(zz$pir))))
  zz
 })
 stopifnot(obsunchanged,rangeok,passive_error<1e-12)
 checks[[g]]<-list(observed_unchanged=obsunchanged,all_complete=TRUE,pmm_within_observed_ranges=rangeok,max_passive_spline_error=passive_error)
 for(v in missing_vars){
  observed<-s$data[[v]][!is.na(s$data[[v]])];imputed<-unlist(lapply(completed,function(zz)as.character(zz[[v]][is.na(s$data[[v]])])))
  if(is.factor(observed))for(lev in levels(observed))dists[[length(dists)+1]]<-data.frame(ch=g,variable=v,stat=paste0('proportion_',lev),observed=mean(as.character(observed)==lev),imputed=mean(imputed==lev))
  if(!is.factor(observed))for(st in c('min','q25','median','mean','q75','max')){fun<-switch(st,min=min,q25=function(x)quantile(x,.25),median=median,mean=mean,q75=function(x)quantile(x,.75),max=max);dists[[length(dists)+1]]<-data.frame(ch=g,variable=v,stat=st,observed=unname(fun(observed)),imputed=unname(fun(as.numeric(imputed))))}
 }
 rm(completed);gc(FALSE)
}
writecsv(do.call(rbind,diags),'convergence.csv');writecsv(do.call(rbind,dists),'observed_imputed_distributions.csv')
if(length(events))writecsv(do.call(rbind,events),'logged_events.csv')
write_json(checks,file.path(out,'imputation_checks.json'),pretty=TRUE,auto_unbox=TRUE)
cat('FCS_COMPLETE beginning 40 survey models in 6 workers\n');flush.console()
fit_one<-function(k){
 dm<-mec
 for(g in names(imps)){
  completed<-complete(imps[[g]],k);at<-ix[a$ch==g]
  stopifnot(nrow(completed)==length(at))
  for(v in missing_vars){value<-completed[[v]];if(v=='diabetes')value<-as.numeric(as.character(value));dm[at,v]<-value}
 }
 stopifnot(!anyNA(dm[ix,c('anemia','fi','ch','cycle','age10','female','race',missing_vars)]),identical(dm$anemia,mec$anemia),identical(dm$fi,mec$fi),identical(dm$ch,mec$ch))
 design<-svydesign(ids=~psu_id,strata=~strata_id,weights=~weight,nest=TRUE,data=dm);design<-subset(design,extension_eligible)
 result<-list()
 for(nm in names(forms)){
  warns<-character();f<-withCallingHandlers(svyglm(forms[[nm]],design=design,family=quasibinomial()),warning=function(w){warns<<-c(warns,conditionMessage(w));invokeRestart('muffleWarning')})
  stopifnot(f$converged,f$rank==length(coef(f)),f$df.residual>0,all(is.finite(coef(f))),all(is.finite(vcov(f))))
  result[[nm]]<-list(q=coef(f),u=vcov(f),dfcom=f$df.residual,rank=f$rank,n=nrow(f$model),events=sum(f$model$anemia),warnings=paste(unique(warns),collapse=' | '))
 }
 result
}
fits<-parallel::mclapply(seq_len(total_m),fit_one,mc.cores=cores,mc.preschedule=FALSE)
if(any(vapply(fits,inherits,logical(1),'try-error')))stop('A model failed; no imputation dropped')
saveRDS(fits,file.path(out,'survey_estimate_moments.rds'))
pooled<-list();perimp<-list();global<-list();diagnostic<-list();allcoef<-list()
for(nm in names(forms)){
 fs<-lapply(fits,'[[',nm);terms<-names(fs[[1]]$q);dfcom<-min(vapply(fs,'[[',numeric(1),'dfcom'));stopifnot(all(vapply(fs,function(f)identical(names(f$q),terms),logical(1))))
 for(k in seq_len(total_m)){f<-fs[[k]];allcoef[[length(allcoef)+1]]<-data.frame(model=nm,imputation=k,term=terms,beta=f$q,se=sqrt(diag(f$u)),dfcom=f$dfcom);diagnostic[[length(diagnostic)+1]]<-data.frame(model=nm,imputation=k,rank=f$rank,dfcom=f$dfcom,n=f$n,events=f$events,warnings=f$warnings)}
 for(g in c('no_cancer','cancer'))for(k in 2:4){
  L<-setNames(numeric(length(terms)),terms);L[paste0('fi',k)]<-1;if(g=='cancer')L[paste0('chcancer:fi',k)]<-1
  q<-vapply(fs,function(f)sum(L*f$q),numeric(1));u<-vapply(fs,function(f)drop(L%*%f$u%*%L),numeric(1))
  p<-mice::pool.scalar(q,u,n=dfcom+1,k=1,rule='rubin1987');se<-sqrt(p$t);crit<-qt(.975,p$df);mcse<-sqrt(p$b/total_m)
  pooled[[length(pooled)+1]]<-data.frame(model=nm,ch=g,fi=k,n=sum(a$ch==g),events=sum(a$anemia[a$ch==g]),m=total_m,logOR=p$qbar,se=se,OR=exp(p$qbar),lower=exp(p$qbar-crit*se),upper=exp(p$qbar+crit*se),p=2*pt(-abs(p$qbar/se),p$df),df=p$df,dfcom=dfcom,within=p$ubar,between=p$b,total=p$t,fmi=p$fmi,mcse_logOR=mcse,mcse_to_pooled_se=mcse/se)
  perimp[[length(perimp)+1]]<-data.frame(model=nm,ch=g,fi=k,imputation=seq_len(total_m),logOR=q,se=sqrt(u),OR=exp(q))
 }
 idx<-match(paste0('chcancer:fi',2:4),terms);stopifnot(!anyNA(idx))
 Q<-sapply(fs,function(f)f$q[idx]);U<-array(unlist(lapply(fs,function(f)f$u[idx,idx])),c(3,3,total_m))
 # D1 multivariate Wald pooling: average within-imputation covariance,
 # between-imputation covariance and Li/Raghunathan/Rubin + finite-df F reference.
 # Calling the same numerical engine used by public mice::D1/mitml::testModels
 # avoids fitting unused null models; Q and U are exact survey-Wald moments.
 test<-getFromNamespace('.D1','mitml')(Qhat=Q,Uhat=U,df.com=dfcom)
 qbar<-rowMeans(Q);ubar<-apply(U,c(1,2),mean);B<-cov(t(Q));riv<-(1+1/total_m)*sum(diag(B%*%solve(ubar)))/3
 independent_F<-drop(t(qbar)%*%solve(ubar)%*%qbar)/(3*(1+riv))
 stopifnot(abs(independent_F-as.numeric(test$F))<1e-10,test$v>0)
 global[[nm]]<-data.frame(model=nm,m=total_m,F=as.numeric(test$F),df1=test$k,df2=test$v,dfcom=dfcom,p=pf(test$F,test$k,test$v,lower.tail=FALSE),average_relative_increase_variance=test$r,method='D1 multivariate Wald, finite complete-data survey residual df')
 writecsv(data.frame(term=rownames(Q),Q,check.names=FALSE),paste0(nm,'_interaction_per_imputation_beta.csv'))
 saveRDS(list(Q=Q,U=U,Qbar=qbar,Ubar=ubar,B=B,T=ubar+(1+1/total_m)*B,dfcom=dfcom,test=test),file.path(out,paste0(nm,'_interaction_pooling_moments.rds')))
}
writecsv(do.call(rbind,pooled),'pooled_OR.csv');writecsv(do.call(rbind,perimp),'per_imputation_OR.csv');writecsv(do.call(rbind,global),'pooled_interaction.csv');writecsv(do.call(rbind,diagnostic),'model_diagnostics.csv');writecsv(do.call(rbind,allcoef),'per_imputation_all_coefficients.csv')
manifest<-list(status='executed',input=infile,input_md5=unname(tools::md5sum(infile)),n=nrow(a),events=sum(a$anemia),full_MEC_n=nrow(mec),full_MEC_strata=length(unique(mec$strata_id)),full_MEC_PSUs=length(unique(mec$psu_id)),full_design_df=degf(full_design),cancer_n=sum(a$ch=='cancer'),cancer_events=sum(a$anemia[a$ch=='cancer']),noncancer_n=sum(a$ch=='no_cancer'),noncancer_events=sum(a$anemia[a$ch=='no_cancer']),m=total_m,initial_iterations=maxit,iterations_by_group=lapply(imps,function(i)i$iteration),workers=cores,worker_seeds=seeds,imputation='Separate cancer/no-cancer FCS; paired index forms20 combined completed domains. Six covariates only; PMM numeric, polyreg education/smoking, logreg diabetes. Fixed age basis, passive PIR basis, FI4, anemia and Hb, FI-by-anemia, log weight and cycle-specific fixed strata.',compatibility='Cancer-stratified FCS allows distinct imputation relationships. Passive PIR basis preserves deterministic consistency. This remains an approximate MAR FCS sensitivity, not formally substantive-model-compatible FCS; fixed survey strata/log weights included but no PSU random effects.',design='Full MEC before eligible-domain subset in all20 analyses; all PSUs retained in variance calculation.',formulas=lapply(forms,function(f)paste(deparse(f),collapse=' ')),scalar_pool='mice::pool.scalar Rubin variance and Barnard-Rubin df, n=dfcom+1 k=1 where dfcom is svyglm residual design df.',interaction_pool='mitml .D1 numerical engine used by mice::D1: 3 FI-by-cancer coefficients and full3x3 survey covariance; finite complete-data residual df; not mean P values.',combination_verification='Every combined completed dataset exactly equals its source worker completion after restoring names/NULL slots in mice3.19.0 ibind.',standardized_MI='Not calculated. OR and joint interaction only. CC standardized differences are a separate root module.',never_imputed=c('food security','cancer history','anemia','Hb','weights','design','eligibility'),max_mcse_ratio=max(do.call(rbind,pooled)$mcse_to_pooled_se),logged_event_count=if(length(events))nrow(do.call(rbind,events)) else 0,elapsed_seconds=as.numeric(difftime(Sys.time(),start,units='secs')),versions=list(R=R.version.string,mice=as.character(packageVersion('mice')),survey=as.character(packageVersion('survey')),mitml=as.character(packageVersion('mitml'))),data_transfer='Individual completed datasets stay on shared server; local exports are code and aggregate diagnostics/results only')
manifest$run_mode<-if(length(args)>2)args[3] else 'initial'
manifest$elapsed_scope<-if(manifest$run_mode=='resume') 'Postprocessing only; excludes completed FCS and continuation runtime' else 'Current invocation including FCS and analysis'
manifest$max_rhat_by_group<-lapply(diags,function(d)max(d$rank_normalized_split_rhat,na.rm=TRUE))
manifest$diagnostic_status<-if(all(unlist(manifest$max_rhat_by_group)<=1.05) && manifest$max_mcse_ratio<=0.05) 'Meets frozen Rhat and MCSE criteria' else 'Does not meet all frozen Rhat and MCSE criteria; report diagnostic limitation without dropping imputations'
binding_verification<-lapply(imps,function(i)list(m=i$m,iterations=i$iteration,list_slots=length(i$imp),data_columns=ncol(i$data),combined_completed_datasets_identical_to_workers=TRUE,all_complete=TRUE))
write_json(binding_verification,file.path(out,'binding_fix_verification.json'),pretty=TRUE,auto_unbox=TRUE)
write_json(manifest,file.path(out,'run_manifest.json'),pretty=TRUE,auto_unbox=TRUE,digits=12);writeLines(capture.output(sessionInfo()),file.path(out,'sessionInfo.txt'))
print(do.call(rbind,global));print(do.call(rbind,pooled));cat('COMPARISON_MI_COMPLETE\n')
