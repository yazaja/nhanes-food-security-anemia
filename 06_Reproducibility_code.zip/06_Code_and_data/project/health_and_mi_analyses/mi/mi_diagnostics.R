# Dependency-free rank-normalized split Rhat from already saved MICE traces.
# Monitors imputed-value means/variances, not a proof of MAR or model validity.
split_rhat <- function(z) {
 z<-as.matrix(z);n<-nrow(z);h<-floor(n/2)
 if(h<2 || any(!is.finite(z)))return(NA_real_)
 s<-cbind(z[seq_len(h),,drop=FALSE],z[(n-h+1):n,,drop=FALSE])
 basic<-function(x){w<-mean(apply(x,2,var));b<-nrow(x)*var(colMeans(x));if(w==0)return(if(b==0)1 else Inf);sqrt(((nrow(x)-1)/nrow(x)*w+b/nrow(x))/w)}
 ranknorm<-function(x){r<-rank(as.vector(x),ties.method='average');matrix(qnorm((r-3/8)/(length(r)+1/4)),nrow=nrow(x),ncol=ncol(x))}
 max(basic(ranknorm(s)),basic(ranknorm(abs(s-median(s)))))
}
mi_trace_diagnostics <- function(imp) {
 out<-list()
 for(v in names(imp$method)[imp$method!=''])for(param in c('mean','variance')){
  z<-if(param=='mean')imp$chainMean[v,,] else imp$chainVar[v,,]
  z<-matrix(z,nrow=imp$iteration,ncol=imp$m)
  ac<-apply(z,2,function(x)if(any(!is.finite(x))||sd(x)==0)NA_real_ else cor(head(x,-1),tail(x,-1)))
  out[[length(out)+1]]<-data.frame(variable=v,parameter=param,iterations=nrow(z),chains=ncol(z),rank_normalized_split_rhat=split_rhat(z),mean_lag1_autocorrelation=if(all(is.na(ac)))NA_real_ else mean(ac,na.rm=TRUE),max_absolute_lag1_autocorrelation=if(all(is.na(ac)))NA_real_ else max(abs(ac),na.rm=TRUE),trace_all_finite=all(is.finite(z)),trace_constant=all(is.finite(z)) && all(z==z[1]))
 }
 do.call(rbind,out)
}
