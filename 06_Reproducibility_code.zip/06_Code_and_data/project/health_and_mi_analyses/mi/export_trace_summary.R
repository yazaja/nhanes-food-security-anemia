args<-commandArgs(TRUE);out<-args[1];dest<-args[2];dir.create(dest,recursive=TRUE,showWarnings=FALSE)
source(file.path(out,'prepare_mi.R'));source(file.path(out,'mi_diagnostics.R'))
rows<-list();traces<-list()
for(g in c('cancer','no_cancer')){
 imp<-readRDS(file.path(out,paste0('imputed_',g,'_server_only.rds')));vars<-names(imp$method)[imp$method!='']
 for(kind in c('mean','variance')){
  arr<-if(kind=='mean')imp$chainMean[vars,,,drop=FALSE]else imp$chainVar[vars,,,drop=FALSE]
  dimnames(arr)<-list(variable=vars,iteration=as.character(1:imp$iteration),chain=as.character(1:imp$m))
  tab<-as.data.frame.table(arr,responseName='value',stringsAsFactors=FALSE);tab$ch<-g;tab$parameter<-kind;traces[[length(traces)+1]]<-tab
  for(v in vars){x<-matrix(arr[v,,],nrow=imp$iteration,ncol=imp$m);h<-floor(imp$iteration/2);rows[[length(rows)+1]]<-data.frame(ch=g,variable=v,parameter=kind,iterations=imp$iteration,chains=imp$m,full_Rhat=split_rhat(x),last_half_Rhat=split_rhat(tail(x,h)),last_half_from=imp$iteration-h+1,last_half_to=imp$iteration)}
 }
}
write.csv(do.call(rbind,traces),file.path(dest,'complete_chain_traces.csv'),row.names=FALSE,na='')
d<-do.call(rbind,rows);write.csv(d,file.path(dest,'rhat_full_and_last_half.csv'),row.names=FALSE,na='');print(subset(d,ch=='no_cancer'&variable=='pir_ns2'))
