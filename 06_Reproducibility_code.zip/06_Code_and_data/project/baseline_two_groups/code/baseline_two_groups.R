# Descriptive summaries only; run on the shared server. No hypothesis tests/model refits.
suppressPackageStartupMessages({library(survey);library(jsonlite)})
args<-commandArgs(TRUE);infile<-args[1];out<-args[2]
dir.create(out,recursive=TRUE,showWarnings=FALSE)
options(survey.lonely.psu='fail')
d<-read.csv(infile,stringsAsFactors=FALSE)
stopifnot(!anyDuplicated(d$SEQN),sum(d$eligible)==4034,sum(d$anemia[d$eligible==1])==553)
d$ch<-factor(ifelse(d$MCQ220==1,'cancer',ifelse(d$MCQ220==2,'no_cancer',NA)),levels=c('cancer','no_cancer'))
d$fi<-factor(d$FSDHH,levels=1:4)
d$extension_eligible<-with(d,RIDAGEYR>=20 & known_pregnant==0 & RIDSTATR==2 & weight>0 & !is.na(ch)&!is.na(fi)&!is.na(anemia))
d$extension_eligible[is.na(d$extension_eligible)]<-FALSE
d$age65<-ifelse(is.na(d$RIDAGEYR),NA,as.numeric(d$RIDAGEYR>=65))
mec<-subset(d,RIDSTATR==2 & weight>0 & !is.na(strata_id)&!is.na(psu_id))
des<-svydesign(ids=~psu_id,strata=~strata_id,weights=~weight,nest=TRUE,data=mec)
desc<-subset(des,extension_eligible)
stopifnot(nrow(desc$variables)==41972)
continuous<-c('RIDAGEYR','pir','bmi','LBXSCR','LBXHGB')
categorical<-list(female=0:1,age65=0:1,race=c(3,4,1,2,5),education=1:3,smoking=0:2,diabetes=0:1,fi=1:4,anemia=0:1,cycle=sort(unique(desc$variables$cycle)))
rows<-list();missing<-list();checks<-list()
for(g in c('cancer','no_cancer')){
 ad<-subset(desc,ch==g);N<-nrow(ad$variables)
 stopifnot(N==if(g=='cancer')4034 else 37938, sum(ad$variables$anemia)==if(g=='cancer')553 else 3620)
 for(v in continuous){
  x<-ad$variables[[v]];n<-sum(!is.na(x));f<-reformulate(v)
  avg<-as.numeric(coef(svymean(f,ad,na.rm=TRUE)));sd<-sqrt(as.numeric(coef(svyvar(f,ad,na.rm=TRUE))))
  rows[[paste(g,v)]]<-data.frame(group=g,type='continuous',variable=v,level='',group_n=N,available_n=n,missing_n=N-n,n=NA_real_,mean=avg,sd=sd,percent=NA_real_,formatted=sprintf('%.2f (%.2f)',avg,sd))
 }
 for(v in names(categorical)){
  x<-ad$variables[[v]];ok<-!is.na(x);valid<-ad[ok,];nvalid<-sum(ok);pcts<-c();ns<-c()
  for(k in categorical[[v]]){
   ind<-as.numeric(valid$variables[[v]]==k);tmp<-valid;tmp$variables$indicator<-ind
   pct<-100*as.numeric(coef(svymean(~indicator,tmp)));nk<-sum(ind)
   rows[[paste(g,v,k)]]<-data.frame(group=g,type='categorical',variable=v,level=as.character(k),group_n=N,available_n=nvalid,missing_n=N-nvalid,n=nk,mean=NA_real_,sd=NA_real_,percent=pct,formatted=sprintf('%d (%.1f%%)',nk,pct))
   ns<-c(ns,nk);pcts<-c(pcts,pct)
  }
  stopifnot(sum(ns)==nvalid,abs(sum(pcts)-100)<1e-8)
 }
 for(v in c(continuous,names(categorical))){
  tmp<-ad;tmp$variables$missing_indicator<-as.numeric(is.na(ad$variables[[v]]))
  missing[[paste(g,v)]]<-data.frame(group=g,variable=v,group_n=N,missing_n=sum(tmp$variables$missing_indicator),missing_weighted_percent=100*as.numeric(coef(svymean(~missing_indicator,tmp))))
 }
 checks[[g]]<-list(n=N,events=sum(ad$variables$anemia),male=sum(ad$variables$female==0),female=sum(ad$variables$female==1))
}
tab<-do.call(rbind,rows);rownames(tab)<-NULL
miss<-do.call(rbind,missing);rownames(miss)<-NULL
write.csv(tab,file.path(out,'table1_two_groups_long.csv'),row.names=FALSE,na='')
write.csv(miss,file.path(out,'table1_missingness.csv'),row.names=FALSE,na='')
ca<-tab[tab$group=='cancer',];nc<-tab[tab$group=='no_cancer',]
stopifnot(identical(ca$variable,nc$variable),identical(ca$level,nc$level),checks$cancer$male==1890,checks$cancer$female==2144)
wide<-data.frame(type=ca$type,variable=ca$variable,level=ca$level,cancer=ca$formatted,no_cancer=nc$formatted,cancer_available_n=ca$available_n,no_cancer_available_n=nc$available_n)
write.csv(wide,file.path(out,'table1_two_groups.csv'),row.names=FALSE,na='')
meta<-list(status='executed',date='2026-10-18',input=infile,full_MEC_n=nrow(mec),domain_n=nrow(desc$variables),counts=checks,continuous='Survey-weighted mean and square root of svyvar; SD, not SE',categorical='Unweighted n and survey-weighted percent among observed values for each variable',missingness='Available-case denominator per variable; no imputation',age='RIDAGEYR topcoded at80 in frozen merged input',creatinine='LBXSCR calibrated by original cleaning; not raw uncalibrated field',tests='None',regression_models_refitted=FALSE,checks='Eligibility/event anchors passed; each categorical partition sums to its observed denominator and 100% weighted')
write_json(meta,file.path(out,'table1_manifest.json'),pretty=TRUE,auto_unbox=TRUE,digits=12)
sink(file.path(out,'baseline_sessionInfo.txt'));sessionInfo();sink()
cat('BASELINE_COMPLETE\n');print(checks);print(wide)
