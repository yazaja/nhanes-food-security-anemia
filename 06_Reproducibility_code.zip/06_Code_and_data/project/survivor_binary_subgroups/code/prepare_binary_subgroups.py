#!/usr/bin/env python3
"""Select previously fitted binary subgroup results without fitting any model.

This is a lossless presentation-data transformation. All estimates and tests
come from the original, separately identified result files supplied below.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

ORDER = ["subgroup_female_0", "subgroup_female_1",
         "subgroup_age65_0", "subgroup_age65_1"]


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def write_csv(path, rows):
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--source-results", type=Path, required=True)
    ap.add_argument("--output-dir", type=Path, required=True)
    args = ap.parse_args()
    sources = {name: args.source_results / name for name in (
        "model_results.csv", "interaction_tests.csv",
        "age_interaction_nonlinearity_check.json")}
    all_rows = read_csv(sources["model_results.csv"])
    rows = []
    for model in ORDER:
        matched = [r for r in all_rows if r["model"] == model]
        if len(matched) != 1:
            raise ValueError(f"Expected exactly one source record for {model}")
        r = matched[0]
        if r["term"] != "food_insecure" or r["kind"] != "OR":
            raise ValueError(f"Unexpected model term or effect scale: {model}")
        if r["converged"].upper() != "TRUE":
            raise ValueError(f"Source model did not converge: {model}")
        row = {k: r[k] for k in (
            "model", "term", "n", "anemia_events", "insecure_n",
            "insecure_events", "coefficient", "SE", "estimate", "CI_low",
            "CI_high", "p", "design_df", "residual_df", "parameters", "converged")}
        row["secure_n"] = int(r["n"]) - int(r["insecure_n"])
        row["secure_events"] = int(r["anemia_events"]) - int(r["insecure_events"])
        row["estimate_source"] = "independently_fitted_subgroup_model"
        row["age_adjustment"] = "linear_continuous"
        row["source_record"] = "model_results.csv:" + model
        rows.append(row)
    tests = []
    all_tests = read_csv(sources["interaction_tests.csv"])
    for modifier in ("female", "age65"):
        matched = [r for r in all_tests if r["modifier"] == modifier]
        if len(matched) != 1:
            raise ValueError(f"Expected one interaction test for {modifier}")
        r = matched[0]
        tests.append({
            "modifier": modifier, "age_adjustment": "linear_continuous",
            "n": r["n"], "events": r["events"], "F": r["F"],
            "df": r["df"], "denominator_df": r["denominator_df"],
            "p_interaction": r["p_interaction"],
            "test_source": "pooled_binary_exposure_interaction_model",
            "source_record": "interaction_tests.csv:" + modifier})
    nonlinear = json.loads(sources["age_interaction_nonlinearity_check.json"].read_text())
    tests.append({
        "modifier": "age65", "age_adjustment": "natural_spline_df3",
        "n": nonlinear["n"], "events": nonlinear["events"],
        "F": nonlinear["F"], "df": nonlinear["df"],
        "denominator_df": nonlinear["denominator_df"],
        "p_interaction": nonlinear["p_interaction"],
        "test_source": "pooled_binary_exposure_interaction_model",
        "source_record": "age_interaction_nonlinearity_check.json"})
    args.output_dir.mkdir(parents=True, exist_ok=True)
    outputs = {
        "binary_subgroup_models.csv": rows,
        "binary_interaction_tests.csv": tests,
    }
    for name, data in outputs.items():
        write_csv(args.output_dir / name, data)
    manifest = {
        "model_refitted": False,
        "presentation_only": True,
        "exposure_source": "household food insecurity",
        "exposed_category_codes": [3, 4],
        "reference_category_codes": [1, 2],
        "coefficient_source": "independently fitted stratum-specific M2 models",
        "interaction_source": "pooled M2 models with exposure-by-modifier term",
        "nonlinear_age_test_is_sensitivity_analysis": True,
        "model_order": ORDER,
        "sources": [{"name": p.name, "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
                    for p in sources.values()],
        "outputs": [{"name": name, "rows": len(data),
                     "sha256": hashlib.sha256((args.output_dir/name).read_bytes()).hexdigest()}
                    for name, data in outputs.items()],
        "source_rows": rows,
        "interaction_rows": tests,
    }
    (args.output_dir / "binary_subgroups_source_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"model_refitted": False, "subgroups": len(rows),
                      "interaction_tests": len(tests), "output_dir": str(args.output_dir)}))


if __name__ == "__main__":
    main()
