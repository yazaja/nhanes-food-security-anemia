# Four-category Table 1 from the existing, cleaned NHANES analytic input.
# Reuses eligibility, full-MEC survey design, variable definitions, and the
# make_table() implementation from analysis/formal_analysis.R. No model is fit
# and no raw data cleaning or replacement of the original outputs is performed.
suppressPackageStartupMessages(library(survey))
suppressPackageStartupMessages(library(jsonlite))

args <- commandArgs(trailingOnly=TRUE)
if (length(args) != 2L) {
  stop('Usage: Rscript table1_four_categories.R INPUT_CSV OUTPUT_DIR')
}
infile <- args[[1]]
out <- args[[2]]
dir.create(out, recursive=TRUE, showWarnings=FALSE)
d <- read.csv(infile, stringsAsFactors=FALSE)
required <- c('SEQN', 'RIDAGEYR', 'RIDSTATR', 'weight', 'cycle', 'strata_id',
              'psu_id', 'cancer', 'known_pregnant', 'food_insecure', 'anemia',
              'female', 'race', 'education', 'pir', 'smoking', 'bmi',
              'diabetes', 'LBXHGB', 'LBXSCR', 'FSDHH')
stopifnot(all(required %in% names(d)), !anyDuplicated(d$SEQN))

options(survey.lonely.psu='fail')
d$cycle <- factor(d$cycle)
d$race <- relevel(factor(d$race, levels=1:5), ref='3')
d$education <- factor(d$education, levels=1:3)
d$smoking <- factor(d$smoking, levels=0:2)
d$age65 <- as.integer(d$RIDAGEYR >= 65)
d$eligible <- as.integer(d$RIDAGEYR >= 20 & d$cancer == 1 &
                          d$known_pregnant == 0 & d$RIDSTATR == 2 &
                          d$weight > 0 & !is.na(d$food_insecure) &
                          !is.na(d$anemia))
d$eligible[is.na(d$eligible)] <- 0

# Retain all examined participants for design construction, then select the
# cancer-survivor domain; do not construct the survey design from cases alone.
mec <- subset(d, RIDSTATR == 2 & weight > 0 &
                !is.na(strata_id) & !is.na(psu_id))
des <- svydesign(ids=~psu_id, strata=~strata_id, weights=~weight,
                 nest=TRUE, data=mec)
a <- subset(des, eligible == 1)
stopifnot(nrow(a$variables) == 4034L,
          sum(a$variables$anemia) == 553L,
          degf(des) > 0,
          !anyNA(a$variables$FSDHH),
          all(a$variables$FSDHH %in% 1:4),
          all(a$variables$food_insecure == as.integer(a$variables$FSDHH %in% 3:4)))

designs <- list(Overall=a,
                Full=subset(a, FSDHH == 1),
                Marginal=subset(a, FSDHH == 2),
                Low=subset(a, FSDHH == 3),
                VeryLow=subset(a, FSDHH == 4))
expected_n <- c(Overall=4034L, Full=3209L, Marginal=321L,
                Low=275L, VeryLow=229L)
observed_n <- vapply(designs, function(ad) nrow(ad$variables), integer(1))
stopifnot(identical(observed_n, expected_n),
          sum(observed_n[names(observed_n) != 'Overall']) == observed_n[['Overall']])

# Original Table 1 variables, labels, and summarization implementation.
# The grouping exposure itself is not repeated as an indicator within groups.
continuous<-c(RIDAGEYR='Age, years',pir='Family income-to-poverty ratio',bmi='BMI, kg/m2',LBXSCR='Creatinine, mg/dL',LBXHGB='Hemoglobin, g/dL')
categories<-list(female=c('0'='Male','1'='Female'),age65=c('0'='Age <65','1'='Age >=65'),race=c('1'='Mexican American','2'='Other Hispanic','3'='Non-Hispanic White','4'='Non-Hispanic Black','5'='Other race including multiracial'),education=c('1'='High school or less','2'='Some college/associate degree','3'='College graduate or above'),smoking=c('0'='Never','1'='Former','2'='Current'),diabetes=c('0'='No/borderline','1'='Yes'),anemia=c('0'='No anemia','1'='Anemia'),cycle=setNames(levels(d$cycle),levels(d$cycle)))
make_table<-function(designs) {
 outrows<-list();k<-0
 for(g in names(designs)) {
  ad<-designs[[g]];n<-nrow(ad$variables)
  for(v in names(continuous)) {
   xx<-ad$variables[[v]];n_avail<-sum(!is.na(xx));if(n_avail<2) next
   mu<-svymean(as.formula(paste0('~',v)),ad,na.rm=TRUE);va<-svyvar(as.formula(paste0('~',v)),ad,na.rm=TRUE)
   k<-k+1;outrows[[k]]<-data.frame(group=g,variable=v,level='',label=continuous[[v]],type='continuous',n_total=n,n_available=n_avail,n_missing=n-n_avail,n_level=NA_integer_,weighted_estimate=as.numeric(coef(mu)),SE=as.numeric(SE(mu)),weighted_SD=sqrt(as.numeric(va)),display=sprintf('%.2f (%.2f)',as.numeric(coef(mu)),sqrt(as.numeric(va))))
  }
  for(v in names(categories)) for(lev in names(categories[[v]])) {
   xx<-as.character(ad$variables[[v]]);ad$variables$.table_indicator<-ifelse(is.na(xx),NA_real_,as.numeric(xx==lev));n_avail<-sum(!is.na(xx))
   if(n_avail==0) next
   mu<-svymean(~.table_indicator,ad,na.rm=TRUE);nn<-sum(xx==lev,na.rm=TRUE)
   k<-k+1;outrows[[k]]<-data.frame(group=g,variable=v,level=lev,label=categories[[v]][[lev]],type='categorical',n_total=n,n_available=n_avail,n_missing=n-n_avail,n_level=nn,weighted_estimate=as.numeric(coef(mu)),SE=as.numeric(SE(mu)),weighted_SD=NA_real_,display=sprintf('%d (%.1f%%)',nn,100*as.numeric(coef(mu))))
  }
 }
 do.call(rbind,outrows)
}

tab1 <- make_table(designs)
write.csv(tab1, file.path(out, 'table1_four_level_long.csv'), row.names=FALSE)
wide <- reshape(tab1[,c('group','variable','level','label','type','display')],
                idvar=c('variable','level','label','type'),
                timevar='group', direction='wide')
wide <- wide[,c('variable','level','label','type',paste0('display.',names(designs)))]
write.csv(wide, file.path(out, 'table1_four_level_display.csv'), row.names=FALSE)

group_labels <- c(Overall='Overall', Full='Full food security',
                  Marginal='Marginal food security', Low='Low food security',
                  VeryLow='Very low food security')
groups <- do.call(rbind, lapply(names(designs), function(g) {
  data.frame(group=g, label=unname(group_labels[[g]]),
             FSDHH=if (g == 'Overall') NA_integer_ else match(g,names(designs)[-1]),
             n=nrow(designs[[g]]$variables),
             anemia_events=sum(designs[[g]]$variables$anemia),
             stringsAsFactors=FALSE)
}))
stopifnot(sum(groups$anemia_events[groups$group != 'Overall']) == 553L)
denominators <- unique(tab1[,c('group','variable','type','n_total','n_available','n_missing')])
summary <- list(
  status='executed_four_category_baseline_table',
  analysis_n=nrow(a$variables),
  anemia_events=sum(a$variables$anemia),
  groups=groups,
  grouping_variable='FSDHH',
  grouping_definition='1: full; 2: marginal; 3: low; 4: very low household food security',
  analytic_population='Original eligible descriptive sample; not restricted to M2 complete cases.',
  MEC_n=nrow(mec),
  MEC_strata=length(unique(mec$strata_id)),
  MEC_PSU=length(unique(mec$psu_id)),
  design_df=degf(des),
  weight_variable='weight (existing combined-cycle MEC analysis weight, unchanged)',
  table_convention=paste('Continuous: weighted mean (SD); categorical: unweighted n (weighted %).',
                         'Variable-specific available cases are used; categorical percentages use',
                         'the survey-weighted denominator among participants with nonmissing values',
                         'within each food-security group. No baseline P values.'),
  variable_denominators=denominators,
  cleaning_or_model_fitting_performed=FALSE,
  source_method='analysis/formal_analysis.R: eligibility, design construction, variable labels and make_table',
  versions=list(R=R.version.string, survey=as.character(packageVersion('survey')))
)
write_json(summary, file.path(out, 'table1_four_level_summary.json'),
           pretty=TRUE, auto_unbox=TRUE, na='null', digits=12)
cat('FOUR_CATEGORY_TABLE1_COMPLETE\n')
print(groups)
