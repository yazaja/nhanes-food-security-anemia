# Four-category household food security as the primary exposure.
# Reuses the existing cleaned input, eligibility, MEC design, and covariates.
# No download, raw-data cleaning, exposure spline, or ordinal trend test.
# Rscript analyze_four_category_primary.R INPUT_CSV OUTPUT_DIR
suppressPackageStartupMessages(library(survey))
suppressPackageStartupMessages(library(jsonlite))
suppressPackageStartupMessages(library(splines))

args <- commandArgs(trailingOnly=TRUE)
if (length(args) != 2L) stop('Usage: Rscript analyze_four_category_primary.R INPUT_CSV OUTPUT_DIR')
infile <- args[[1]]
out <- args[[2]]
dir.create(out, recursive=TRUE, showWarnings=FALSE)
d <- read.csv(infile, stringsAsFactors=FALSE)
required <- c('SEQN','RIDAGEYR','RIAGENDR','RIDSTATR','weight','cycle','strata_id',
              'psu_id','cancer','known_pregnant','food_insecure','anemia','age10',
              'female','race','education','pir','smoking','bmi','log_creatinine',
              'diabetes','LBXHGB','nmsc_only','FSDHH','FSDAD','hb_smoking_deduction',
              'anemia_smoking_corrected')
missing_columns <- setdiff(required, names(d))
if (length(missing_columns)) stop(paste('Required cleaned-input columns missing:', paste(missing_columns, collapse=', ')))
stopifnot(!anyDuplicated(d$SEQN))
options(survey.lonely.psu='fail')

# This is the identical on-load CBC precision convention in formal_analysis.R,
# used only for the smoking-corrected sensitivity outcome; measured Hb is intact.
old_smoking_anemia <- d$anemia_smoking_corrected
d$hb_smoking_corrected <- round(d$LBXHGB - d$hb_smoking_deduction, 1)
d$anemia_smoking_corrected <- ifelse(is.na(d$hb_smoking_corrected), NA_real_,
  ifelse(d$RIAGENDR == 1, d$hb_smoking_corrected < 13, d$hb_smoking_corrected < 12))
smoking_rounding_changed_on_R_load <- sum(old_smoking_anemia != d$anemia_smoking_corrected, na.rm=TRUE)

d$cycle <- factor(d$cycle)
d$race <- relevel(factor(d$race, levels=1:5), ref='3')
d$education <- factor(d$education, levels=1:3)
d$smoking <- factor(d$smoking, levels=0:2)
d$age65 <- as.integer(d$RIDAGEYR >= 65)
d$eligible <- as.integer(d$RIDAGEYR >= 20 & d$cancer == 1 & d$known_pregnant == 0 &
  d$RIDSTATR == 2 & d$weight > 0 & !is.na(d$food_insecure) & !is.na(d$anemia))
d$eligible[is.na(d$eligible)] <- 0
v2 <- c('anemia','food_insecure','cycle','age10','female','race','education','pir','smoking')
v3 <- c(v2,'bmi','log_creatinine','diabetes')
d$complete2 <- as.integer(complete.cases(d[,v2]))
d$complete3 <- as.integer(complete.cases(d[,v3]))
d$food_security_category <- factor(d$FSDHH, levels=1:4)
d$adult_food_security_category <- factor(d$FSDAD, levels=1:4)
stopifnot(!anyNA(d$food_security_category[d$eligible == 1]),
  all(d$food_insecure[d$eligible == 1] == as.integer(d$FSDHH[d$eligible == 1] %in% 3:4)))

# Construct the full MEC design before cancer-survivor domain subsetting.
mec <- subset(d, RIDSTATR == 2 & weight > 0 & !is.na(strata_id) & !is.na(psu_id))
des <- svydesign(ids=~psu_id, strata=~strata_id, weights=~weight, nest=TRUE, data=mec)
a <- subset(des, eligible == 1)
a2 <- subset(des, eligible == 1 & complete2 == 1)
a3 <- subset(des, eligible == 1 & complete3 == 1)
stopifnot(nrow(a$variables) == 4034L, sum(a$variables$anemia) == 553L,
          nrow(a2$variables) == 3755L, sum(a2$variables$anemia) == 510L,
          nrow(a3$variables) == 3587L, sum(a3$variables$anemia) == 472L, degf(des) > 0)

category_labels <- c('Fully food secure','Marginally food secure','Low food security','Very low food security')
fits <- list()
count_records <- list()
coefficient_records <- list()
diagnostic_records <- list()
global_records <- list()
formula_records <- list()
spline_records <- list()

save_csv <- function(x, filename) write.csv(x, file.path(out, filename), row.names=FALSE, na='')
bind_records <- function(x) { ans <- do.call(rbind, x); rownames(ans) <- NULL; ans }
count_groups <- function(ad, model, exposure='food_security_category', eventvar='anemia',
                         population=model, modifier=NA_character_, level=NA_integer_) {
  x <- as.character(ad$variables[[exposure]])
  yy <- ad$variables[[eventvar]]
  stopifnot(!anyNA(x), all(x %in% as.character(1:4)), !anyNA(yy), all(yy %in% 0:1))
  do.call(rbind, lapply(1:4, function(k) {
    take <- x == as.character(k)
    data.frame(model=model, population=population, exposure=exposure, event_definition=eventvar,
      modifier=modifier, level=level, category_code=k, category=category_labels[k],
      n=nrow(ad$variables), events=sum(yy), group_n=sum(take), group_events=sum(yy[take]),
      group_non_events=sum(yy[take] == 0), stringsAsFactors=FALSE)
  }))
}
count_records[['Descriptive']] <- count_groups(a, 'Descriptive')
save_csv(bind_records(count_records), 'group_counts.csv')

global_test <- function(fit, term) {
  test <- regTermTest(fit, as.formula(paste0('~', term)), method='Wald')
  result <- list(F=as.numeric(test$Ftest), df=as.numeric(test$df),
                 denominator_df=as.numeric(test$ddf), p=as.numeric(test$p))
  stopifnot(result$df == 3, is.finite(result$F), is.finite(result$p),
            result$denominator_df > 0, result$p >= 0, result$p <= 1)
  result
}

fit_model <- function(model, formula, ad, exposure='food_security_category',
                      eventvar='anemia', family=quasibinomial(), kind='OR',
                      modifier=NA_character_, level=NA_integer_) {
  counts <- count_groups(ad, model, exposure, eventvar, modifier=modifier, level=level)
  count_records[[model]] <<- counts
  save_csv(bind_records(count_records), 'group_counts.csv')
  if (any(counts$group_n == 0)) stop(paste(model, 'has an empty exposure category; see group_counts.csv'))
  if (kind == 'OR' && any(counts$group_events == 0 | counts$group_non_events == 0))
    stop(paste(model, 'has a category without events or non-events; see group_counts.csv'))
  # Counts refer to the exact design supplied. Fail if svyglm would silently
  # remove observations beyond the explicitly selected sensitivity sample.
  frame <- model.frame(formula, data=ad$variables, na.action=na.pass)
  stopifnot(nrow(frame) == nrow(ad$variables), all(complete.cases(frame)))
  fit_warnings <- character()
  fit <- withCallingHandlers(svyglm(formula, design=ad, family=family),
    warning=function(w) { fit_warnings <<- c(fit_warnings, conditionMessage(w)); invokeRestart('muffleWarning') })
  fits[[model]] <<- fit
  formula_records[[model]] <<- paste(deparse(formula), collapse=' ')
  # Persist the fitted natural-spline specification for reproducible follow-up.
  spline_columns <- vapply(frame, function(x) inherits(x, 'ns'), logical(1))
  if (any(spline_columns)) spline_records[[model]] <<- lapply(frame[spline_columns], function(x)
    list(knots=attr(x,'knots'), boundary_knots=attr(x,'Boundary.knots'), intercept=attr(x,'intercept')))
  cc <- summary(fit)$coefficients
  coefficient_records[[model]] <<- data.frame(model=model, term=rownames(cc),
    coefficient=cc[,1], SE=cc[,2], statistic=cc[,3], p=cc[,4], row.names=NULL,
    stringsAsFactors=FALSE)
  save_csv(bind_records(coefficient_records), 'all_coefficients.csv')
  b <- coef(fit)
  se <- sqrt(diag(vcov(fit)))
  diag <- data.frame(model=model, n=nrow(ad$variables), events=sum(ad$variables[[eventvar]]),
    converged=isTRUE(fit$converged), rank=fit$rank, parameters=length(b),
    rank_deficient=fit$rank < length(b), all_coefficients_finite=all(is.finite(b)),
    all_SE_finite=all(is.finite(se)), residual_df=fit$df.residual, design_df=degf(ad),
    minimum_group_n=min(counts$group_n), minimum_group_events=min(counts$group_events),
    minimum_group_non_events=min(counts$group_non_events),
    max_abs_coefficient=max(abs(b)), max_SE=max(se),
    fitted_min=min(fitted(fit)), fitted_max=max(fitted(fit)),
    warnings=paste(unique(fit_warnings), collapse=' | '), stringsAsFactors=FALSE)
  diagnostic_records[[model]] <<- diag
  save_csv(bind_records(diagnostic_records), 'model_diagnostics.csv')
  if (!isTRUE(fit$converged) || fit$rank != length(b) || !all(is.finite(b)) ||
      !all(is.finite(se)) || fit$df.residual <= 0)
    stop(paste(model, 'failed model diagnostics; see model_diagnostics.csv'))
  list(fit=fit, counts=counts)
}

record_model <- function(model, formula, ad, exposure='food_security_category', eventvar='anemia',
                         family=quasibinomial(), kind='OR',
                         modifier=NA_character_, level=NA_integer_, subgroup_label=NA_character_) {
  result <- fit_model(model, formula, ad, exposure, eventvar, family, kind, modifier, level)
  fit <- result$fit
  counts <- result$counts
  global <- global_test(fit, exposure)
  global_records[[model]] <<- data.frame(model=model, n=nrow(ad$variables),
    events=sum(ad$variables[[eventvar]]), exposure=exposure, event_definition=eventvar,
    global_F=global$F, global_df=global$df, global_denominator_df=global$denominator_df,
    global_p=global$p, stringsAsFactors=FALSE)
  b <- coef(fit)
  se <- sqrt(diag(vcov(fit)))
  crit <- qt(.975, fit$df.residual)
  rows <- lapply(1:4, function(k) {
    reference <- k == 1L
    term <- if (reference) NA_character_ else paste0(exposure, k)
    if (!reference) stopifnot(term %in% names(b), is.finite(b[[term]]), se[[term]] > 0)
    beta <- if (reference) 0 else unname(b[[term]])
    sigma <- if (reference) NA_real_ else unname(se[[term]])
    lower <- if (reference) NA_real_ else beta - crit * sigma
    upper <- if (reference) NA_real_ else beta + crit * sigma
    estimate <- if (kind == 'OR') exp(beta) else beta
    lower <- if (kind == 'OR') exp(lower) else lower
    upper <- if (kind == 'OR') exp(upper) else upper
    p <- if (reference) NA_real_ else 2 * pt(abs(beta/sigma), fit$df.residual, lower.tail=FALSE)
    if (!reference) stopifnot(all(is.finite(c(estimate,lower,upper,p))), lower <= estimate, estimate <= upper)
    data.frame(model=model, category_code=k, category=category_labels[k],
      n=counts$n[k], events=counts$events[k], group_n=counts$group_n[k],
      group_events=counts$group_events[k], estimate=estimate, ci_low=lower, ci_high=upper,
      p=p, global_p=global$p, kind=kind, exposure=exposure, event_definition=eventvar,
      is_reference=reference, coefficient=beta, SE=sigma, term=term,
      design_df=degf(ad), residual_df=fit$df.residual,
      global_F=global$F, global_df=global$df, global_denominator_df=global$denominator_df,
      modifier=modifier, level=level, subgroup_label=subgroup_label, stringsAsFactors=FALSE)
  })
  bind_records(rows)
}

forms <- list(
  M0=anemia ~ food_security_category + cycle,
  M1=anemia ~ food_security_category + cycle + age10 + female + race,
  M2=anemia ~ food_security_category + cycle + age10 + female + race + education + pir + smoking,
  M3=anemia ~ food_security_category + cycle + age10 + female + race + education + pir + smoking + bmi + log_creatinine + diabetes
)
main <- lapply(names(forms), function(model)
  record_model(model, forms[[model]], if (model == 'M3') a3 else a2))
main <- bind_records(main)
save_csv(main, 'main_models.csv')

adult_design <- subset(des, eligible == 1 & complete2 == 1 & !is.na(adult_food_security_category))
if (nrow(adult_design$variables) == 0L) stop('FSDAD exists but no eligible M2 participant has a valid four-level FSDAD value')
sensitivity <- list(
  record_model('sensitivity_adult_definition',
    update(forms$M2, . ~ . - food_security_category + adult_food_security_category), adult_design,
    exposure='adult_food_security_category'),
  record_model('sensitivity_exclude_nmsc_only', forms$M2,
    subset(des, eligible == 1 & complete2 == 1 & nmsc_only == 0)),
  record_model('sensitivity_smoking_corrected_hb',
    update(forms$M2, anemia_smoking_corrected ~ .),
    subset(des, eligible == 1 & complete2 == 1 & !is.na(anemia_smoking_corrected)),
    eventvar='anemia_smoking_corrected'),
  record_model('sensitivity_nonlinear_age10',
    update(forms$M2, . ~ . - age10 + ns(age10, df=3)), a2),
  record_model('sensitivity_nonlinear_pir',
    update(forms$M2, . ~ . - pir + ns(pir, df=3)), a2)
)
sensitivity <- bind_records(sensitivity)
save_csv(sensitivity, 'sensitivity_models.csv')

hemoglobin <- record_model('secondary_continuous_hb', update(forms$M2, LBXHGB ~ .),
  a2, family=gaussian(), kind='Hb_difference_g_dL')
save_csv(hemoglobin, 'hemoglobin_models.csv')

subgroups <- list()
subgroup_labels <- c(subgroup_female_0='Male', subgroup_female_1='Female',
                     subgroup_age65_0='Age <65', subgroup_age65_1='Age >=65')
for (modifier in c('female','age65')) for (level in 0:1) {
  subgroup <- a2[a2$variables[[modifier]] == level, ]
  form <- if (modifier == 'female') update(forms$M2, . ~ . - female) else forms$M2
  model <- paste0('subgroup_', modifier, '_', level)
  subgroups[[model]] <- record_model(model, form, subgroup, modifier=modifier, level=level,
                                    subgroup_label=unname(subgroup_labels[[model]]))
}
subgroups <- bind_records(subgroups)
save_csv(subgroups, 'subgroup_models.csv')

interactions <- list()
interaction_specs <- list(
  interaction_female=list(formula=update(forms$M2, . ~ . + food_security_category:female),
    modifier='female', age_adjustment='linear'),
  interaction_age65_linear=list(formula=update(forms$M2, . ~ . + age65 + food_security_category:age65),
    modifier='age65', age_adjustment='linear'),
  interaction_age65_spline=list(formula=update(forms$M2,
    . ~ . - age10 + ns(age10, df=3) + age65 + food_security_category:age65),
    modifier='age65', age_adjustment='ns_df3')
)
for (model in names(interaction_specs)) {
  specification <- interaction_specs[[model]]
  fit <- fit_model(model, specification$formula, a2, modifier=specification$modifier)$fit
  test <- global_test(fit, paste0('food_security_category:', specification$modifier))
  interactions[[model]] <- data.frame(model=model, modifier=specification$modifier,
    age_adjustment=specification$age_adjustment, n=nrow(a2$variables), events=sum(a2$variables$anemia),
    F=test$F, df=test$df, denominator_df=test$denominator_df, p_interaction=test$p,
    design_df=degf(a2), residual_df=fit$df.residual, stringsAsFactors=FALSE)
}
interactions <- bind_records(interactions)
save_csv(interactions, 'interaction_tests.csv')

# Observed prevalence is supplied for BOTH cohorts. The revised main prevalence
# figure uses Descriptive (4,034), matching Table 1; M2 values remain traceable.
prevalence_rows <- list()
for (population in c('Descriptive','M2_complete_case')) {
  ad <- if (population == 'Descriptive') a else a2
  for (k in 1:4) {
    gd <- ad[as.character(ad$variables$food_security_category) == as.character(k), ]
    prevalence <- svyciprop(~anemia, gd, method='logit', df=degf(gd))
    ci <- confint(prevalence)
    values <- c(as.numeric(coef(prevalence)), as.numeric(ci))
    stopifnot(all(is.finite(values)), all(values >= 0), all(values <= 1))
    prevalence_rows[[paste(population,k)]] <- data.frame(population=population,
      category_code=k, category=category_labels[k], n=nrow(gd$variables), events=sum(gd$variables$anemia),
      prevalence=values[1], ci_low=values[2], ci_high=values[3],
      cohort_n=nrow(ad$variables), cohort_events=sum(ad$variables$anemia),
      design_df=degf(gd), stringsAsFactors=FALSE)
  }
}
prevalence <- bind_records(prevalence_rows)
save_csv(prevalence, 'prevalence.csv')
save_csv(bind_records(global_records), 'global_tests.csv')
save_csv(bind_records(count_records), 'group_counts.csv')
save_csv(bind_records(diagnostic_records), 'model_diagnostics.csv')
save_csv(bind_records(coefficient_records), 'all_coefficients.csv')
saveRDS(fits, file.path(out, 'four_category_models.rds'))
sink(file.path(out, 'R_sessionInfo.txt'))
sessionInfo()
sink()

summary <- list(
  status='executed_four_category_primary_analyses', date=as.character(Sys.Date()),
  source='Existing cleaned NHANES 2003-March 2020 merged input; no raw download or re-cleaning',
  exposure='FSDHH as an unordered four-level factor; category 1 (fully food secure) is the reference',
  adult_sensitivity_exposure='FSDAD as an unordered four-level factor; category 1 is the reference',
  analysis_history=paste('Four-category primary framing requested after the original binary analysis',
                         'and supplementary four-category M2 results had been viewed.',
                         'This is a subsequent analysis revision, not a preregistered analysis.'),
  descriptive_n=nrow(a$variables), descriptive_events=sum(a$variables$anemia),
  primary_n=nrow(a2$variables), primary_events=sum(a2$variables$anemia),
  m3_n=nrow(a3$variables), m3_events=sum(a3$variables$anemia),
  adult_sensitivity_n=nrow(adult_design$variables),
  missing_FSDAD_in_M2=sum(is.na(a2$variables$adult_food_security_category)),
  MEC_n=nrow(mec), MEC_strata=length(unique(mec$strata_id)), MEC_PSU=length(unique(mec$psu_id)),
  design_df=degf(des), smoking_rounding_changed_on_R_load=smoking_rounding_changed_on_R_load,
  model_counts=list(main=nrow(main), sensitivity=nrow(sensitivity), hemoglobin=nrow(hemoglobin),
                    subgroup=nrow(subgroups), interaction_tests=nrow(interactions), prevalence=nrow(prevalence)),
  formulas=formula_records, natural_spline_specifications=spline_records,
  main_models=main, sensitivity_models=sensitivity, hemoglobin_models=hemoglobin,
  subgroup_models=subgroups, interaction_tests=interactions, prevalence=prevalence,
  global_tests=bind_records(global_records), diagnostics=bind_records(diagnostic_records),
  conventions=list(
    model_n='Total model sample; events counts anemia cases in the stated event_definition. For Gaussian Hb models, events are descriptive clinical anemia counts, not the fitted outcome.',
    group_counts='group_n and group_events are unweighted counts within the stated exposure category in the exact model sample.',
    reference_rows='Reference OR=1; reference Hb mean difference=0; no CI or P value is assigned to a reference contrast.',
    confidence_intervals='t-based 95% Wald intervals using fitted model residual design degrees of freedom.',
    global_tests='Survey-design-adjusted joint Wald F tests of three nonreference category coefficients; interaction tests jointly test three factor-by-modifier coefficients.',
    prevalence='Survey-weighted observed prevalence, with logit confidence intervals and group design degrees of freedom; not covariate-standardized predictions.',
    subgroups='Separately fitted subgroup models. Sex omitted within sex strata; continuous linear age retained within age strata.',
    nonlinear_age_interaction='Pooled age-group interaction reported with both linear age and natural cubic spline age (3 df); subgroup models remain as explicitly specified.',
    no_trend_test='No ordinal trend test and no spline model of the four-category exposure.',
    multiplicity='Sensitivity, secondary, subgroup and interaction analyses are exploratory; P values are not multiplicity-adjusted.'),
  versions=list(R=R.version.string, survey=as.character(packageVersion('survey')), jsonlite=as.character(packageVersion('jsonlite')))
)
write_json(summary, file.path(out, 'summary.json'), pretty=TRUE, auto_unbox=TRUE, na='null', digits=12)
cat('FOUR_CATEGORY_PRIMARY_ANALYSIS_COMPLETE\n')
print(main)
print(interactions)
