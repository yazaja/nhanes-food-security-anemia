# Continuous Hb extension of the frozen two-population M2 model.
# Rscript analyze_hb.R FROZEN_MODEL_RDS OUTPUT_DIR
suppressPackageStartupMessages({library(survey);library(splines);library(jsonlite)})
args <- commandArgs(TRUE); source <- args[1]; out <- args[2]
dir.create(out, recursive=TRUE, showWarnings=FALSE)
options(survey.lonely.psu='fail')
csv <- function(x, name) write.csv(x, file.path(out,name), row.names=FALSE, na='')
prior <- readRDS(source)$model
a <- prior$survey.design
stopifnot(inherits(a,'survey.design'), nrow(a$variables)==38929,
          !anyDuplicated(a$variables$SEQN),
          sum(a$variables$ch=='cancer')==3755,
          sum(a$variables$ch=='no_cancer')==35174,
          all(is.finite(a$variables$LBXHGB)),
          all(a$variables$LBXHGB>0 & a$variables$LBXHGB<30),
          prior$rank==52, prior$df.residual==83,degf(a)==134)
a <- update(a, hb_g_L=LBXHGB*10)
v <- a$variables
stopifnot(all(v$anemia == ifelse(v$female==1,v$LBXHGB<12,v$LBXHGB<13)))
form <- update(formula(prior), hb_g_L ~ .)
warnings_seen <- character()
fit <- withCallingHandlers(svyglm(form, design=a, family=gaussian()),
  warning=function(e){warnings_seen<<-c(warnings_seen,conditionMessage(e));invokeRestart('muffleWarning')})
X <- model.matrix(fit); oldX <- model.matrix(prior)
stopifnot(identical(dimnames(X),dimnames(oldX)),
          max(abs(X-oldX))<1e-12, fit$rank==52, fit$df.residual==83,
          fit$converged, all(is.finite(coef(fit))), all(is.finite(vcov(fit))))
df <- fit$df.residual; crit <- qt(.975,df)
mm <- function(z) model.matrix(delete.response(terms(fit)),z,
                                contrasts.arg=fit$contrasts,xlev=fit$xlevels)
contrast <- function(L){
  b <- sum(L*coef(fit)); se <- sqrt(drop(L%*%vcov(fit)%*%L))
  data.frame(estimate=b,low=b-crit*se,high=b+crit*se,se=se,
             t=b/se,p=2*pt(abs(b/se),df,lower.tail=FALSE),df=df,unit='g/L')
}
make_L <- function(g,k){
  z <- v[rep(1L,2L),]
  z$ch <- factor(rep(g,2),levels=levels(v$ch))
  z$fi <- factor(c(k,1),levels=levels(v$fi))
  mx <- mm(z); mx[1,]-mx[2,]
}
within <- list(); Ls <- list(); raw <- list()
for(g in levels(v$ch)){
  for(k in levels(v$fi)){
    ad <- subset(a,ch==g & fi==k)
    m <- svymean(~hb_g_L,ad); se <- SE(m)[1]
    raw[[paste(g,k)]] <- data.frame(ch=g,fi=k,n=nrow(ad$variables),
      anemia=sum(ad$variables$anemia),mean=coef(m)[1],sd=sqrt(coef(svyvar(~hb_g_L,ad))[1]),
      low=coef(m)[1]-qt(.975,degf(ad))*se,high=coef(m)[1]+qt(.975,degf(ad))*se,
      se=se,design_df=degf(ad),unit='g/L',adjusted=FALSE)
  }
  for(k in 2:4){
    key <- paste(g,k,sep='_'); L <- make_L(g,k); Ls[[key]] <- L
    within[[key]] <- cbind(data.frame(ch=g,fi=k,n=sum(v$ch==g),
                       group_n=sum(v$ch==g & v$fi==k),reference_n=sum(v$ch==g & v$fi=='1')),
                       contrast(L))
  }
}
within <- do.call(rbind,within)
csv(within,'within_group_differences.csv')
csv(do.call(rbind,raw),'observed_Hb_by_group.csv')
interaction <- regTermTest(fit,~ch:fi,method='Wald')
IL <- do.call(rbind,lapply(2:4,function(k) Ls[[paste0('cancer_',k)]]-Ls[[paste0('no_cancer_',k)]]))
rownames(IL) <- paste0('FI',2:4)
ib <- drop(IL%*%coef(fit)); iV <- IL%*%vcov(fit)%*%t(IL)
manual_F <- drop(t(ib)%*%solve(iV,ib))/3
manual_p <- pf(manual_F,3,df,lower.tail=FALSE)
stopifnot(abs(manual_F-as.numeric(interaction$Ftest))<1e-8,
          abs(manual_p-as.numeric(interaction$p))<1e-10)
interaction_rows <- do.call(rbind,lapply(1:3,function(j)
  cbind(data.frame(fi=j+1,definition='Cancer minus no-cancer difference versus full food security'),
        contrast(IL[j,]))))
csv(interaction_rows,'interaction_contrasts.csv')
csv(data.frame(F=as.numeric(interaction$Ftest),numerator_df=interaction$df,
               denominator_df=interaction$ddf,p=interaction$p,manual_F=manual_F,manual_p=manual_p),
    'interaction_global.csv')
cc <- summary(fit)$coefficients
csv(data.frame(term=rownames(cc),estimate=cc[,1],se=cc[,2],t=cc[,3],p=cc[,4]),
    'all_coefficients.csv')
csv(data.frame(term=colnames(X),t(IL),check.names=FALSE),'interaction_contrast_matrix.csv')

# Independent point-estimate checks, without replacing the combined-model CIs.
separate_formula <- hb_g_L ~ fi+cycle+
  ns(age10,knots=c(4,6),Boundary.knots=c(2,8))+female+race+education+
  ns(pir,knots=c(1,3),Boundary.knots=c(0,5))+smoking
checks <- list()
for(g in levels(v$ch)){
  sf <- svyglm(separate_formula,design=subset(a,ch==g),family=gaussian())
  for(k in 2:4){
    b <- within$estimate[within$ch==g & within$fi==k]
    sb <- coef(sf)[paste0('fi',k)]
    checks[[paste(g,k)]] <- data.frame(ch=g,fi=k,combined=b,separate=sb,absolute_error=abs(b-sb))
  }
}
checks <- do.call(rbind,checks); stopifnot(max(checks$absolute_error)<1e-8)
direct_terms <- paste0('chcancer:fi',2:4)
stopifnot(all(direct_terms%in%names(coef(fit))),
          max(abs(coef(fit)[direct_terms]-ib))<1e-8)
csv(checks,'separate_model_point_checks.csv')

# Descriptive diagnostics only; no outcome-driven trimming or refitting.
res <- residuals(fit,type='response'); fv <- fitted(fit); w <- as.numeric(weights(a))
breaks <- unique(quantile(fv,seq(0,1,length.out=21)))
bins <- cut(fv,breaks,include.lowest=TRUE)
diag_rows <- lapply(levels(bins),function(b){
  take <- bins==b
  data.frame(bin=b,n=sum(take),fitted=weighted.mean(fv[take],w[take]),
             residual=weighted.mean(res[take],w[take]),
             residual_rms=sqrt(weighted.mean(res[take]^2,w[take])))
})
csv(do.call(rbind,diag_rows),'residual_binned.csv')
probs <- seq(.005,.995,length.out=101)
csv(data.frame(probability=probs,normal_quantile=qnorm(probs),
               residual_quantile=as.numeric(quantile(res,probs))),'residual_quantiles.csv')
pdf(file.path(out,'model_diagnostics.pdf'),width=8,height=4)
par(mfrow=c(1,2),mar=c(4,4,2,1))
dr <- do.call(rbind,diag_rows)
plot(dr$fitted,dr$residual,xlab='Fitted Hb (g/L)',ylab='Weighted mean residual (g/L)',
     pch=19,main='Residuals by fitted-value bins');abline(h=0,lty=2,col='grey40')
qqnorm(res,pch='.',main='Residual Q-Q plot',ylab='Residual (g/L)');qqline(res,col='grey40')
dev.off()
hat <- hatvalues(fit)
tmp <- tempfile(); writeLines(as.character(v$SEQN),tmp)
sample_md5 <- unname(tools::md5sum(tmp));unlink(tmp)
meta <- list(status='executed',date='2026-10-20',input=source,
  input_md5=unname(tools::md5sum(source)),sample_order_md5=sample_md5,
  formula=paste(deparse(form),collapse=' '),outcome='LBXHGB * 10 (g/L)',
  n=nrow(v),cancer_n=sum(v$ch=='cancer'),noncancer_n=sum(v$ch=='no_cancer'),
  no_additional_Hb_missing=all(is.finite(v$LBXHGB)),
  exact_original_M2_sample=TRUE,identical_original_M2_design_matrix=TRUE,
  rank=fit$rank,design_df=degf(a),residual_df=df,converged=fit$converged,
  global_interaction_F=as.numeric(interaction$Ftest),
  global_interaction_df=interaction$df,global_interaction_p=as.numeric(interaction$p),
  variance='Taylor linearization with frozen full-MEC-derived domain survey design',
  contrast_CI='Pointwise two-sided 95% t intervals with residual design df; global 3df interaction is primary',
  Hb_range_g_L=range(v$hb_g_L),Hb_quantiles_g_L=as.list(quantile(v$hb_g_L,c(0,.01,.5,.99,1))),
  residual_range_g_L=range(res),fitted_range_g_L=range(fv),
  max_weight_share=max(w)/sum(w),max_hat=max(hat),mean_hat=mean(hat),
  separate_fit_max_error=max(checks$absolute_error),
  manual_joint_Wald_agrees=TRUE,direct_interaction_coefficients_agree=TRUE,
  warnings=unique(warnings_seen),new_imputation=FALSE,standardized_absolute_means_computed=FALSE,
  outcome_based_exclusions=FALSE,exploratory=TRUE)
write_json(meta,file.path(out,'summary.json'),pretty=TRUE,auto_unbox=TRUE,digits=14)
saveRDS(list(model=fit,within=within,interaction=interaction_rows,global=interaction,
             contrasts=Ls,interaction_matrix=IL,metadata=meta),file.path(out,'hb_model.rds'))
sink(file.path(out,'R_sessionInfo.txt'));sessionInfo();sink()
cat('HB_ANALYSIS_COMPLETE\n');print(within);print(interaction_rows);print(meta)
