"""Format existing aggregate results for manuscript assembly; no model re-estimation."""
from pathlib import Path
import csv,json,argparse
ROOT=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument('--results-dir',type=Path,default=ROOT/'results')
ap.add_argument('--output-dir',type=Path)
args=ap.parse_args();R=args.results_dir;O=args.output_dir or R;O.mkdir(parents=True,exist_ok=True)
def read(n):
 with (R/n).open() as f:return list(csv.DictReader(f))
def fmt(x,digits=2):return f'{float(x):.{digits}f}'
def pval(x):
 x=float(x)
 return '<0.001' if x<.001 else f'{x:.3f}'
def est(r,key='estimate'):
 return f"{fmt(r[key])}（{fmt(r['low'])}，{fmt(r['high'])}）"
def table(headers,rows):
 return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+['| '+' | '.join(map(str,r))+' |' for r in rows])
pops={'cancer':'癌症史','no_cancer':'无癌症史'}
fi={'1':'充分食物安全','2':'边缘食物安全','3':'低食物安全','4':'极低食物安全'}
nut={'DR1TIRON':'铁（mg/d）','DR1TFDFE':'叶酸（μg DFE/d）','DR1TVB12':'维生素B12（μg/d）','DR1TPROT':'蛋白质（g/d）','DR1TKCAL':'总能量（kcal/d）'}
all_counts=read('diet_group_counts.csv')
counts={(r['ch'],r['fi']):r for r in all_counts if r['population']=='core_diet'}
def population_counts(pop):
 rows=[r for r in all_counts if r['population']==pop]
 assert len(rows)==8 and len({(r['ch'],r['fi']) for r in rows})==8
 result={g:{k:sum(int(r[k]) for r in rows if r['ch']==g) for k in ['n','anemia']} for g in ['cancer','no_cancer']}
 result['total']=sum(result[g]['n'] for g in ['cancer','no_cancer'])
 return result
core=population_counts('core_diet');model=population_counts('M2_diet')
means={(r['ch'],r['fi'],r['variable']):r for r in read('diet_weighted_means.csv') if r['population']=='core_diet'}
order=['DR1TKCAL','DR1TIRON','DR1TFDFE','DR1TVB12','DR1TPROT']
rows=[]
for g in ['cancer','no_cancer']:
 for k in ['1','2','3','4']:
  c=counts[g,k];rows.append([pops[g],fi[k],f"{int(c['n']):,}",c['anemia']]+[est(means[g,k,n],'mean') for n in order])
s13='### 表S13 不同癌症史及家庭食物安全水平的单日膳食营养素摄入\n\n'+table(['人群','家庭食物安全','n','贫血例数']+[nut[n]+'，均值（95% CI）' for n in order],rows)
s13+=f'\n\n注：描述样本为原核心人群中具有可靠第一天24小时膳食回顾及正膳食权重的{core["total"]:,}人，其中癌症史{core["cancer"]["n"]:,}人、无癌症史{core["no_cancer"]["n"]:,}人。n和贫血例数为未加权计数；均值和95% CI采用合并第一天膳食权重及复杂抽样设计估计，未作协变量调整。2003–2016年各周期使用WTDRD1×2/17.2，2017–2020年3月使用WTDRD1PP×3.2/17.2。叶酸以膳食叶酸当量（DFE）表示。摄入来源为食物和饮料，不包含膳食补充剂；单日摄入不等同于个体长期摄入或营养缺乏诊断。\n'
(O/'table_s13.md').write_text(s13)
within=read('diet_adjusted_within_differences.csv');between=read('diet_interaction_contrasts.csv');glob=read('diet_global_interactions.csv')
rows=[]
for n in list(nut)[:4]:
 for g in ['cancer','no_cancer']:
  for k in ['2','3','4']:
   r=next(x for x in within if x['variable']==n and x['ch']==g and x['fi']==k)
   rows.append([nut[n],pops[g],fi[k],r['group_n'],est(r),pval(r['p'])])
s14='### 表S14 家庭食物安全与单日营养素摄入的调整后关联及癌症史交互\n\nA. 各人群内相对于充分食物安全的调整后均值差\n\n'+table(['营养素','人群','家庭食物安全','该类别n','调整后均值差（95% CI）','P值'],rows)
rows=[]
for n in list(nut)[:4]:
 for k in ['2','3','4']:
  r=next(x for x in between if x['variable']==n and x['fi']==k)
  rows.append([nut[n],fi[k],est(r),pval(r['p'])])
s14+='\n\nB. 组间差异：癌症史组减去无癌症史组的上述均值差\n\n'+table(['营养素','家庭食物安全','组间差异（95% CI）','P值'],rows)
rows=[]
for n in list(nut)[:4]:
 r=next(x for x in glob if x['variable']==n)
 rows.append([nut[n],fmt(r['F'],3),'3，81',pval(r['p']),pval(r['p_BH_4_interactions'])])
s14+='\n\nC. 四分类家庭食物安全×癌症史总体交互检验\n\n'+table(['营养素','Wald F','分子、分母自由度','原始P值','BH-FDR校正P值'],rows)
s14+=f'\n\n注：调整模型为原M2完整病例与可靠膳食回顾的交集，共{model["total"]:,}人，其中癌症史{model["cancer"]["n"]:,}人（{model["cancer"]["anemia"]:,}例贫血）、无癌症史{model["no_cancer"]["n"]:,}人（{model["no_cancer"]["anemia"]:,}例贫血）。采用调查加权线性回归，以各营养素原始单位摄入量为结局；调整周期、年龄样条、性别、种族/族裔、教育、家庭收入贫困比样条、吸烟状态和第一天总能量（每1,000 kcal），并允许所有协变量与癌症史交互。以完整正膳食权重人群建立调查设计，再作研究人群域分析。方差采用Taylor线性化，95% CI采用模型残余自由度81的t分布；A和B为点对点区间和未经多重校正的P值，属补充分析。C中BH-FDR在预先固定的4项总体交互检验间校正。两组各自以充分食物安全为参照；B中负值表示同一食物安全等级相对于充分食物安全的摄入差在癌症史组更低。所有预定营养素和类别均予呈现，不依据显著性筛选。\n'
(O/'table_s14.md').write_text(s14)
print(json.dumps({'table_s13_rows':8,'table_s14_within_rows':24,'table_s14_between_rows':12,'table_s14_global_rows':4,'outputs':[str(O/'table_s13.md'),str(O/'table_s14.md')]},ensure_ascii=False))
