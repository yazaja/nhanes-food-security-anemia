"""Execute on shared server: public total-nutrient downloads and one-to-one linkage."""
from pathlib import Path
import hashlib,json,datetime,time
import requests,pandas as pd,numpy as np
from concurrent.futures import ThreadPoolExecutor
ROOT=Path('/opt/nhanes_workspace/age_and_dietary_analyses/diet')
for f in ['sources','results','data']: (ROOT/f).mkdir(parents=True,exist_ok=True)
releases=[(y,f'{y}-{y+1}',f'DR1TOT_{suffix}',2.0) for y,suffix in zip(range(2003,2017,2),'CDEFGHI')]+[(2017,'2017-March2020','P_DR1TOT',3.2)]
vars=['SEQN','DR1DRSTZ','DR1TKCAL','DR1TIRON','DR1TFDFE','DR1TVB12','DR1TPROT','DRDINT']
def get(row):
 y,cycle,stub,years=row
 url=f'https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/{y}/DataFiles/{stub}'
 entries={}
 for ext in ['htm','xpt']:
  p=ROOT/'sources'/f'{stub}.{ext}'
  if not p.exists():
   for attempt in range(3):
    try:
     r=requests.get(url+'.'+ext,timeout=90);r.raise_for_status()
     if ext=='xpt': assert r.content[:20]==b'HEADER RECORD*******',f'Not XPT {stub}: '+repr(r.content[:60])
     else: assert 'DR1TIRON' in r.text and 'DR1DRSTZ' in r.text,'Invalid docs'
     p.write_bytes(r.content);break
    except Exception:
     if attempt==2:raise
     time.sleep(2)
  entries[ext]={'url':url+'.'+ext,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
 d=pd.read_sas(ROOT/'sources'/f'{stub}.xpt',format='xport')
 # Restore SAS XPT zero values sometimes decoded by pandas as ~5.4e-79.
 # Apply before >0 energy/weight eligibility checks; true nutrient zeros remain valid.
 numeric=d.select_dtypes(include='number').columns
 tiny=d[numeric].notna() & d[numeric].abs().lt(1e-70)
 d[numeric]=d[numeric].mask(tiny,0.0)
 assert not d.SEQN.duplicated().any()
 weight='WTDRD1PP' if stub.startswith('P_') else 'WTDRD1'
 assert set(vars+[weight])<=set(d.columns)
 z=d[vars+[weight]].copy().rename(columns={weight:'source_diet_weight'})
 z['diet_cycle']=cycle;z['diet_duration']=years;z['diet_weight']=z.source_diet_weight*years/17.2
 entries.update({'release':stub,'cycle':cycle,'n':len(d),'weight_field':weight,'duration':years,'reliable':int((d.DR1DRSTZ==1).sum()),'positive_weight':int((d[weight]>0).sum()),'variables':vars})
 print('DOWNLOADED',stub,len(d),flush=True)
 return z,entries
parts=list(ThreadPoolExecutor(max_workers=3).map(get,releases))
z=pd.concat([p[0] for p in parts],ignore_index=True)
assert not z.SEQN.duplicated().any()
d=pd.read_csv('/opt/nhanes_workspace/analysis/data/merged_expanded.csv')
assert not d.SEQN.duplicated().any()
m=d.merge(z,on='SEQN',how='left',validate='one_to_one',indicator=True)
assert len(d)==len(m)
linked=m._merge=='both'
assert (m.loc[linked,'cycle']==m.loc[linked,'diet_cycle']).all()
assert (m.loc[linked,'cycle_duration_years']==m.loc[linked,'diet_duration']).all()
nutrients=vars[2:7]
m['diet_valid']=(m.DR1DRSTZ==1)&(m.source_diet_weight>0)&(m.DR1TKCAL>0)&m[nutrients].notna().all(axis=1)&(m[nutrients]>=0).all(axis=1)
m['ch']=np.where(m.MCQ220==1,'cancer',np.where(m.MCQ220==2,'no_cancer','unknown'))
m['core']=(m.RIDAGEYR>=20)&(m.known_pregnant==0)&(m.RIDSTATR==2)&(m.weight>0)&m.MCQ220.isin([1,2])&m.FSDHH.isin([1,2,3,4])&m.anemia.notna()
m['cc2']=m[['anemia','FSDHH','MCQ220','cycle','age10','female','race','education','pir','smoking']].notna().all(axis=1)
assert int(m.core.sum())==41972 and int((m.core&m.cc2).sum())==38929
rows=[]
for name,take in [('core',m.core),('core_diet',m.core&m.diet_valid),('M2',m.core&m.cc2),('M2_diet',m.core&m.cc2&m.diet_valid)]:
 for g in ['no_cancer','cancer']:
  for k in range(1,5):
   a=m[take&(m.ch==g)&(m.FSDHH==k)]
   rows.append({'population':name,'ch':g,'fi':k,'n':len(a),'anemia':int(a.anemia.sum()),'day2_available':int((a.DRDINT==2).sum())})
pd.DataFrame(rows).to_csv(ROOT/'results/prefit_counts.csv',index=False)
m.groupby(['cycle','diet_valid']).size().rename('n').reset_index().to_csv(ROOT/'results/prefit_cycle_counts.csv',index=False)
audit={'n_input':len(d),'n_diet_source':len(z),'n_after_merge':len(m),'duplicate_ids_input':0,'duplicate_ids_diet':0,'wrong_cycle_links':0,'linked':int(linked.sum()),'unlinked':int((~linked).sum()),'core':int(m.core.sum()),'core_diet':int((m.core&m.diet_valid).sum()),'M2':int((m.core&m.cc2).sum()),'M2_diet':int((m.core&m.cc2&m.diet_valid).sum()),'diet_valid_all':int(m.diet_valid.sum()),'diet_valid_zero_energy_excluded':int(((m.DR1DRSTZ==1)&(m.source_diet_weight>0)&(m.DR1TKCAL==0)).sum()),'weight_scale':'2/17.2 for seven 2-year cycles;3.2/17.2 for 2017-March2020','input_sha256':hashlib.sha256(Path('/opt/nhanes_workspace/analysis/data/merged_expanded.csv').read_bytes()).hexdigest()}
(ROOT/'results/merge_audit.json').write_text(json.dumps(audit,indent=2))
(ROOT/'sources/download_manifest.json').write_text(json.dumps([p[1] for p in parts],indent=2))
m.drop(columns=['_merge']).to_csv(ROOT/'data/merged_diet.csv',index=False)
print(json.dumps(audit),flush=True)
print(pd.DataFrame(rows).groupby(['population','ch'])[['n','anemia','day2_available']].sum().to_string(),flush=True)
