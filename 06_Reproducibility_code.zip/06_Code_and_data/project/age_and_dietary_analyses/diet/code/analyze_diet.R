# 2026-11-01 audited release: use with the corrected prepare_diet.py; four zero-energy observations excluded.
# Exploratory four-nutrient context, all inference executed on shared server.
suppressPackageStartupMessages({library(survey);library(splines);library(jsonlite)})
root <- '/opt/nhanes_workspace/age_and_dietary_analyses/diet'
out <- file.path(root,'results'); options(survey.lonely.psu='fail')
csv <- function(x,n)write.csv(x,file.path(out,n),row.names=FALSE,na='')
d <- read.csv(file.path(root,'data/merged_diet.csv'),stringsAsFactors=FALSE)
for(n in c('core','cc2','diet_valid')) d[[n]]<-as.logical(d[[n]])
stopifnot(!anyDuplicated(d$SEQN),sum(d$core)==41972,sum(d$core&d$cc2)==38929)
d$ch<-factor(d$ch,levels=c('no_cancer','cancer'));d$fi<-factor(d$FSDHH,levels=1:4)
d$cycle<-factor(d$cycle);d$race<-relevel(factor(d$race,levels=1:5),'3')
d$education<-factor(d$education,levels=1:3);d$smoking<-factor(d$smoking,levels=0:2)
d$energy1000 <- d$DR1TKCAL/1000
# Keep every positive Day 1 dietary weight in the design before any domain restriction.
full <- subset(d,RIDSTATR==2 & diet_weight>0 & !is.na(strata_id)&!is.na(psu_id))
des<-svydesign(ids=~psu_id,strata=~strata_id,weights=~diet_weight,nest=TRUE,data=full)
psus<-aggregate(psu_id~strata_id,full,function(x)length(unique(x)))
stopifnot(all(psus$psu_id>=2))
desc<-subset(des,core & diet_valid);a<-subset(des,core & cc2 & diet_valid)
v<-a$variables;stopifnot(nrow(v)==36588,sum(v$ch=='cancer')==3550,
  sum(v$ch=='no_cancer')==33038,all(v$DR1DRSTZ==1),all(weights(a)>0))
prior<-readRDS('/opt/nhanes_workspace/two_population_primary/results/models_and_replicates.rds')$model
pv<-prior$survey.design$variables
stopifnot(setequal(d$SEQN[d$core&d$cc2],pv$SEQN),all(v$SEQN%in%pv$SEQN))
ix<-match(v$SEQN,pv$SEQN)
for(n in c('anemia','age10','female','pir','fi','ch','cycle','race','education','smoking')){
 stopifnot(identical(as.character(v[[n]]),as.character(pv[[n]][ix])))
}
stopifnot(max(abs(v$diet_weight-v$source_diet_weight*v$cycle_duration_years/17.2))<1e-10)
nutrients<-c(DR1TIRON='iron',DR1TFDFE='folate_DFE',DR1TVB12='vitamin_B12',DR1TPROT='protein')
units<-c(DR1TIRON='mg/day',DR1TFDFE='micrograms_DFE/day',DR1TVB12='micrograms/day',DR1TPROT='g/day',DR1TKCAL='kcal/day')
means<-list();counts<-list();ranges<-list()
for(pop in c('core_diet','M2_diet')){
 ad<-if(pop=='core_diet')desc else a
 for(g in levels(v$ch))for(k in levels(v$fi)){
  sub<-subset(ad,ch==g & fi==k)
  counts[[paste(pop,g,k)]]<-data.frame(population=pop,ch=g,fi=k,n=nrow(sub$variables),anemia=sum(sub$variables$anemia),design_df=degf(sub))
  for(n in c(names(nutrients),'DR1TKCAL')){
   fit<-svymean(as.formula(paste('~',n)),sub);z<-coef(fit)[1];se<-SE(fit)[1];crit<-qt(.975,degf(sub))
   means[[paste(pop,g,k,n)]]<-data.frame(population=pop,ch=g,fi=k,variable=n,unit=units[n],n=nrow(sub$variables),mean=z,se=se,low=z-crit*se,high=z+crit*se,design_df=degf(sub))
  }
 }
}
csv(do.call(rbind,counts),'diet_group_counts.csv');csv(do.call(rbind,means),'diet_weighted_means.csv')
for(n in c(names(nutrients),'DR1TKCAL')){
 q<-quantile(v[[n]],c(0,.01,.5,.99,1));ranges[[n]]<-data.frame(variable=n,unit=units[n],min=q[1],p01=q[2],median=q[3],p99=q[4],max=q[5],zero_n=sum(v[[n]]==0),missing_n=sum(is.na(v[[n]])))
}
csv(do.call(rbind,ranges),'diet_ranges.csv')
base_rhs <- 'ch*(fi+cycle+ns(age10,knots=c(4,6),Boundary.knots=c(2,8))+female+race+education+ns(pir,knots=c(1,3),Boundary.knots=c(0,5))+smoking+energy1000)'
within<-list();between<-list();global<-list();diagnostics<-list();checks<-list();allcoef<-list();models<-list();warnings_seen<-list()
for(n in names(nutrients)){
 form<-as.formula(paste(n,'~',base_rhs));warn<-character()
 fit<-withCallingHandlers(svyglm(form,design=a,family=gaussian()),warning=function(e){warn<<-c(warn,conditionMessage(e));invokeRestart('muffleWarning')})
 stopifnot(fit$converged,fit$rank==length(coef(fit)),all(is.finite(coef(fit))),all(is.finite(vcov(fit))),fit$df.residual>0)
 df<-fit$df.residual;crit<-qt(.975,df)
 mm<-function(z)model.matrix(delete.response(terms(fit)),z,contrasts.arg=fit$contrasts,xlev=fit$xlevels)
 contrast<-function(L){b<-sum(L*coef(fit));se<-sqrt(drop(L%*%vcov(fit)%*%L));data.frame(estimate=b,low=b-crit*se,high=b+crit*se,se=se,t=b/se,p=2*pt(abs(b/se),df,lower.tail=FALSE),df=df)}
 Ls<-list()
 for(g in levels(v$ch))for(k in 2:4){
  z<-v[rep(1L,2L),];z$ch<-factor(rep(g,2),levels=levels(v$ch));z$fi<-factor(c(k,1),levels=levels(v$fi))
  mx<-mm(z);L<-mx[1,]-mx[2,];Ls[[paste(g,k,sep='_')]]<-L
  within[[paste(n,g,k)]]<-cbind(data.frame(variable=n,nutrient=nutrients[n],unit=units[n],ch=g,fi=k,n=sum(v$ch==g),group_n=sum(v$ch==g&v$fi==k)),contrast(L))
 }
 IL<-do.call(rbind,lapply(2:4,function(k)Ls[[paste0('cancer_',k)]]-Ls[[paste0('no_cancer_',k)]]))
 it<-regTermTest(fit,~ch:fi,method='Wald');ib<-drop(IL%*%coef(fit));iv<-IL%*%vcov(fit)%*%t(IL)
 manual_F<-drop(t(ib)%*%solve(iv,ib))/3
 stopifnot(abs(manual_F-as.numeric(it$Ftest))<1e-8, max(abs(ib-coef(fit)[paste0('chcancer:fi',2:4)]))<1e-8)
 for(j in 1:3)between[[paste(n,j)]]<-cbind(data.frame(variable=n,nutrient=nutrients[n],unit=units[n],fi=j+1,definition='Cancer minus no-cancer difference versus full food security'),contrast(IL[j,]))
 global[[n]]<-data.frame(variable=n,nutrient=nutrients[n],F=as.numeric(it$Ftest),numerator_df=it$df,denominator_df=it$ddf,p=as.numeric(it$p),manual_F=manual_F)
 sep_rhs<-'fi+cycle+ns(age10,knots=c(4,6),Boundary.knots=c(2,8))+female+race+education+ns(pir,knots=c(1,3),Boundary.knots=c(0,5))+smoking+energy1000'
 for(g in levels(v$ch)){
  sf<-svyglm(as.formula(paste(n,'~',sep_rhs)),design=subset(a,ch==g),family=gaussian())
  for(k in 2:4){b<-sum(Ls[[paste(g,k,sep='_')]]*coef(fit));sb<-coef(sf)[paste0('fi',k)];stopifnot(abs(b-sb)<1e-7)
   checks[[paste(n,g,k)]]<-data.frame(variable=n,ch=g,fi=k,combined=b,separate=sb,absolute_error=abs(b-sb))
  }
 }
 cc<-summary(fit)$coefficients;allcoef[[n]]<-data.frame(variable=n,term=rownames(cc),estimate=cc[,1],se=cc[,2],t=cc[,3],p=cc[,4])
 diagnostics[[n]]<-data.frame(variable=n,n=nrow(v),rank=fit$rank,design_df=degf(a),residual_df=df,converged=fit$converged,all_covariance_finite=all(is.finite(vcov(fit))),max_hat=max(hatvalues(fit)),max_weight_share=max(weights(a))/sum(weights(a)),residual_min=min(residuals(fit)),residual_max=max(residuals(fit)),warnings=paste(unique(warn),collapse='; '))
 warnings_seen[[n]]<-unique(warn);models[[n]]<-fit
}
w<-do.call(rbind,within);b<-do.call(rbind,between);g<-do.call(rbind,global)
g$p_BH_4_interactions<-p.adjust(g$p,method='BH')
csv(w,'diet_adjusted_within_differences.csv');csv(b,'diet_interaction_contrasts.csv');csv(g,'diet_global_interactions.csv');csv(do.call(rbind,checks),'diet_separate_point_checks.csv');csv(do.call(rbind,allcoef),'diet_all_coefficients.csv');csv(do.call(rbind,diagnostics),'diet_model_diagnostics.csv')
meta<-list(status='executed',date='2026-11-01',audit_correction='XPT zeros normalized before eligibility; model specification unchanged',full_positive_diet_weight_n=nrow(full),full_strata=nrow(psus),full_PSUs=sum(psus$psu_id),core_diet_n=nrow(desc$variables),core_cancer_n=sum(desc$variables$ch=='cancer'),core_no_cancer_n=sum(desc$variables$ch=='no_cancer'),M2_diet_n=nrow(v),M2_cancer_n=sum(v$ch=='cancer'),M2_cancer_anemia=sum(v$anemia[v$ch=='cancer']),M2_no_cancer_n=sum(v$ch=='no_cancer'),M2_no_cancer_anemia=sum(v$anemia[v$ch=='no_cancer']),design_df=degf(a),formula_rhs=base_rhs,original_main_data_unchanged=TRUE,exact_original_M2_subset=TRUE,weight='WTDRD1*2/17.2 or WTDRD1PP*3.2/17.2',variance='Taylor linearization; model residual df for t intervals',all_joint_Wald_and_separate_points_verified=TRUE,pointwise_CIs=TRUE,interaction_multiplicity='BH across four global tests',supplements_included=FALSE,single_day_intake=TRUE,usual_intake_or_deficiency_not_estimated=TRUE,outcome_driven_trim=FALSE,warnings=warnings_seen)
write_json(meta,file.path(out,'summary.json'),pretty=TRUE,auto_unbox=TRUE,digits=14)
saveRDS(list(models=models,metadata=meta,within=w,between=b,global=g),file.path(out,'diet_models.rds'))
sink(file.path(out,'R_sessionInfo.txt'));sessionInfo();sink()
cat('DIET_ANALYSIS_COMPLETE\n');print(meta);print(g);print(w)
