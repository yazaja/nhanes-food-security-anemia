"""Mechanical display of already computed aggregate age-sensitivity results."""
from pathlib import Path
import csv
r=Path(__file__).resolve().parents[1]/'results'
def read(name):return list(csv.DictReader((r/name).open()))
def est(x):return f"{float(x['estimate']):.2f}（{float(x['low']):.2f}至{float(x['high']):.2f}）"
def p(x):return f"{float(x):.4f}"
ages=read('age_summary.csv');balance=read('age_balance.csv');counts=read('group_counts.csv');within=read('within_group_effects.csv');ints=read('interaction_contrasts.csv');glob=read('interaction_global.csv')
labels={'1':'完全食物安全','2':'边缘食物安全','3':'低食物安全','4':'极低食物安全'}
lines=['### 表S12 共同年龄范围（40–74岁）内家庭食物安全与贫血、血红蛋白的敏感性分析','','**A. 限制年龄前后的人口与年龄分布**','','| 分析样本 | 癌症史 | 样本量 | 贫血例数 | 加权年龄，均值±SD（岁） | 年龄中位数（第5–95百分位） | 组间年龄绝对SMD |','|---|---|---:|---:|---|---|---:|']
for pop in ['original_M2','age_40_74']:
 for ch in ['cancer','no_cancer']:
  a=next(a for a in ages if a['population']==pop and a['ch']==ch);b=next(b for b in balance if b['population']==pop)
  lines.append('| '+' | '.join(['原M2完整病例' if pop=='original_M2' else '限制40–74岁','有' if ch=='cancer' else '无',f"{int(a['n']):,}",f"{int(a['anemia']):,}",f"{float(a['age_mean']):.2f}±{float(a['age_SD']):.2f}",f"{int(a['median'])}（{int(a['p05'])}–{int(a['p95'])}）",f"{float(b['absolute_SMD']):.3f}" if ch=='cancer' else ''])+' |')
lines+=['','**B. 40–74岁内各家庭食物安全类别的样本、事件与组内关联**','','| 癌症史 | 家庭食物安全 | 样本量 | 贫血例数 | 贫血OR（95% CI） | Hb差值（95% CI），g/L |','|---|---|---:|---:|---|---|']
for ch in ['cancer','no_cancer']:
 for k in ['1','2','3','4']:
  c=next(c for c in counts if c['population']=='age_40_74' and c['ch']==ch and c['fi']==k)
  cells=['1.00（参照）','0（参照）'] if k=='1' else [est(next(x for x in within if x['outcome']==o and x['ch']==ch and x['fi']==k)) for o in ['anemia','Hb']]
  lines.append('| '+' | '.join(['有' if ch=='cancer' else '无',labels[k],f"{int(c['n']):,}",f"{int(c['anemia']):,}",*cells])+' |')
lines+=['','**C. 癌症史组与无癌症史组之间的交互效应**','','| 家庭食物安全对比 | 贫血OR之比（癌症/无癌症；95% CI） | 类别交互P | Hb差值之差（癌症−无癌症；95% CI），g/L | 类别交互P |','|---|---|---:|---|---:|']
for k in ['2','3','4']:
 a=next(x for x in ints if x['outcome']=='anemia' and x['fi']==k);h=next(x for x in ints if x['outcome']=='Hb' and x['fi']==k)
 lines.append('| '+' | '.join([labels[k]+' vs 完全食物安全',est(a),p(a['p']),est(h),p(h['p'])])+' |')
lines+=['','| 总体交互检验 | Wald F | 分子/分母自由度 | P值 |','|---|---:|---|---:|']
for o in ['anemia','Hb']:
 g=next(x for x in glob if x['outcome']==o)
 lines.append('| '+' | '.join(['家庭食物安全×癌症史：'+('贫血' if o=='anemia' else 'Hb'),f"{float(g['F']):.3f}",f"{int(g['numerator_df'])}/{int(g['denominator_df'])}",p(g['p'])])+' |')
lines+=['','注：样本量及贫血例数为未加权人数，年龄统计使用原MEC调查权重。组间年龄绝对SMD为两组加权均龄差的绝对值除以两组加权年龄方差均值的平方根，不代表已实现年龄平衡。40–74岁范围由两组加权年龄第5–95百分位交集（36–76岁）内的完整五岁年龄段确定，确定范围时未查看限制后的关联结果。两个结局均使用原M2完整病例与调查域设计，保留固定年龄样条、周期、性别、种族/族裔、教育、固定PIR样条、吸烟及其与癌症史的交互。贫血采用调查加权logit模型，Hb采用调查加权线性模型；每组以完全食物安全为参照。组内OR及Hb差值、OR之比及Hb差值之差均给出点别95%置信区间。总体检验为三自由度联合Wald F检验，逐类别P值未作多重比较校正。方差使用Taylor线性化，置信区间使用残余调查自由度83的t分布。本分析未重新插补或重新计算JKn标准化患病率。','']
(r/'table_s12.md').write_text('\n'.join(lines))
print(r/'table_s12.md')
