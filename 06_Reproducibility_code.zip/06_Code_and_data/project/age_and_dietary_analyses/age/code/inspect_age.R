suppressPackageStartupMessages({library(survey);library(jsonlite)})
a<-readRDS('/opt/nhanes_workspace/two_population_primary/results/models_and_replicates.rds')$model$survey.design
v<-a$variables;w<-as.numeric(weights(a))
out<-'/opt/nhanes_workspace/age_and_dietary_analyses/age/results'
dir.create(out,recursive=TRUE,showWarnings=FALSE)
weighted_q<-function(x,w,p){s<-order(x); x<-x[s];w<-w[s]; cdf<-cumsum(w)/sum(w);vapply(p,function(q)x[which(cdf>=q)[1]],numeric(1))}
rows<-lapply(levels(v$ch),function(g){i<-v$ch==g;data.frame(ch=g,n=sum(i),mean=weighted.mean(v$RIDAGEYR[i],w[i]),sd=sqrt(sum(w[i]*(v$RIDAGEYR[i]-weighted.mean(v$RIDAGEYR[i],w[i]))^2)/sum(w[i])),p05=weighted_q(v$RIDAGEYR[i],w[i],.05),p10=weighted_q(v$RIDAGEYR[i],w[i],.1),median=weighted_q(v$RIDAGEYR[i],w[i],.5),p90=weighted_q(v$RIDAGEYR[i],w[i],.9),p95=weighted_q(v$RIDAGEYR[i],w[i],.95),min=min(v$RIDAGEYR[i]),max=max(v$RIDAGEYR[i]))})
r<-do.call(rbind,rows);write.csv(r,file.path(out,'age_distribution_before.csv'),row.names=FALSE);print(r)
v$band<-cut(v$RIDAGEYR,breaks=c(seq(20,80,5),Inf),right=FALSE)
bs<-do.call(rbind,lapply(levels(v$ch),function(g)do.call(rbind,lapply(levels(v$band),function(b){i<-v$ch==g & v$band==b;data.frame(ch=g,age_band=b,n=sum(i),weighted_percent=100*sum(w[i])/sum(w[v$ch==g]))}))))
write.csv(bs,file.path(out,'age_band_support_before.csv'),row.names=FALSE);print(bs)
print(data.frame(age_raw=sort(unique(v$RIDAGEYR)),age_model=v$age10[match(sort(unique(v$RIDAGEYR)),v$RIDAGEYR)]))
