suppressPackageStartupMessages({library(survey);library(splines);library(jsonlite)})
options(survey.lonely.psu='fail')
root<-'/opt/nhanes_workspace/age_and_dietary_analyses/age'
out<-file.path(root,'results');dir.create(out,recursive=TRUE,showWarnings=FALSE)
source<-'/opt/nhanes_workspace/two_population_primary/results/models_and_replicates.rds'
plan<-fromJSON(file.path(root,'analysis_plan.json'))
stopifnot(identical(as.integer(plan$primary_interval_inclusive),c(40L,74L)))
prior<-readRDS(source)$model
original<-prior$survey.design
stopifnot(nrow(original$variables)==38929,degf(original)==134,!anyDuplicated(original$variables$SEQN))
original<-update(original,hb_g_L=LBXHGB*10)
a<-subset(original,RIDAGEYR>=40 & RIDAGEYR<=74)
v<-a$variables
stopifnot(all(v$RIDAGEYR>=40 & v$RIDAGEYR<=74),all(v$RIDAGEYR/10==v$age10),all(v$anemia==ifelse(v$female==1,v$LBXHGB<12,v$LBXHGB<13)))
csv<-function(x,name)write.csv(x,file.path(out,name),row.names=FALSE,na='')
wq<-function(x,w,p){s<-order(x);x<-x[s];w<-w[s];cdf<-cumsum(w)/sum(w);vapply(p,function(q)x[which(cdf>=q)[1]],numeric(1))}
age_rows<-list();count_rows<-list();agebands<-list()
for(pop in c('original_M2','age_40_74')){
 ad<-if(pop=='original_M2') original else a
 x<-ad$variables;w<-as.numeric(weights(ad))
 for(g in levels(x$ch)){
  gd<-subset(ad,ch==g);i<-x$ch==g;mn<-weighted.mean(x$RIDAGEYR[i],w[i]);ageest<-svymean(~RIDAGEYR,gd);sdw<-sqrt(sum(w[i]*(x$RIDAGEYR[i]-mn)^2)/sum(w[i]))
  qs<-wq(x$RIDAGEYR[i],w[i],c(.05,.1,.5,.9,.95))
  age_rows[[paste(pop,g)]]<-data.frame(population=pop,ch=g,n=sum(i),anemia=sum(x$anemia[i]),age_mean=mn,age_SE=SE(ageest)[1],age_SD=sdw,p05=qs[1],p10=qs[2],median=qs[3],p90=qs[4],p95=qs[5],female_percent=100*weighted.mean(x$female[i],w[i]),min=min(x$RIDAGEYR[i]),max=max(x$RIDAGEYR[i]))
  for(k in levels(x$fi)){
   take<-x$ch==g & x$fi==k
   count_rows[[paste(pop,g,k)]]<-data.frame(population=pop,ch=g,fi=k,n=sum(take),anemia=sum(x$anemia[take]),nonanemia=sum(x$anemia[take]==0),weight_share_within_history=sum(w[take])/sum(w[i]),age_mean=weighted.mean(x$RIDAGEYR[take],w[take]))
  }
  for(lower in seq(20,80,5)){
   take<-i & x$RIDAGEYR>=lower & x$RIDAGEYR<lower+5
   agebands[[paste(pop,g,lower)]]<-data.frame(population=pop,ch=g,lower_age=lower,upper_age=if(lower==80)NA else lower+4,n=sum(take),percent=100*sum(w[take])/sum(w[i]))
  }
 }
}
age_rows<-do.call(rbind,age_rows);counts<-do.call(rbind,count_rows)
smd<-do.call(rbind,lapply(unique(age_rows$population),function(p){r<-age_rows[age_rows$population==p,];mca<-r$age_mean[r$ch=='cancer'];mnc<-r$age_mean[r$ch=='no_cancer'];sds<-r$age_SD;data.frame(population=p,cancer_mean=mca,noncancer_mean=mnc,mean_difference=mca-mnc,absolute_SMD=abs(mca-mnc)/sqrt(mean(sds^2)))}))
csv(age_rows,'age_summary.csv');csv(smd,'age_balance.csv');csv(counts,'group_counts.csv');csv(do.call(rbind,agebands),'age_bands_before_after.csv')
all_within<-list();all_interactions<-list();globals<-list();diags<-list();checks<-list();coefs<-list();fits<-list()
for(outcome in c('anemia','Hb')){
 form<-if(outcome=='anemia') formula(prior) else update(formula(prior),hb_g_L~.)
 fam<-if(outcome=='anemia') quasibinomial() else gaussian()
 warnings_seen<-character()
 fit<-withCallingHandlers(svyglm(form,design=a,family=fam),warning=function(e){warnings_seen<<-c(warnings_seen,conditionMessage(e));invokeRestart('muffleWarning')})
 stopifnot(isTRUE(fit$converged),fit$rank==length(coef(fit)),fit$df.residual>0,all(is.finite(coef(fit))),all(is.finite(vcov(fit))))
 mm<-function(z)model.matrix(delete.response(terms(fit)),z,contrasts.arg=fit$contrasts,xlev=fit$xlevels)
 Lof<-function(g,k){z<-v[rep(1L,2L),];z$ch<-factor(rep(g,2),levels=levels(v$ch));z$fi<-factor(c(k,1),levels=levels(v$fi));mx<-mm(z);mx[1,]-mx[2,]}
 contrast<-function(L){b<-sum(L*coef(fit));se<-sqrt(drop(L%*%vcov(fit)%*%L));crit<-qt(.975,fit$df.residual);data.frame(beta=b,se=se,estimate=if(outcome=='anemia')exp(b)else b,low=if(outcome=='anemia')exp(b-crit*se)else b-crit*se,high=if(outcome=='anemia')exp(b+crit*se)else b+crit*se,p=2*pt(abs(b/se),fit$df.residual,lower.tail=FALSE),df=fit$df.residual,unit=if(outcome=='anemia')'OR' else 'g/L')}
 Ls<-list()
 for(g in levels(v$ch))for(k in 2:4){key<-paste(g,k,sep='_');L<-Lof(g,k);Ls[[key]]<-L;all_within[[paste(outcome,key)]]<-cbind(data.frame(outcome=outcome,ch=g,fi=k,n=sum(v$ch==g),category_n=sum(v$ch==g&v$fi==k),category_events=sum(v$anemia[v$ch==g&v$fi==k]),reference_n=sum(v$ch==g&v$fi=='1')),contrast(L))}
 IL<-do.call(rbind,lapply(2:4,function(k)Ls[[paste0('cancer_',k)]]-Ls[[paste0('no_cancer_',k)]]))
 it<-regTermTest(fit,~ch:fi,method='Wald');ib<-drop(IL%*%coef(fit));iV<-IL%*%vcov(fit)%*%t(IL);mf<-drop(t(ib)%*%solve(iV,ib))/3;mp<-pf(mf,3,fit$df.residual,lower.tail=FALSE)
 stopifnot(abs(mf-as.numeric(it$Ftest))<1e-8,abs(mp-as.numeric(it$p))<1e-10,max(abs(coef(fit)[paste0('chcancer:fi',2:4)]-ib))<1e-8)
 globals[[outcome]]<-data.frame(outcome=outcome,F=as.numeric(it$Ftest),numerator_df=it$df,denominator_df=it$ddf,p=it$p,manual_F=mf,manual_p=mp)
 for(j in 1:3){r<-contrast(IL[j,]);r$unit<-if(outcome=='anemia')'Ratio of ORs (cancer/noncancer)'else'g/L difference of differences';all_interactions[[paste(outcome,j)]]<-cbind(data.frame(outcome=outcome,fi=j+1),r)}
 # The full interaction model must reproduce separately fitted population coefficients.
 sf<-if(outcome=='anemia') anemia~fi+cycle+ns(age10,knots=c(4,6),Boundary.knots=c(2,8))+female+race+education+ns(pir,knots=c(1,3),Boundary.knots=c(0,5))+smoking else hb_g_L~fi+cycle+ns(age10,knots=c(4,6),Boundary.knots=c(2,8))+female+race+education+ns(pir,knots=c(1,3),Boundary.knots=c(0,5))+smoking
 for(g in levels(v$ch)){
  separate<-svyglm(sf,design=subset(a,ch==g),family=fam)
  for(k in 2:4){b<-sum(Ls[[paste(g,k,sep='_')]]*coef(fit));sb<-coef(separate)[paste0('fi',k)];checks[[paste(outcome,g,k)]]<-data.frame(outcome=outcome,ch=g,fi=k,combined_beta=b,separate_beta=sb,absolute_error=abs(b-sb))}
 }
 cc<-summary(fit)$coefficients;coefs[[outcome]]<-data.frame(outcome=outcome,term=rownames(cc),estimate=cc[,1],se=cc[,2],statistic=cc[,3],p=cc[,4])
 diags[[outcome]]<-data.frame(outcome=outcome,n=nrow(v),events=sum(v$anemia),rank=fit$rank,coefficient_count=length(coef(fit)),design_df=degf(a),residual_df=fit$df.residual,converged=fit$converged,iterations=fit$iter,fitted_min=min(fitted(fit)),fitted_max=max(fitted(fit)),warnings=paste(unique(warnings_seen),collapse=' | '))
 fits[[outcome]]<-fit
}
within<-do.call(rbind,all_within);ints<-do.call(rbind,all_interactions);gtests<-do.call(rbind,globals);diagnostics<-do.call(rbind,diags);checks<-do.call(rbind,checks)
stopifnot(max(checks$absolute_error)<1e-6)
csv(within,'within_group_effects.csv');csv(ints,'interaction_contrasts.csv');csv(gtests,'interaction_global.csv');csv(diagnostics,'model_diagnostics.csv');csv(checks,'separate_fit_checks.csv');csv(do.call(rbind,coefs),'all_coefficients.csv')
meta<-list(status='executed',date='2026-10-20',input=source,input_md5=unname(tools::md5sum(source)),plan_md5=unname(tools::md5sum(file.path(root,'analysis_plan.json'))),primary_age_range=c(40,74),original_n=nrow(original$variables),n=nrow(v),cancer_n=sum(v$ch=='cancer'),noncancer_n=sum(v$ch=='no_cancer'),cancer_events=sum(v$anemia[v$ch=='cancer']),noncancer_events=sum(v$anemia[v$ch=='no_cancer']),age_balance=smd,global_tests=gtests,model_diagnostics=diagnostics,separate_fit_max_absolute_error=max(checks$absolute_error),manual_wald_agrees=TRUE,direct_interaction_coefficient_agrees=TRUE,original_anemia_definition_verified=TRUE,frozen_age_scaling_verified=TRUE,formula_anemia=paste(deparse(formula(fits$anemia)),collapse=' '),formula_Hb=paste(deparse(formula(fits$Hb)),collapse=' '),variance='Taylor linearization, survey domain from original full-MEC-derived M2 object; t residual df CIs',new_MI=FALSE,new_JKn=FALSE,additional_age_ranges=FALSE)
write_json(meta,file.path(out,'summary.json'),pretty=TRUE,auto_unbox=TRUE,digits=14)
saveRDS(list(models=fits,meta=meta),file.path(out,'age_models.rds'))
sink(file.path(out,'R_sessionInfo.txt'));sessionInfo();sink()
cat('AGE_ANALYSIS_COMPLETE\n');print(smd);print(counts[counts$population=='age_40_74',]);print(gtests);print(within);print(ints);print(diagnostics)
