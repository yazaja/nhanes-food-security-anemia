# Counts only. Reproduce frozen eligibility and complete-case definitions; fit no models.
args<-commandArgs(TRUE);infile<-args[1];out<-args[2]
dir.create(out,recursive=TRUE,showWarnings=FALSE)
d<-read.csv(infile,stringsAsFactors=FALSE)
stopifnot(nrow(d)==86618,!anyDuplicated(d$SEQN),sum(d$eligible)==4034)
d$ch<-factor(ifelse(d$MCQ220==1,'cancer',ifelse(d$MCQ220==2,'no_cancer',NA)),levels=c('no_cancer','cancer'))
d$fi<-factor(d$FSDHH,levels=1:4);d$cycle<-factor(d$cycle)
d$race<-factor(d$race,levels=1:5);d$education<-factor(d$education,levels=1:3);d$smoking<-factor(d$smoking,levels=0:2)
v<-c('anemia','fi','ch','cycle','age10','female','race','education','pir','smoking')
d$cc2<-complete.cases(d[,v]);d$cc3<-complete.cases(d[,c(v,'bmi','log_creatinine','diabetes')])
valid<-function(x){x[is.na(x)]<-FALSE;x}
mec<-valid(with(d,RIDSTATR==2 & weight>0 & !is.na(strata_id)&!is.na(psu_id)))
eligible<-valid(with(d,RIDAGEYR>=20 & known_pregnant==0 & RIDSTATR==2 & weight>0 & !is.na(ch)&!is.na(fi)&!is.na(anemia))) & mec
stopifnot(sum(mec)==82603,sum(eligible)==41972,sum(eligible & d$cc2)==38929,sum(eligible & d$cc3)==37695)
# The original eligibility is a simultaneous conjunction. This explicit display
# order produces mutually exclusive exclusion counts, preserving the same final IDs.
conditions<-list(
 'Full MEC design population'=mec,
 'Age at least 20 years'=valid(d$RIDAGEYR>=20),
 'Not known pregnant'=valid(d$known_pregnant==0),
 'Household food security observed'=!is.na(d$fi),
 'Hemoglobin and anemia status observed'=!is.na(d$anemia),
 'Explicit cancer history'=!is.na(d$ch),
 'Complete M2 covariates'=d$cc2,
 'Complete health covariates for common M2/M3 sample'=d$cc3)
mask<-rep(TRUE,nrow(d));flow<-list();groups<-list()
for(i in seq_along(conditions)){
 name<-names(conditions)[i];before<-sum(mask);mask<-mask & conditions[[i]]
 flow[[i]]<-data.frame(order=i,stage=name,n_before=before,n_excluded=before-sum(mask),n_remaining=sum(mask))
 if(i>=6){
  for(g in levels(d$ch)){
   take<-mask & !is.na(d$ch) & d$ch==g
   groups[[paste(i,g)]]<-data.frame(stage=name,ch=g,n=sum(take),anemia=sum(d$anemia[take]))
  }
 }
 if(i==6)stopifnot(identical(mask,eligible))
 if(i==7)stopifnot(identical(mask,eligible & d$cc2))
 if(i==8)stopifnot(identical(mask,eligible & d$cc3))
}
flow<-do.call(rbind,flow);groups<-do.call(rbind,groups)
stopifnot(flow$n_excluded[6]==41,flow$n_excluded[7]==3043,flow$n_excluded[8]==1234)
stopifnot(identical(as.integer(groups$n),c(37938L,4034L,35174L,3755L,34108L,3587L)))
stopifnot(identical(as.integer(groups$anemia),c(3620L,553L,3299L,510L,3122L,472L)))
write.csv(flow,file.path(out,'sequential_flow.csv'),row.names=FALSE)
write.csv(groups,file.path(out,'group_counts.csv'),row.names=FALSE)
stopifnot(all(!is.na(d$LBXHGB[eligible])),sum(eligible & d$ch=='cancer' & d$anemia==1 & d$fi!='1')==155)
jsonlite::write_json(list(input=infile,input_md5=unname(tools::md5sum(infile)),rows=nrow(d),status='counts_verified',all_eligible_ids_match=TRUE,all_M2_ids_match=TRUE,all_common_M2_M3_ids_match=TRUE,regressions_run=FALSE,MI_run=FALSE,JKn_run=FALSE,order_note='Eligibility was originally defined by a simultaneous conjunction; mutually exclusive exclusions are counted in the displayed order: full MEC, adult age, known pregnancy, food security, anemia, cancer history, core covariates, health covariates.'),file.path(out,'provenance.json'),pretty=TRUE,auto_unbox=TRUE)
print(flow);print(groups)
