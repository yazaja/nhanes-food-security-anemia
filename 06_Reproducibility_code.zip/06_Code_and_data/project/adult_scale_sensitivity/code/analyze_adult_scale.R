# Alternative exposure definition; original anemia outcome and M2 design.
# Rscript analyze_adult_scale.R ORIGINAL_MODEL_RDS OUTPUT_DIRECTORY
suppressPackageStartupMessages({library(survey);library(splines);library(jsonlite)})
args <- commandArgs(TRUE); source <- args[1]; out <- args[2]
dir.create(out,recursive=TRUE,showWarnings=FALSE)
options(survey.lonely.psu='fail')
csv <- function(x,name)write.csv(x,file.path(out,name),row.names=FALSE,na='')
previous_path <- file.path(out,'adjusted_OR.csv')
previous_OR <- if(file.exists(previous_path))read.csv(previous_path)else NULL
prior <- readRDS(source)$model
original <- prior$survey.design; v0 <- original$variables
stopifnot(inherits(original,'survey.design'),nrow(v0)==38929,
          !anyDuplicated(v0$SEQN),sum(v0$ch=='cancer')==3755,
          sum(v0$ch=='no_cancer')==35174,prior$rank==52,prior$df.residual==83,
          all(as.character(v0$fi)==as.character(v0$FSDHH)))
original <- update(original,adult_valid=FSDAD%in%1:4,
                   fi_household=factor(FSDHH,levels=1:4))
common <- subset(original,adult_valid)
v <- common$variables
stopifnot(nrow(v)>0,all(v$FSDAD%in%1:4),all(v$ch%in%c('cancer','no_cancer')))
miss <- list()
for(g in levels(v0$ch))for(cy in levels(v0$cycle)){
  z <- v0[v0$ch==g & v0$cycle==cy,]
  miss[[paste(g,cy)]] <- data.frame(ch=g,cycle=cy,n_original=nrow(z),
    n_valid=sum(z$FSDAD%in%1:4),n_missing=sum(is.na(z$FSDAD)),
    n_other_invalid=sum(!is.na(z$FSDAD)&!z$FSDAD%in%1:4))
}
csv(do.call(rbind,miss),'adult_scale_missingness.csv')
samples <- do.call(rbind,lapply(levels(v0$ch),function(g)
  data.frame(ch=g,n_original=sum(v0$ch==g),n_common=sum(v$ch==g),
    original_events=sum(v0$anemia[v0$ch==g]),common_events=sum(v$anemia[v$ch==g]))))
csv(samples,'sample_comparison.csv')

# Explicitly record classification changes on the common analysis sample.
common <- update(common,classification_changed=as.numeric(FSDAD!=FSDHH))
reclass <- list(); changed <- list()
for(g in levels(v$ch)){
  ad <- subset(common,ch==g); z <- ad$variables; w <- as.numeric(weights(ad))
  for(hh in 1:4)for(aa in 1:4){
    take <- z$FSDHH==hh & z$FSDAD==aa
    reclass[[paste(g,hh,aa)]] <- data.frame(ch=g,household_category=hh,
      adult_category=aa,n=sum(take),anemia=sum(z$anemia[take]),
      weighted_fraction_of_group=sum(w[take])/sum(w))
  }
  est <- svymean(~classification_changed,ad)
  changed[[g]] <- data.frame(ch=g,n=nrow(z),changed_n=sum(z$FSDHH!=z$FSDAD),
    unweighted_fraction=mean(z$FSDHH!=z$FSDAD),
    weighted_fraction=coef(est)[1],weighted_fraction_se=SE(est)[1])
}
reclass <- do.call(rbind,reclass)
csv(reclass,'reclassification_counts.csv')
csv(do.call(rbind,changed),'reclassification_summary.csv')
stopifnot(sum(reclass$n)==nrow(v),sum(reclass$anemia)==sum(v$anemia))
for(g in levels(v$ch))for(k in 1:4){
  stopifnot(sum(reclass$n[reclass$ch==g & reclass$household_category==k])==
              sum(v$ch==g & v$FSDHH==k),
            sum(reclass$n[reclass$ch==g & reclass$adult_category==k])==
              sum(v$ch==g & v$FSDAD==k))
}

adult_design <- update(common,fi=factor(FSDAD,levels=1:4))
form <- formula(prior)
warnings_seen <- character()
fit_model <- function(des){
  withCallingHandlers(svyglm(form,design=des,family=quasibinomial(),na.action=na.fail,
                            control=glm.control(epsilon=1e-12,maxit=100)),
    warning=function(e){warnings_seen<<-c(warnings_seen,conditionMessage(e));invokeRestart('muffleWarning')})
}
same_sample <- nrow(v)==nrow(v0)
household <- if(same_sample)prior else fit_model(common)
adult <- fit_model(adult_design)
fits <- list(household=household,adult=adult)
designs <- list(household=common,adult=adult_design)
stopifnot(identical(household$survey.design$variables$SEQN,adult$survey.design$variables$SEQN))
hX <- model.matrix(household); aX <- model.matrix(adult)
stopifnot(identical(dimnames(hX),dimnames(aX)))
exposure_columns <- c(paste0('fi',2:4),paste0('chcancer:fi',2:4))
other_columns <- setdiff(colnames(hX),exposure_columns)
stopifnot(max(abs(hX[,other_columns]-aX[,other_columns]))<1e-12,
          identical(household$y,adult$y),
          identical(as.numeric(weights(household$survey.design)),
                    as.numeric(weights(adult$survey.design))))

ors <- list(); rors <- list(); globals <- list(); counts <- list()
coefficients <- list(); model_diags <- list(); contrast_matrices <- list()
for(scale in names(fits)){
  fit <- fits[[scale]]; design <- designs[[scale]]; vv <- design$variables
  stopifnot(fit$converged,fit$rank==52,fit$rank==length(coef(fit)),
            fit$df.residual>0,all(is.finite(coef(fit))),all(is.finite(vcov(fit))))
  if(same_sample)stopifnot(fit$df.residual==83,degf(design)==134)
  df <- fit$df.residual; crit <- qt(.975,df)
  mm <- function(z)model.matrix(delete.response(terms(fit)),z,
                                  contrasts.arg=fit$contrasts,xlev=fit$xlevels)
  make_L <- function(g,k){
    z <- vv[rep(1L,2L),];z$ch<-factor(rep(g,2),levels=levels(vv$ch))
    z$fi<-factor(c(k,1),levels=levels(vv$fi))
    mx<-mm(z);mx[1,]-mx[2,]
  }
  contrast <- function(L){
    b<-sum(L*coef(fit));se<-sqrt(drop(L%*%vcov(fit)%*%L))
    data.frame(OR=exp(b),low=exp(b-crit*se),high=exp(b+crit*se),beta=b,se=se,
               p=2*pt(abs(b/se),df,lower.tail=FALSE),residual_df=df)
  }
  Ls <- list()
  for(g in levels(vv$ch)){
    for(k in 1:4){
      ad<-subset(design,ch==g & fi==k)
      pr<-svyciprop(~anemia,ad,method='logit',df=degf(ad));ci<-confint(pr)
      counts[[paste(scale,g,k)]]<-data.frame(scale=scale,ch=g,fi=k,
        n=nrow(ad$variables),events=sum(ad$variables$anemia),
        weighted_crude_prevalence=coef(pr)[1],low=ci[1],high=ci[2],design_df=degf(ad))
    }
    for(k in 2:4){
      key<-paste(g,k,sep='_');Ls[[key]]<-make_L(g,k)
      ors[[paste(scale,key)]]<-cbind(data.frame(scale=scale,ch=g,fi=k,
        n=sum(vv$ch==g),events=sum(vv$anemia[vv$ch==g]),
        group_n=sum(vv$ch==g & vv$fi==k),
        group_events=sum(vv$anemia[vv$ch==g & vv$fi==k])),
        contrast(Ls[[key]]))
    }
  }
  IL<-do.call(rbind,lapply(2:4,function(k)Ls[[paste0('cancer_',k)]]-Ls[[paste0('no_cancer_',k)]]))
  rownames(IL)<-paste0('FI',2:4);contrast_matrices[[scale]]<-IL
  ib<-drop(IL%*%coef(fit));iV<-IL%*%vcov(fit)%*%t(IL)
  test<-regTermTest(fit,~ch:fi,method='Wald')
  manual_F<-drop(t(ib)%*%solve(iV,ib))/3;manual_p<-pf(manual_F,3,df,lower.tail=FALSE)
  stopifnot(abs(manual_F-as.numeric(test$Ftest))<1e-8,
            abs(manual_p-as.numeric(test$p))<1e-10,
            max(abs(coef(fit)[paste0('chcancer:fi',2:4)]-ib))<1e-10)
  globals[[scale]]<-data.frame(scale=scale,F=as.numeric(test$Ftest),
    numerator_df=test$df,denominator_df=test$ddf,p=as.numeric(test$p),manual_F=manual_F,manual_p=manual_p)
  for(j in 1:3){
    row<-contrast(IL[j,]);names(row)[names(row)=='OR']<-'ratio_of_ORs'
    rors[[paste(scale,j)]]<-cbind(data.frame(scale=scale,fi=j+1,
      direction='Cancer OR divided by no-cancer OR, each versus full'),row)
  }
  cc<-summary(fit)$coefficients
  coefficients[[scale]]<-data.frame(scale=scale,term=rownames(cc),
    beta=cc[,1],se=cc[,2],t=cc[,3],p=cc[,4])
  model_diags[[scale]]<-data.frame(scale=scale,n=nrow(vv),events=sum(vv$anemia),
    rank=fit$rank,design_df=degf(design),residual_df=df,converged=fit$converged,
    min_fitted=min(fitted(fit)),max_fitted=max(fitted(fit)),
    max_abs_beta=max(abs(coef(fit))),max_se=max(sqrt(diag(vcov(fit)))))
}
ors<-do.call(rbind,ors);global_table<-do.call(rbind,globals)
csv(ors,'adjusted_OR.csv');csv(do.call(rbind,rors),'interaction_ROR.csv')
csv(global_table,'interaction_global.csv');csv(do.call(rbind,counts),'category_counts.csv')
csv(do.call(rbind,coefficients),'all_coefficients.csv')
csv(do.call(rbind,model_diags),'model_diagnostics.csv')

# Check adult within-history point estimates against separate regression fits.
sepform<-anemia~fi+cycle+ns(age10,knots=c(4,6),Boundary.knots=c(2,8))+
  female+race+education+ns(pir,knots=c(1,3),Boundary.knots=c(0,5))+smoking
checks<-list()
for(g in levels(v$ch)){
  sf<-svyglm(sepform,design=subset(adult_design,ch==g),family=quasibinomial(),
             control=glm.control(epsilon=1e-12,maxit=100))
  stopifnot(sf$converged,all(is.finite(coef(sf))))
  for(k in 2:4){
    b<-ors$beta[ors$scale=='adult' & ors$ch==g & ors$fi==k]
    sb<-coef(sf)[paste0('fi',k)]
    checks[[paste(g,k)]]<-data.frame(ch=g,fi=k,joint_beta=b,
      separate_beta=sb,absolute_error=abs(b-sb))
  }
}
checks<-do.call(rbind,checks)
csv(checks,'separate_model_point_checks.csv')
print(checks)
stopifnot(max(checks$absolute_error)<1e-8)
if(!is.null(previous_OR)){
  pc<-merge(previous_OR[,c('scale','ch','fi','beta','OR')],
            ors[,c('scale','ch','fi','beta','OR')],by=c('scale','ch','fi'),
            suffixes=c('_previous','_current'))
  pc$absolute_beta_change<-abs(pc$beta_current-pc$beta_previous)
  pc$absolute_OR_change<-abs(pc$OR_current-pc$OR_previous)
  csv(pc,'numerical_tolerance_comparison.csv')
  print(pc)
}
tmp<-tempfile();writeLines(as.character(v$SEQN),tmp)
sample_md5<-unname(tools::md5sum(tmp));unlink(tmp)
meta<-list(status='executed',date='2026-10-20',input=source,
  input_md5=unname(tools::md5sum(source)),sample_order_md5=sample_md5,
  formula=paste(deparse(form),collapse=' '),outcome='Original binary anemia',
  exposure='FSDAD official adult-referenced household food security, four unordered categories',
  original_n=nrow(v0),n=nrow(v),events=sum(v$anemia),
  cancer_n=sum(v$ch=='cancer'),noncancer_n=sum(v$ch=='no_cancer'),
  cancer_events=sum(v$anemia[v$ch=='cancer']),
  noncancer_events=sum(v$anemia[v$ch=='no_cancer']),
  excluded_missing_or_invalid_adult_scale=nrow(v0)-nrow(v),
  exact_original_M2_sample=same_sample,household_refitted_due_to_missingness=!same_sample,
  global_interaction_p_household=as.numeric(globals$household$p),
  global_interaction_p_adult=as.numeric(globals$adult$p),
  global_interaction_F_adult=as.numeric(globals$adult$F),
  residual_df_adult=adult$df.residual,rank_adult=adult$rank,design_df=degf(common),
  nonexposure_design_matrix_unchanged=TRUE,outcome_unchanged=TRUE,weights_unchanged=TRUE,
  missingness_handled='Common valid-adult-scale subset of original main M2; no expansion/imputation',
  inference='Survey Taylor variance; residual design df t intervals; pointwise CIs',
  reclassification=do.call(rbind,changed),
  separate_model_max_beta_error=max(checks$absolute_error),
  manual_joint_Wald_agrees=TRUE,direct_interaction_coefficients_agree=TRUE,
  warnings=unique(warnings_seen),new_MI=FALSE,new_standardization=FALSE,
  independent_validation=FALSE,manuscript_modified=FALSE,exploratory=TRUE)
write_json(meta,file.path(out,'summary.json'),pretty=TRUE,auto_unbox=TRUE,digits=14)
saveRDS(list(household_model=household,adult_model=adult,contrasts=contrast_matrices,
             metadata=meta),file.path(out,'adult_scale_models.rds'))
sink(file.path(out,'R_sessionInfo.txt'));sessionInfo();sink()
cat('ADULT_SCALE_COMPLETE\n');print(samples);print(do.call(rbind,changed))
print(ors);print(global_table);print(meta)
