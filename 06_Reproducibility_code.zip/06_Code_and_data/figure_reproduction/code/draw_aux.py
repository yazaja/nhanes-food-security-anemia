"""Redraw S2/S4 from frozen aggregate results; no model fitting.

The input root preserves paths relative to nhanes_workspace.
All intervals, effects, interaction tests and sample counts come from the
original CSV results. Panel numbering and estimands are retained.
"""
from pathlib import Path

import numpy as np
import pandas as pd
from matplotlib import ticker
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle

from style import INK, MUTED, NAVY, WINE, GRID, BAND, LINE
from style import save, new_figure, header


INPUTS = [
    "survivor_binary_subgroups/results/binary_subgroup_models.csv",
    "survivor_binary_subgroups/results/binary_interaction_tests.csv",
    "two_population_primary/phenotype/results/phenotype_composition_among_anemic.csv",
    "two_population_primary/phenotype/results/normocytic_vs_no_anemia_M2.csv",
]


def _rule(fig, y, x0=.045, x1=.96, color=LINE, lw=.65):
    fig.add_artist(Line2D([x0, x1], [y, y], transform=fig.transFigure,
                          color=color, lw=lw, zorder=.5))


def _band(fig, y, text, detail="", letter=None, color=INK):
    fig.add_artist(Rectangle((.045, y-.018), .915, .036,
                             transform=fig.transFigure, facecolor=BAND,
                             edgecolor="none", zorder=.6))
    label = (letter + "   " if letter else "") + text
    fig.text(.052, y, label, color=color, fontsize=8.3,
             fontweight="bold", va="center")
    if detail:
        fig.text(.948, y, detail, fontsize=7.6, color=MUTED,
                 ha="right", va="center")


def _forest_axis(fig, rect, ylim, xlim, ticks, xlabel, log=False, zero=None):
    ax = fig.add_axes(rect)
    ax.set_facecolor("none")
    ax.set_ylim(*ylim)
    if log:
        ax.set_xscale("log")
    ax.set_xlim(*xlim)
    ax.set_xticks(ticks)
    ax.xaxis.set_major_formatter(ticker.FuncFormatter(lambda x, _: f"{x:g}"))
    ax.xaxis.set_minor_locator(ticker.NullLocator())
    ax.set_yticks([])
    ax.spines[["top", "right", "left"]].set_visible(False)
    ax.spines["bottom"].set_color(LINE)
    ax.spines["bottom"].set_linewidth(.65)
    ax.tick_params(axis="x", labelsize=7.2, color=LINE, labelcolor=MUTED,
                   length=3, width=.6, pad=3)
    ax.grid(axis="x", color=GRID, linewidth=.5, zorder=0)
    if zero is not None:
        ax.axvline(zero, color="#9BA7B3", linewidth=.8,
                   linestyle=(0, (3, 3)), zorder=1)
    ax.set_xlabel(xlabel, fontsize=7.5, labelpad=5, color=INK)
    return ax


def _errorbar(ax, y, est, lo, hi, color, marker="o", fill=True):
    est, lo, hi = float(est), float(lo), float(hi)
    assert np.isfinite([est, lo, hi]).all() and lo <= est <= hi
    ax.errorbar(est, y, xerr=[[est-lo], [hi-est]], fmt=marker,
                markersize=5.4, markerfacecolor=color if fill else "white",
                markeredgecolor=color, markeredgewidth=.9,
                ecolor=color, elinewidth=1, capsize=2.4, capthick=.8,
                linestyle="none", zorder=4)


def _value(est, lo, hi, digits=2, percent=False):
    tail = "%" if percent else ""
    return f"{est:.{digits}f}{tail} ({lo:.{digits}f}–{hi:.{digits}f})"


def draw_s2(base, out):
    base, out = Path(base), Path(out)
    d = pd.read_csv(base / INPUTS[0]).set_index("model")
    interactions = pd.read_csv(base / INPUTS[1])
    models = ["subgroup_female_0", "subgroup_female_1",
              "subgroup_age65_0", "subgroup_age65_1"]
    assert set(d.index) == set(models)

    def ip(modifier, age):
        v = interactions[(interactions.modifier == modifier) &
                         (interactions.age_adjustment == age)]
        assert len(v) == 1
        return float(v.iloc[0].p_interaction)

    psex = ip("female", "linear_continuous")
    page = ip("age65", "linear_continuous")
    pspline = ip("age65", "natural_spline_df3")
    fig = new_figure(height_mm=122)
    header(fig, "Food insecurity and anemia across survivor subgroups",
           "Cancer survivors · Separate adjusted models within each subgroup")

    # The labels, counts, markers and printed estimates share exact row centres.
    bottom, height = .265, .55
    ylim = (-.55, 5.85)
    fy = lambda y: bottom + (y-ylim[0]) / (ylim[1]-ylim[0]) * height
    ax = _forest_axis(fig, [.46, bottom, .28, height], ylim, (.8, 8.5),
                      [1, 2, 4, 8], "Adjusted odds ratio (log scale)",
                      log=True, zero=1)

    for x, text, ha in [(.052, "Subgroup", "left"),
                        (.35, "Total / anemia, n", "center"),
                        (.60, "Adjusted OR", "center"),
                        (.95, "OR (95% CI)", "right")]:
        fig.text(x, .85, text, fontsize=8, fontweight="bold", color=INK,
                 ha=ha, va="center")
    _rule(fig, .832)
    _band(fig, fy(5.25), "Sex", f"Interaction P = {psex:.3f}")
    _band(fig, fy(2.25), "Age", f"Interaction P = {page:.3f}")

    for y, model, label in zip([4.35, 3.35, 1.35, .35], models,
                               ["Male", "Female", "<65 years", "≥65 years"]):
        r = d.loc[model]
        cy = fy(y)
        _rule(fig, cy-.034, color=GRID, lw=.5)
        fig.text(.066, cy, label, fontsize=8.3, va="center", color=INK)
        fig.text(.35, cy, f"{int(r.n):,} / {int(r.anemia_events):,}",
                 fontsize=8, va="center", ha="center", color=MUTED)
        _errorbar(ax, y, r.estimate, r.CI_low, r.CI_high, WINE)
        fig.text(.95, cy, _value(r.estimate, r.CI_low, r.CI_high),
                 fontsize=8, va="center", ha="right", color=INK)

    _rule(fig, .265)
    fig.text(.045, .155, "Food insecure: low / very low; reference: full / marginal food security.",
             fontsize=7.1, color=MUTED, va="center")
    fig.text(.045, .115, "Points and bars: adjusted ORs and 95% CIs. Interaction tests use pooled models.",
             fontsize=7.1, color=MUTED, va="center")
    fig.text(.045, .075, f"Age interaction with nonlinear age adjustment: P = {pspline:.3f}.",
             fontsize=7.1, color=MUTED, va="center")
    return save(fig, out, "Figure_S2")


def draw_s4(base, out):
    base, out = Path(base), Path(out)
    comp = pd.read_csv(base / INPUTS[2])
    comp = comp[(comp.population == "Descriptive") & (comp.category_code == 0)]
    comp = comp.set_index("phenotype").loc[["microcytic", "normocytic", "macrocytic"]]
    model = pd.read_csv(base / INPUTS[3])
    m = model.set_index("category_code").loc[[2, 3, 4]]
    assert list(comp.unweighted_events) == [75, 448, 30]
    assert (comp.unweighted_denominator == 553).all()
    assert np.isclose(comp.weighted_proportion.sum(), 1)
    assert model.n.sum() == 3654 and model.events.sum() == 409

    fig = new_figure(height_mm=151)
    header(fig, "Red-cell morphology and normocytic anemia",
           "Cancer survivors · Descriptive composition and adjusted associations")

    _band(fig, .855, "Red-cell morphology", "553 anemia cases", "A")
    cols = [(.052, "Phenotype", "left"), (.315, "Cases, n", "center"),
            (.585, "Weighted proportion", "center"), (.95, "% (95% CI)", "right")]
    for x, text, ha in cols:
        fig.text(x, .810, text, fontsize=8, color=INK, fontweight="bold",
                 va="center", ha=ha)
    _rule(fig, .793)
    a_bottom, a_height = .582, .202
    ylim = (-.55, 2.55)
    ay = lambda y: a_bottom + (y-ylim[0]) / (ylim[1]-ylim[0]) * a_height
    a = _forest_axis(fig, [.43, a_bottom, .30, a_height], ylim, (0, 100),
                     [0, 25, 50, 75, 100], "Weighted proportion (%)")
    for y, (name, r) in zip([2, 1, 0], comp.iterrows()):
        cy = ay(y)
        est, lo, hi = r.weighted_proportion*100, r.CI_low*100, r.CI_high*100
        _rule(fig, cy-.025, color=GRID, lw=.5)
        fig.text(.066, cy, name.capitalize(), fontsize=8.2, color=INK, va="center")
        fig.text(.315, cy, f"{int(r.unweighted_events):,}", fontsize=8,
                 color=MUTED, va="center", ha="center")
        _errorbar(a, y, est, lo, hi, NAVY, marker="s")
        fig.text(.95, cy, _value(est, lo, hi, digits=1), fontsize=8,
                 va="center", ha="right", color=INK)

    _band(fig, .475, "Normocytic anemia versus no anemia", "n = 3,654; 409 cases", "B")
    for x, text, ha in [(.052, "Food security", "left"),
                        (.315, "Total / cases, n", "center"),
                        (.585, "Adjusted OR", "center"),
                        (.95, "OR (95% CI)", "right")]:
        fig.text(x, .430, text, fontsize=8, fontweight="bold", color=INK,
                 va="center", ha=ha)
    _rule(fig, .413)
    b_bottom, b_height = .202, .202
    by = lambda y: b_bottom + (y-ylim[0]) / (ylim[1]-ylim[0]) * b_height
    b = _forest_axis(fig, [.43, b_bottom, .30, b_height], ylim, (.7, 10),
                     [1, 2, 5, 10], "Adjusted odds ratio (log scale)", log=True, zero=1)
    for y, code, label in zip([2, 1, 0], [2, 3, 4], ["Marginal", "Low", "Very low"]):
        r = m.loc[code]
        cy = by(y)
        _rule(fig, cy-.025, color=GRID, lw=.5)
        fig.text(.066, cy, label, fontsize=8.2, color=INK, va="center")
        fig.text(.315, cy, f"{int(r.n):,} / {int(r.events):,}", fontsize=8,
                 color=MUTED, va="center", ha="center")
        _errorbar(b, y, r.OR, r.CI_low, r.CI_high, WINE)
        fig.text(.95, cy, _value(r.OR, r.CI_low, r.CI_high), fontsize=8,
                 va="center", ha="right", color=INK)

    fig.text(.045, .096, "Bars show 95% CIs; counts are unweighted. Panel B: survivor-only Model 2.",
             fontsize=7.1, color=MUTED, va="center")
    fig.text(.045, .061, "Panel B excludes microcytic / macrocytic anemia; reference: full food security.",
             fontsize=7.1, color=MUTED, va="center")
    return save(fig, out, "Figure_S4")
