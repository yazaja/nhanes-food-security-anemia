"""Redraw Figures 2, 3, S1 and S3 using existing aggregate estimates only."""
import json
import numpy as np
import pandas as pd
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
from style import (INK,MUTED,NAVY,WINE,GRID,BAND,LINE,COLORS,MARKERS,NAMES,
                   new_figure,header,panel_title,forest_axis,text_axis,estimate,ci_text,save)

LEVELS={1:'Full',2:'Marginal',3:'Low',4:'Very low'}


def group_legend(fig,y=.83):
    handles=[Line2D([0],[0],marker=MARKERS[g],color=COLORS[g],linestyle='none',
                    markersize=4.5,label=NAMES[g]) for g in ['cancer','no_cancer']]
    fig.legend(handles=handles,loc='upper right',bbox_to_anchor=(.97,y),ncol=2,
               frameon=False,columnspacing=1.5,handletextpad=.4,borderaxespad=0)


def band(ax,y,label=None):
    ax.axhspan(y-.35,y+.35,color=BAND,lw=0,zorder=0)
    if label:
        ax.text(.012,y,label,transform=ax.get_yaxis_transform(),va='center',
                fontsize=8,weight='bold',color=INK)


def draw_2(base,out):
    folder=base/'two_population_primary/results'
    data=pd.read_csv(folder/'standardized_prevalence.csv')
    delta=pd.read_csv(folder/'standardized_differences.csv').set_index('term')
    summary=json.loads((folder/'comparison_summary.json').read_text())
    assert len(data)==8 and summary['n']==38929
    fig=new_figure(120)
    header(fig,'Food security and standardized anemia prevalence',
           'Cancer survivors and adults with no cancer history  |  Main model, n = 38,929')
    group_legend(fig,.859)
    axes=[fig.add_axes([.095,.305,.38,.425]),fig.add_axes([.59,.305,.375,.425])]
    for ax in axes:
        ax.spines[['top','right','left']].set_visible(False)
        ax.tick_params(axis='y',length=0,pad=4)
        ax.tick_params(axis='x',length=0,pad=6)
        ax.set_axisbelow(True);ax.grid(axis='y',color=GRID,lw=.5)
    panel_title(axes[0],'A','Standardized prevalence')
    panel_title(axes[1],'B','Difference versus full food security')
    for g,off in [('cancer',-.11),('no_cancer',.11)]:
        z=data[data.ch==g].set_index('fi').loc[[1,2,3,4]]
        v=z.estimate.to_numpy()*100
        axes[0].errorbar(np.arange(4)+off,v,
            yerr=np.vstack([v-z.low.to_numpy()*100,z.high.to_numpy()*100-v]),
            fmt=MARKERS[g],color=COLORS[g],mec='white',mew=.4,ms=5.2,
            elinewidth=1.05,capsize=2.5,capthick=.8,zorder=3)
        z=delta.loc[[f'pd_{g}_{f}' for f in [2,3,4]]]
        v=z.estimate.to_numpy()*100
        axes[1].errorbar(np.arange(3)+off,v,
            yerr=np.vstack([v-z.low.to_numpy()*100,z.high.to_numpy()*100-v]),
            fmt=MARKERS[g],color=COLORS[g],mec='white',mew=.4,ms=5.2,
            elinewidth=1.05,capsize=2.5,capthick=.8,zorder=3)
    axes[0].set(ylim=(0,38),xlim=(-.5,3.5),ylabel='Anemia prevalence (%)')
    axes[0].set_yticks([0,10,20,30])
    axes[0].set_xticks(range(4),list(LEVELS.values()))
    axes[1].set(ylim=(-3,30),xlim=(-.5,2.5),ylabel='Prevalence difference (percentage points)')
    axes[1].set_yticks([0,10,20,30])
    axes[1].axhline(0,color=LINE,ls=(0,(3,3)),lw=.8)
    axes[1].set_xticks(range(3),[LEVELS[f] for f in [2,3,4]])
    # Compact numeric rows align with the actual category positions, without
    # inserting text beside overlapping confidence intervals.
    for ax,frames,levels in [(axes[0],data,[1,2,3,4]),(axes[1],None,[2,3,4])]:
        for gi,g in enumerate(['cancer','no_cancer']):
            ax.plot(-.38,-.16-gi*.068,marker=MARKERS[g],color=COLORS[g],
                    markersize=3,linestyle='none',transform=ax.get_xaxis_transform(),clip_on=False)
            for i,f in enumerate(levels):
                value=(data[(data.ch==g)&(data.fi==f)].iloc[0].estimate
                       if frames is not None else delta.loc[f'pd_{g}_{f}','estimate'])*100
                ax.text(i,-.16-gi*.068,f'{value:.2f}',transform=ax.get_xaxis_transform(),
                        color=COLORS[g],ha='center',va='center',fontsize=7.4)
    fig.text(.035,.143,'Both groups standardized to the weighted cancer-survivor covariate distribution (n = 3,755).',
             fontsize=7.2,color=MUTED)
    fig.text(.035,.097,'Points and bars: estimates and 95% CIs. Panel B compares each level with full food security within its group.',
             fontsize=6.8,color=MUTED)
    fig.text(.035,.051,'Values below the axes are point estimates; symbols and colors follow the legend. JKn replicate-weight uncertainty.',
             fontsize=6.8,color=MUTED)
    save(fig,out,'Figure_2')


def draw_3(base,out):
    folder=base/'continuous_hemoglobin/results'
    within=pd.read_csv(folder/'within_group_differences.csv')
    between=pd.read_csv(folder/'interaction_contrasts.csv').set_index('fi')
    summary=json.loads((folder/'summary.json').read_text())
    fig=new_figure(164)
    header(fig,'Food security and hemoglobin differences',
           f"Survey-weighted main model, n = {summary['n']:,}  |  Overall interaction P = {summary['global_interaction_p']:.3f}")
    # A: grouped within-population estimates in an aligned table–forest layout.
    ylimits=(-.55,8.65);bottom=.415;height=.39
    label=text_axis(fig,[.035,bottom,.30,height],ylimits)
    graph=fig.add_axes([.35,bottom,.34,height])
    numbers=text_axis(fig,[.71,bottom,.255,height],ylimits)
    forest_axis(graph,(-7.3,1.3),[-6,-4,-2,0],ylimits)
    fig.text(.035,.841,'A  Within-group differences versus full food security',fontsize=9,weight='bold')
    numbers.text(1,9.10,'Mean difference (95% CI)',ha='right',fontsize=7.2,weight='bold')
    full=text_axis(fig,[.035,bottom,.93,height],ylimits);full.set_zorder(-1)
    for f,head_y in [(2,8),(3,5),(4,2)]:
        band(full,head_y,LEVELS[f])
        for g,yy in [('cancer',head_y-1),('no_cancer',head_y-2)]:
            z=within[(within.ch==g)&(within.fi==f)].iloc[0]
            label.text(.035,yy,NAMES[g],va='center',fontsize=7.8,color=COLORS[g])
            estimate(graph,z.estimate,z.low,z.high,yy,COLORS[g],MARKERS[g])
            numbers.text(1,yy,ci_text(z.estimate,z.low,z.high),ha='right',va='center',fontsize=7.5,color=COLORS[g])
    graph.set_xlabel('Adjusted Hb difference (g/L)',labelpad=5)
    # B: interaction contrasts, with their original pointwise intervals.
    ylimits=(-.5,2.5);bottom=.155;height=.135
    label=text_axis(fig,[.035,bottom,.30,height],ylimits)
    graph=fig.add_axes([.35,bottom,.34,height])
    numbers=text_axis(fig,[.71,bottom,.255,height],ylimits)
    forest_axis(graph,(-7.3,1.3),[-6,-4,-2,0],ylimits)
    fig.text(.035,.338,'B  Between-group difference in the within-group differences',fontsize=9,weight='bold')
    fig.text(.035,.313,'Cancer survivors minus adults with no cancer history',fontsize=7.3,color=MUTED)
    for f,yy in [(2,2),(3,1),(4,0)]:
        z=between.loc[f]
        label.text(.035,yy,LEVELS[f],va='center',fontsize=8)
        estimate(graph,z.estimate,z.low,z.high,yy,INK,'D',hollow=True)
        numbers.text(1,yy,ci_text(z.estimate,z.low,z.high),ha='right',va='center',fontsize=7.5)
    graph.set_xlabel('Difference in Hb differences (g/L)',labelpad=5)
    fig.text(.035,.061,'Cancer survivors: n = 3,755; no cancer history: n = 35,174. Dashed lines indicate no difference.',fontsize=7,color=MUTED)
    fig.text(.035,.031,'Pointwise 95% CIs from the complex-survey model (Taylor linearization; residual df = 83).',fontsize=7,color=MUTED)
    save(fig,out,'Figure_3')


def model_forest_table(fig, rows, groups, plot_bottom, plot_height, ylim,
                       left_header, value_header='OR (95% CI)'):
    """Two equally scaled forest columns with right-aligned numeric estimates."""
    label=text_axis(fig,[.035,plot_bottom,.22,plot_height],ylim)
    axes=[];numbers=[]
    for xpos,npos in [(.28,.475),(.64,.835)]:
        ax=fig.add_axes([xpos,plot_bottom,.18,plot_height])
        forest_axis(ax,(.6,10),[1,2,4,8],ylim,reference=1,log=True)
        ax.set_xlabel('Odds ratio (log scale)',fontsize=7.2,labelpad=6)
        axes.append(ax)
        numbers.append(text_axis(fig,[npos,plot_bottom,.13,plot_height],ylim))
    back=text_axis(fig,[.035,plot_bottom,.93,plot_height],ylim);back.set_zorder(-1)
    label.text(0,1.04,left_header,transform=label.transAxes,weight='bold',fontsize=8)
    for j,g in enumerate(groups):
        axes[j].text(0,1.10,('A  ' if j==0 else 'B  ')+NAMES[g],
                     transform=axes[j].transAxes,weight='bold',color=COLORS[g],fontsize=8.6)
        numbers[j].text(1,1.04,value_header,transform=numbers[j].transAxes,ha='right',weight='bold',fontsize=7.2)
    for item in rows:
        if item['kind']=='band':
            band(back,item['y'],item['text'])
        else:
            label.text(.035,item['y'],item['label'],va='center',fontsize=7.3,color=MUTED)
            for j,g in enumerate(groups):
                z=item['data'][g]
                estimate(axes[j],z.OR,z.low,z.high,item['y'],COLORS[g],item['marker'],item.get('hollow',False),4.6)
                # Compact interval typography matches the reference forest tables.
                v=f'{z.OR:.2f} ({z.low:.2f}–{z.high:.2f})'
                numbers[j].text(1,item['y'],v,ha='right',va='center',fontsize=7,color=INK)
    return axes


def draw_s1(base,out):
    folder=base/'health_and_mi_analyses/cc_sensitivity/results'
    data=pd.read_csv(folder/'conditional_OR.csv')
    interactions=pd.read_csv(folder/'interaction.csv').set_index('model')
    fig=new_figure(155)
    header(fig,'Sensitivity to health adjustment and complete-case selection',
           'Four-category food security  |  Reference: full food security  |  Adjusted odds ratios for anemia')
    rows=[]
    for f,h in [(2,11),(3,7),(4,3)]:
        rows.append({'kind':'band','y':h,'text':LEVELS[f]})
        for j,(model,label,mk,hollow) in enumerate([
            ('M2_all','M2 · all complete cases','o',True),
            ('M2_same','M2 · common sample','s',False),
            ('M3_same','M3 · common sample','^',False)]):
            rows.append({'kind':'data','y':h-j-1,'label':label,'marker':mk,'hollow':hollow,
                'data':{g:data[(data.model==model)&(data.ch==g)&(data.fi==f)].iloc[0] for g in ['cancer','no_cancer']}})
    model_forest_table(fig,rows,['cancer','no_cancer'],.205,.585,(-.65,11.65),'Food security / model')
    fig.text(.035,.115,'M2 all: n = 38,929. Common complete-case sample: n = 37,695. Bars show 95% CIs.',fontsize=7,color=MUTED)
    fig.text(.035,.081,'M3 adds BMI, log-transformed calibrated creatinine and diabetes to M2. Dashed lines indicate OR = 1.',fontsize=7,color=MUTED)
    fig.text(.035,.047,'Food security × cancer history interaction: P < 0.00001 in all three models.',fontsize=7,color=MUTED)
    assert (interactions['p']<.00001).all() if 'p' in interactions else True
    save(fig,out,'Figure_S1')


def draw_s3(base,out):
    folder=base/'adult_scale_sensitivity/results'
    data=pd.read_csv(folder/'adjusted_OR.csv')
    summary=json.loads((folder/'summary.json').read_text())
    assert summary['n']==38929 and summary['exact_original_M2_sample']
    fig=new_figure(136)
    header(fig,'Household and adult food-security scales',
           'Same participants and adjustment set  |  Reference: full food security  |  n = 38,929')
    rows=[]
    for f,h in [(2,8),(3,5),(4,2)]:
        rows.append({'kind':'band','y':h,'text':LEVELS[f]})
        for j,(scale,label,mk,hollow) in enumerate([
            ('household','Household scale','o',True),('adult','Adult 10-item scale','s',False)]):
            rows.append({'kind':'data','y':h-j-1,'label':label,'marker':mk,'hollow':hollow,
                'data':{g:data[(data.scale==scale)&(data.ch==g)&(data.fi==f)].iloc[0] for g in ['no_cancer','cancer']}})
    model_forest_table(fig,rows,['no_cancer','cancer'],.225,.555,(-.65,8.65),'Food security / scale')
    fig.text(.035,.126,r'Overall interaction: household scale $P = 5.91\times10^{-6}$; adult 10-item scale $P = 2.65\times10^{-5}$.',fontsize=7.3,color=MUTED)
    fig.text(.035,.085,'Cancer survivors: n = 3,755; no cancer history: n = 35,174. Bars show pointwise 95% CIs.',fontsize=7,color=MUTED)
    fig.text(.035,.044,'Survey-weighted M2 for both scales. Dashed lines indicate OR = 1; both panels use the same logarithmic scale.',fontsize=7,color=MUTED)
    save(fig,out,'Figure_S3')
