"""Traditional participant flow using verified sequential counts; no model fitting."""
from pathlib import Path
import csv
from matplotlib.patches import Rectangle
from style import save,new_figure

def draw_flow(base,out):
    base,out=Path(base),Path(out)
    source=base/'selection_flow'
    with (source/'sequential_flow.csv').open() as f:flow=list(csv.DictReader(f))
    with (source/'group_counts.csv').open() as f:groups=list(csv.DictReader(f))
    for row in flow:
        for k in ['order','n_before','n_excluded','n_remaining']:row[k]=int(row[k])
        assert row['n_before']-row['n_excluded']==row['n_remaining']
    assert [r['n_remaining'] for r in flow]==[82603,46206,45258,44166,42013,41972,38929,37695]
    def n(i,key='n_remaining'):return f"{flow[i-1][key]:,}"
    def group(stage,history):
        r=next(x for x in groups if x['stage']==flow[stage-1]['stage'] and x['ch']==history)
        return f"n = {int(r['n']):,}; anemia: {int(r['anemia']):,}"
    fig=new_figure(220,width_mm=180)
    ax=fig.add_axes([0,0,1,1]);ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
    ink='#222222';boxes=[]
    def node(x,y,w,h,text,size=8.1):
        patch=Rectangle((x-w/2,y-h/2),w,h,linewidth=.65,edgecolor=ink,facecolor='white',zorder=2)
        ax.add_patch(patch)
        label=ax.text(x,y,text,ha='center',va='center',fontsize=size,color=ink,linespacing=1.4,zorder=3)
        boxes.append((patch,label))
    def arrow(x1,y1,x2,y2):
        ax.annotate('',xy=(x2,y2),xytext=(x1,y1),arrowprops={'arrowstyle':'-|>','mutation_scale':8,'linewidth':.65,'color':ink,'shrinkA':1.5,'shrinkB':1.5},zorder=1)
    x=.32;w=.56;right=.81;rw=.32
    node(x,.94,w,.075,'NHANES 2003–March 2020\n'+f"Interviewed participants: n = {n(1,'n_before')}")
    arrow(x,.9025,x,.8275)
    node(right,.865,rw,.067,'Outside full MEC design\n'+f"n = {n(1,'n_excluded')}",7.6)
    arrow(x,.865,right-rw/2,.865)
    node(x,.79,w,.075,'Full MEC survey-design population\n'+f'n = {n(1)}')
    arrow(x,.7525,x,.56)
    excluded='Excluded in the order shown\n\n'+ '\n'.join([
        f"Age <20 years: {n(2,'n_excluded')}",
        f"Known pregnancy: {n(3,'n_excluded')}",
        f"Missing food security: {n(4,'n_excluded')}",
        f"Missing anemia status: {n(5,'n_excluded')}",
        f"Unknown cancer history: {n(6,'n_excluded')}"])
    node(right,.655,rw,.195,excluded,7.5);arrow(x,.655,right-rw/2,.655)
    node(x,.50,w,.12,'Eligible descriptive / MI sample\n'+f'n = {n(6)}\n'+
         'Cancer survivors: '+group(6,'cancer')+'\n'+'No cancer history: '+group(6,'no_cancer'),7.8)
    arrow(x,.44,x,.35)
    node(right,.395,rw,.075,'Missing core covariates\n'+f"n = {n(7,'n_excluded')}",7.6);arrow(x,.395,right-rw/2,.395)
    node(x,.29,w,.12,'Primary M2 complete-case sample\n'+f'n = {n(7)}\n'+
         'Cancer survivors: '+group(7,'cancer')+'\n'+'No cancer history: '+group(7,'no_cancer'),7.8)
    arrow(x,.23,x,.15)
    node(right,.19,rw,.075,'Missing health covariates\n'+f"n = {n(8,'n_excluded')}",7.6);arrow(x,.19,right-rw/2,.19)
    node(x,.09,w,.12,'Common M2/M3 complete-case sample\n'+f'n = {n(8)}\n'+
         'Cancer survivors: '+group(8,'cancer')+'\n'+'No cancer history: '+group(8,'no_cancer'),7.8)
    ax.text(.5,.012,'All counts are unweighted. MEC, mobile examination center; MI, multiple imputation.',
            fontsize=7,ha='center',va='center',color=ink)
    fig.canvas.draw();renderer=fig.canvas.get_renderer()
    for patch,label in boxes:
        p=patch.get_window_extent(renderer);t=label.get_window_extent(renderer)
        assert p.x0<t.x0 and t.x1<p.x1 and p.y0<t.y0 and t.y1<p.y1,label.get_text()
    return save(fig,out,'Figure_1')
