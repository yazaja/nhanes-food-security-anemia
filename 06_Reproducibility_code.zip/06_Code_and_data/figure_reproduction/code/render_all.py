"""Render the seven current submission figures from frozen aggregate results.

This entrypoint replaces the 27 October figure list without fitting models.
"""
from pathlib import Path
import argparse, hashlib, json, shutil, subprocess, sys, tempfile
from PIL import Image,ImageDraw
try:
    from pypdf import PdfWriter
except ImportError:
    PdfWriter=None
import style
from draw_flow import draw_flow
from draw_core import draw_2,draw_3
from draw_aux import draw_s2,draw_s4

NAMES=['Figure_1','Figure_2','Figure_3','Figure_4','Figure_5','Figure_S1','Figure_S2']
SUFFIXES=['.pdf','.svg','.png','.tiff','_preview.png']

def overview(out):
    tw,th,gap=650,650,30
    board=Image.new('RGB',(3*tw+4*gap,3*th+4*gap),(239,242,245))
    draw=ImageDraw.Draw(board)
    for i,name in enumerate(NAMES):
        with Image.open(out/f'{name}_preview.png') as im:
            tile=im.convert('RGB');tile.thumbnail((tw,th-32))
            x=gap+(i%3)*(tw+gap);y=gap+(i//3)*(th+gap)
            draw.text((x+6,y+6),name,fill=(37,45,54))
            board.paste(tile,(x+(tw-tile.width)//2,y+30))
    board.save(out/'All_figures_preview.png')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    ap.add_argument('--extension-root',type=Path,help='Defaults to ../figure_extension beside --root')
    args=ap.parse_args();root=args.root.resolve()
    extension=(args.extension_root or root.parent/'figure_extension').resolve()
    for module,script in [('nutrients','draw_nutrients.py'),('sensitivity','render_figure5.py')]:
        assert (extension/module/'code'/script).is_file(),str(extension/module)
    out=root/'figures';out.mkdir(parents=True,exist_ok=True)
    font=style.apply_style();style.PORTFOLIO=None
    style.FILES.clear();style.QA.clear()
    # Staging avoids old/new S2 name collisions and stale supplemental figures.
    with tempfile.TemporaryDirectory(prefix='current_figures_',dir=root) as temp:
        work=Path(temp)
        for func in [draw_flow,draw_2,draw_3]:
            func(root/'data',work);print('Rendered',func.__name__,flush=True)
        for func,old,new in [(draw_s2,'Figure_S2','Figure_S1'),(draw_s4,'Figure_S4','Figure_S2')]:
            func(root/'data',work)
            for suffix in SUFFIXES:(work/(old+suffix)).replace(work/(new+suffix))
            for q in style.QA:
                if q['figure']==old:q['figure']=new
            print(f'Rendered {new} from retained {old}',flush=True)
        extra_qa={}
        for module,script,name in [('nutrients','draw_nutrients.py','Figure_4'),('sensitivity','render_figure5.py','Figure_5')]:
            module_root=extension/module
            subprocess.run([sys.executable,str(module_root/'code'/script),'--root',str(module_root)],check=True)
            for suffix in SUFFIXES:shutil.copy2(module_root/'figures'/(name+suffix),work/(name+suffix))
            extra_qa[name]=json.loads((module_root/'render_qa.json').read_text())
        assert {p.stem for p in work.glob('Figure_*.pdf')}==set(NAMES)
        assert not any(q['text_outside_canvas'] for q in style.QA)
        for name in NAMES:
            for suffix in SUFFIXES:shutil.copy2(work/(name+suffix),out/(name+suffix))
    for stale in ['Figure_S3','Figure_S4']:
        for suffix in SUFFIXES:
            p=out/(stale+suffix)
            if p.exists():p.unlink()
    combined=False
    if PdfWriter is not None:
        writer=PdfWriter()
        for name in NAMES:writer.append(str(out/(name+'.pdf')))
        with (out/'All_figures.pdf').open('wb') as f:writer.write(f)
        writer.close();combined=True
    else:
        if (out/'All_figures.pdf').exists():(out/'All_figures.pdf').unlink()
        print('Seven individual PDFs rendered. Install optional pypdf to also combine All_figures.pdf.',flush=True)
    overview(out)
    records=[]
    for p in sorted(out.iterdir()):
        if p.is_file() and p.name!='figure_manifest.json':
            records.append({'file':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
    manifest={'date':'2026-11-06','revision':'post-review','font':font,'figure_order':NAMES,
              'rendering':'Frozen aggregate results; no model refitting',
              'renumbering':{'old_Figure_S2':'Figure_S1','old_Figure_S4':'Figure_S2'},
              'replaced_by_Figure_5':['old_Figure_S1','old_Figure_S3'],
              'palette':{'cancer':style.WINE,'no_cancer':style.NAVY},
              'combined_pdf_created':combined,'outputs':records,'retained_layout_checks':style.QA,'extension_layout_checks':extra_qa}
    (out/'figure_manifest.json').write_text(json.dumps(manifest,indent=2))
    print(json.dumps({'figures':7,'font':font,'current_order':NAMES,'all_figures_pdf_pages':7 if combined else None}),flush=True)

if __name__=='__main__':main()
