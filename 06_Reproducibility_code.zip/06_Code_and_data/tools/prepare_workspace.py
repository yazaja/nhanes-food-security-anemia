"""Stage unchanged analysis sources and substitute only the original root path.

No datasets are downloaded and no statistical model is run by this helper.
"""
from pathlib import Path
import argparse
import hashlib
import json
import shutil

PACKAGE = Path(__file__).resolve().parents[1]
OLD_ROOT = '/opt/nhanes_workspace'

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--work-root', type=Path, required=True)
    a = p.parse_args()
    root = a.work_root.expanduser().resolve()
    if root.exists() and any(root.iterdir()):
        p.error('Use a new or empty directory to preserve existing outputs.')
    if "'" in str(root) or '\\' in str(root):
        p.error('Use a POSIX path without apostrophes or backslashes.')
    root.mkdir(parents=True, exist_ok=True)
    changes = []
    for src in sorted((PACKAGE/'project').rglob('*')):
        if not src.is_file() or 'results' in src.relative_to(PACKAGE/'project').parts:
            continue
        dest = root/src.relative_to(PACKAGE/'project')
        dest.parent.mkdir(parents=True, exist_ok=True)
        original = src.read_bytes()
        text = original.decode('utf-8')
        updated = text.replace(OLD_ROOT, str(root)).encode('utf-8')
        dest.write_bytes(updated)
        changes.append({'file': str(dest.relative_to(root)),
                        'source_sha256': hashlib.sha256(original).hexdigest(),
                        'staged_sha256': hashlib.sha256(updated).hexdigest(),
                        'root_substitutions': text.count(OLD_ROOT)})
    for rel in ['analysis', 'age_and_dietary_analyses/diet/results']:
        (root/rel).mkdir(parents=True, exist_ok=True)
    (root/'path_substitution_manifest.json').write_text(json.dumps(changes,indent=2))
    print(root)
    print('Only sources/configuration staged. No analysis executed.')

if __name__ == '__main__':
    main()
