"""Stage immutable aggregate inputs for Figure 5; no statistical estimation."""
from pathlib import Path
import argparse, hashlib, json, shutil

FILES = [
    'two_population_primary/results/conditional_OR.csv',
    'two_population_primary/results/interaction.csv',
    'two_population_primary/results/comparison_summary.json',
    'health_and_mi_analyses/cc_sensitivity/results/conditional_OR.csv',
    'health_and_mi_analyses/cc_sensitivity/results/interaction.csv',
    'health_and_mi_analyses/cc_sensitivity/results/summary.json',
    'health_and_mi_analyses/mi/pooled_OR.csv',
    'health_and_mi_analyses/mi/pooled_interaction.csv',
    'health_and_mi_analyses/mi/results_summary.json',
    'adult_scale_sensitivity/results/adjusted_OR.csv',
    'adult_scale_sensitivity/results/interaction_global.csv',
    'adult_scale_sensitivity/results/summary.json',
    'age_and_dietary_analyses/age/results/within_group_effects.csv',
    'age_and_dietary_analyses/age/results/interaction_global.csv',
    'age_and_dietary_analyses/age/results/summary.json',
]

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--source',type=Path,required=True)
    ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    args=ap.parse_args()
    manifest=[]
    for rel in FILES:
        src=args.source/rel
        dst=args.root/'data'/rel
        dst.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(src,dst)
        digest=hashlib.sha256(src.read_bytes()).hexdigest()
        assert digest==hashlib.sha256(dst.read_bytes()).hexdigest()
        manifest.append({'file':str(dst.relative_to(args.root)), 'source':str(src.resolve()),
                         'bytes':dst.stat().st_size,'sha256':digest})
    (args.root/'source_manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False))
    print(f'Staged {len(manifest)} frozen aggregate files.')

if __name__=='__main__':main()
