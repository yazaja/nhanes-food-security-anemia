"""Render frozen OR estimates without refitting any statistical model.

Run: python code/render_figure5.py --root .
Inputs are immutable aggregate CSV files copied by prepare_sources.py.
"""
from pathlib import Path
import argparse, hashlib, json, platform
import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.text import Text
from PIL import Image
import style

ROWS = [
    ('main_m2','Main analysis',38929,'M2','household',8.2),
    ('common_m2','Common complete cases',37695,'M2','household',7.0),
    ('adult_m2','Adult 10-item scale',38929,'M2','adult',5.8),
    ('age_m2','Ages 40–74 years',21964,'M2','household',4.6),
    ('mi_m2','Multiple imputation',41972,'M2','household',3.4),
    ('common_m3','Common complete cases',37695,'M3','household',1.3),
    ('mi_m3','Multiple imputation',41972,'M3','household',0.1),
]

def read(root, rel):
    return pd.read_csv(root/'data'/rel, float_precision='round_trip')

def tidy(root):
    main='two_population_primary/results/'
    cc='health_and_mi_analyses/cc_sensitivity/results/'
    mi='health_and_mi_analyses/mi/'
    adult='adult_scale_sensitivity/results/'
    age='age_and_dietary_analyses/age/results/'
    inputs={
        'main_m2':(read(root,main+'conditional_OR.csv'),read(root,main+'interaction.csv').iloc[0]['p'],main+'conditional_OR.csv'),
    }
    d=read(root,cc+'conditional_OR.csv'); p=read(root,cc+'interaction.csv').set_index('model')['p']
    for key,model in [('common_m2','M2_same'),('common_m3','M3_same')]:
        inputs[key]=(d[d.model==model].copy(),p[model],cc+'conditional_OR.csv')
    d=read(root,adult+'adjusted_OR.csv');p=read(root,adult+'interaction_global.csv')
    inputs['adult_m2']=(d[d.scale=='adult'].copy(),p.loc[p.scale=='adult','p'].iloc[0],adult+'adjusted_OR.csv')
    d=read(root,age+'within_group_effects.csv');p=read(root,age+'interaction_global.csv')
    inputs['age_m2']=(d[d.outcome=='anemia'].rename(columns={'estimate':'OR'}).copy(),p.loc[p.outcome=='anemia','p'].iloc[0],age+'within_group_effects.csv')
    d=read(root,mi+'pooled_OR.csv').rename(columns={'lower':'low','upper':'high'});p=read(root,mi+'pooled_interaction.csv').set_index('model')['p']
    for key,model in [('mi_m2','M2'),('mi_m3','M3')]:
        inputs[key]=(d[d.model==model].copy(),p[model],mi+'pooled_OR.csv')
    frames=[]
    for key,label,n,model,scale,y in ROWS:
        df,interaction,source=inputs[key]
        assert len(df)==6 and set(df.ch)=={'cancer','no_cancer'} and set(df.fi)=={2,3,4}
        assert not df.duplicated(['ch','fi']).any()
        df=df[['ch','fi','OR','low','high','p']].copy()
        assert df[['OR','low','high','p']].notna().all().all()
        assert ((df.low>0)&(df.low<=df.OR)&(df.OR<=df.high)).all()
        df.insert(0,'analysis',key);df['label']=label;df['total_n']=n;df['adjustment']=model
        df['exposure_scale']=scale;df['global_interaction_p']=interaction;df['source_file']='data/'+source
        frames.append(df)
    data=pd.concat(frames,ignore_index=True)
    assert len(data)==42
    data.to_csv(root/'plotted_source.csv',index=False,float_format='%.17g')
    return data

def p_label(p):
    if p>=.001:return f'{p:.4f}'
    exponent=int(np.floor(np.log10(p)));mantissa=p/(10**exponent)
    return rf'${mantissa:.2f}\times10^{{{exponent}}}$'

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);args=ap.parse_args()
    root=args.root.resolve();out=root/'figures';out.mkdir(parents=True,exist_ok=True)
    data=tidy(root)
    font=style.apply_style()
    fig=style.new_figure(174)
    style.header(fig,'Sensitivity of food security–anemia associations',
                 'Adjusted odds ratios by cancer history  |  Reference: full food security within each population')
    handles=[Line2D([0],[0],marker=style.MARKERS[g],color=style.COLORS[g],linestyle='none',
             markersize=4.4,label=style.NAMES[g]) for g in ['cancer','no_cancer']]
    fig.legend(handles=handles,loc='upper right',bbox_to_anchor=(.967,.869),ncol=2,
               frameon=False,columnspacing=1.7,handletextpad=.4,borderaxespad=0)

    ylim=(-.65,9.1);bottom=.215;height=.575
    label=style.text_axis(fig,[.035,bottom,.283,height],ylim)
    pall=style.text_axis(fig,[.886,bottom,.08,height],ylim)
    xs=[.335,.52,.705];width=.16
    axes=[fig.add_axes([x,bottom,width,height]) for x in xs]
    for i,ax in enumerate(axes):
        style.forest_axis(ax,(.72,10.0),[1,2,4,8],ylim,reference=1,log=True)
        ax.tick_params(axis='x',labelsize=7.2)
        style.panel_title(ax,'ABC'[i],['Marginal','Low','Very low'][i])
    fig.text(.035,.812,'Analysis / sample',fontsize=8,weight='bold')
    fig.text(.967,.812,'Interaction P',fontsize=6.6,weight='bold',ha='right')
    # Shared bands delimit the two adjustment levels without implying identical samples.
    bg=style.text_axis(fig,[.035,bottom,.932,height],ylim);bg.set_zorder(-1)
    for y,title in [(8.9,'M2 · Main covariate adjustment'),(2.05,'M3 · M2 plus clinical health covariates')]:
        bg.axhspan(y-.20,y+.20,color=style.BAND,lw=0,zorder=0)
        bg.text(.008,y,title,va='center',fontsize=7.2,weight='bold')

    for key,lab,n,model,scale,y in ROWS:
        label.text(0,y+.10,lab,fontsize=7.4,va='center',weight='bold' if key=='main_m2' else 'normal')
        label.text(0,y-.29,f'n = {n:,}'+('  ·  20 imputations' if key.startswith('mi') else ''),
                   fontsize=6.3,va='center',color=style.MUTED)
        section=data[data.analysis==key]
        pall.text(1,y,p_label(float(section.global_interaction_p.iloc[0])),ha='right',va='center',fontsize=6.5)
        for f,ax in zip([2,3,4],axes):
            for g,off in [('cancer',.17),('no_cancer',-.17)]:
                z=section[(section.fi==f)&(section.ch==g)].iloc[0]
                style.estimate(ax,z.OR,z.low,z.high,y+off,style.COLORS[g],style.MARKERS[g],size=4.3)

    fig.text(.598,.153,'Odds ratio (log scale)',ha='center',fontsize=8)
    fig.text(.035,.107,'Points and bars: odds ratios and 95% CIs. Dashed lines indicate OR = 1.',fontsize=7,color=style.MUTED)
    fig.text(.035,.073,'M3 adds BMI, log-transformed calibrated creatinine and diabetes. Adult-scale exposure differs from other rows.',fontsize=6.7,color=style.MUTED)
    fig.text(.035,.039,'Interaction P: joint three-contrast Wald test; pooled D1 test for multiple imputation. Details: Tables S7, S9, S11 and S12.',fontsize=6.4,color=style.MUTED)
    fig.canvas.draw()
    renderer=fig.canvas.get_renderer()
    outside=[]
    for a in fig.findobj(match=Text):
        if a.get_visible() and a.get_text().strip():
            b=a.get_window_extent(renderer)
            if b.x0 < -.5 or b.y0 < -.5 or b.x1>fig.bbox.width+.5 or b.y1>fig.bbox.height+.5:outside.append(a.get_text())
    assert not outside,outside
    meta=[]
    for ext in ['pdf','svg','png','tiff']:
        path=out/f'Figure_5.{ext}'
        opts={'pil_kwargs':{'compression':'tiff_lzw'}} if ext=='tiff' else {}
        fig.savefig(path,dpi=600,**opts)
        if ext=='tiff':
            with Image.open(path) as im:
                if im.mode=='RGBA':
                    assert im.getchannel('A').getextrema()==(255,255)
                    im.convert('RGB').save(path,dpi=(600,600),compression='tiff_lzw')
        meta.append({'file':path.name,'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    fig.savefig(out/'Figure_5_preview.png',dpi=200)
    plt.close(fig)
    with Image.open(out/'Figure_5.tiff') as im:
        tiff={'size':im.size,'mode':im.mode,'dpi':[float(x) for x in im.info.get('dpi',[])],'compression':im.info.get('compression')}
    qa={'n_points':len(data),'n_global_tests':data.analysis.nunique(),'width_mm':180,'height_mm':174,
        'font':font,'common_log_axis':[.72,10.0],'intervals_recomputed':False,'models_refitted':False,
        'text_outside_canvas':outside,'tiff':tiff,'exports':meta,'software':{'python':platform.python_version(),
        'matplotlib':matplotlib.__version__,'pandas':pd.__version__,'numpy':np.__version__}}
    (root/'render_qa.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2))
    print(json.dumps({'figure':str(out/'Figure_5_preview.png'),'points':len(data),'font':font,'qa':'passed'}))

if __name__=='__main__':main()
