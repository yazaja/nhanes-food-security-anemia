"""Independent cell-level check of plotted CSV against copied source files."""
from pathlib import Path
import csv,json,math,hashlib
ROOT=Path(__file__).resolve().parents[1]
def rows(p):
    with p.open() as f:return list(csv.DictReader(f))
manifest=json.loads((ROOT/'source_manifest.json').read_text())
for rec in manifest:
    assert hashlib.sha256((ROOT/rec['file']).read_bytes()).hexdigest()==rec['sha256']
plot=rows(ROOT/'plotted_source.csv');assert len(plot)==42
mapping={
 'main_m2':(None,None,'OR','low','high'),
 'common_m2':('model','M2_same','OR','low','high'),
 'common_m3':('model','M3_same','OR','low','high'),
 'adult_m2':('scale','adult','OR','low','high'),
 'age_m2':('outcome','anemia','estimate','low','high'),
 'mi_m2':('model','M2','OR','lower','upper'),
 'mi_m3':('model','M3','OR','lower','upper')}
checked=0
for p in plot:
    col,value,est,lo,hi=mapping[p['analysis']]
    hits=[s for s in rows(ROOT/p['source_file']) if s['ch']==p['ch'] and s['fi']==p['fi'] and (col is None or s[col]==value)]
    assert len(hits)==1
    s=hits[0]
    for key,sourcekey in [('OR',est),('low',lo),('high',hi),('p','p')]:
        assert math.isclose(float(p[key]),float(s[sourcekey]),rel_tol=1e-14,abs_tol=1e-15),(p,key)
        checked+=1
for key,expected in [('main_m2',38929),('common_m2',37695),('common_m3',37695),('adult_m2',38929),('age_m2',21964),('mi_m2',41972),('mi_m3',41972)]:
    group=[p for p in plot if p['analysis']==key]
    assert len(group)==6 and {int(p['total_n']) for p in group}=={expected}
    assert len({p['global_interaction_p'] for p in group})==1
joint={
 'main_m2':('two_population_primary/results/interaction.csv',None,None),
 'common_m2':('health_and_mi_analyses/cc_sensitivity/results/interaction.csv','model','M2_same'),
 'common_m3':('health_and_mi_analyses/cc_sensitivity/results/interaction.csv','model','M3_same'),
 'adult_m2':('adult_scale_sensitivity/results/interaction_global.csv','scale','adult'),
 'age_m2':('age_and_dietary_analyses/age/results/interaction_global.csv','outcome','anemia'),
 'mi_m2':('health_and_mi_analyses/mi/pooled_interaction.csv','model','M2'),
 'mi_m3':('health_and_mi_analyses/mi/pooled_interaction.csv','model','M3')}
for key,(file,col,value) in joint.items():
    hits=[s for s in rows(ROOT/'data'/file) if col is None or s[col]==value]
    assert len(hits)==1
    plotted=next(p['global_interaction_p'] for p in plot if p['analysis']==key)
    assert math.isclose(float(plotted),float(hits[0]['p']),rel_tol=1e-14,abs_tol=1e-15)
qa={'frozen_source_hashes_checked':len(manifest),'plotted_effects':len(plot),
    'source_numeric_cells_checked':checked,'population_labels_checked':True,
    'global_p_cells_checked':len(joint),'no_reestimated_CIs':True,'checks_passed':True}
(ROOT/'source_checks.json').write_text(json.dumps(qa,indent=2))
print(json.dumps(qa))
