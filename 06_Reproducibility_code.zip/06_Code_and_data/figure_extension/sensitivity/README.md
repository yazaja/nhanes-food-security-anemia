# Figure 5: Sensitivity Analyses of Household Food Security and Anemia

Renders the multi-specification forest plot (`Figure 5`) from the aggregate regression outputs (`Table 2` and `Tables S7, S9, S11, S12`) and verifies cell-level numerical agreement against the source CSV files.

## Usage

```bash
python code/render_figure5.py --root .
python code/check_sources.py
```

## Input files and verification

- `data/`: Aggregate ORs, 95% CIs, and interaction test P values across the five `Model M2` specifications (primary complete cases, common complete cases, 10-item adult scale, ages 40–74 years, and 20-dataset multiple imputation) and two `Model M3` specifications (common complete cases and multiple imputation).
- `plotted_source.csv`: Tidy table of all 42 within-group OR estimates and 7 overall interaction P values.
- `source_manifest.json`: SHA-256 checksums for all 15 input files verified by `code/check_sources.py`.
