"""Render Figure 4 from frozen, corrected aggregate dietary estimates only.

No statistical models are fitted and no participant-level data are read.
Run: python code/draw_nutrients.py --root /path/to/nutrients
"""
from pathlib import Path
import argparse
import hashlib
import json
import platform
import re

import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from PIL import Image

import style
from style import (INK, MUTED, BAND, COLORS, MARKERS, NAMES,
                   new_figure, header, forest_axis, estimate, save)


PANELS = [
    ("iron", "A", "Iron", "mg/d", (-2.2, 2.2), [-2, -1, 0, 1, 2]),
    ("folate_DFE", "B", "Folate", "µg DFE/d", (-85, 85), [-80, -40, 0, 40, 80]),
    ("vitamin_B12", "C", "Vitamin B12", "µg/d", (-2.0, 2.0), [-2, -1, 0, 1, 2]),
    ("protein", "D", "Protein", "g/d", (-10.5, 5.5), [-10, -5, 0, 5]),
]
LEVELS = {2: "Marginal", 3: "Low", 4: "Very low"}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def contrast(hex_color):
    rgb = [int(hex_color[i:i + 2], 16) / 255 for i in (1, 3, 5)]
    lin = [v / 12.92 if v <= .04045 else ((v + .055) / 1.055) ** 2.4 for v in rgb]
    return 1.05 / (.2126 * lin[0] + .7152 * lin[1] + .0722 * lin[2] + .05)


def main(root):
    root = Path(root).resolve()
    data, out = root / "data", root / "figures"
    out.mkdir(parents=True, exist_ok=True)
    within = pd.read_csv(data / "diet_adjusted_within_differences.csv")
    tests = pd.read_csv(data / "diet_global_interactions.csv").set_index("nutrient")
    summary = json.loads((data / "summary.json").read_text())
    assert summary["M2_diet_n"] == 36588
    assert summary["M2_cancer_n"] == 3550 and summary["M2_no_cancer_n"] == 33038
    assert len(within) == 24 and len(tests) == 4
    assert not within.duplicated(["nutrient", "ch", "fi"]).any()
    assert np.isfinite(within[["estimate", "low", "high"]]).all().all()
    assert (within.low <= within.estimate).all() and (within.estimate <= within.high).all()
    assert set(within.df) == {81}
    assert set(within.n) == {3550, 33038}
    assert set(within.fi) == {2, 3, 4}
    assert set(within.ch) == {"cancer", "no_cancer"}

    font = style.apply_style()
    fig = new_figure(158)
    header(fig, "Food security and dietary nutrient intake",
           "Energy-adjusted mean differences  |  First-day dietary sample, n = 36,588")
    handles = [Line2D([0], [0], marker=MARKERS[g], color=COLORS[g], linestyle="none",
                      markersize=4.5, label=f"{NAMES[g]} (n = {summary['M2_cancer_n' if g == 'cancer' else 'M2_no_cancer_n']:,})")
               for g in ["cancer", "no_cancer"]]
    fig.legend(handles=handles, loc="upper left", bbox_to_anchor=(.035, .892), ncol=2,
               frameon=False, columnspacing=2, handletextpad=.45, borderaxespad=0)

    positions = [[.12, .555, .345, .225], [.615, .555, .345, .225],
                 [.12, .205, .345, .225], [.615, .205, .345, .225]]
    plotted = []
    for pos, (key, letter, title, unit, limits, ticks) in zip(positions, PANELS):
        ax = fig.add_axes(pos)
        forest_axis(ax, limits, ticks, (-.48, 2.48), reference=0)
        ax.set_yticks([2, 1, 0], [LEVELS[x] for x in [2, 3, 4]])
        ax.tick_params(axis="y", length=0, pad=5, labelsize=7.5)
        ax.axhspan(.55, 1.45, color=BAND, linewidth=0, zorder=0)
        # Titles and global tests belong to the facet, not to a particular level.
        ax.text(-.245, 1.24, f"{letter}  {title}", transform=ax.transAxes,
                weight="bold", fontsize=9, va="bottom", color=INK)
        row = tests.loc[key]
        ax.text(-.245, 1.085,
                f"Interaction P = {row.p:.3f}; BH-adjusted P = {row.p_BH_4_interactions:.3f}",
                transform=ax.transAxes, fontsize=6.7, color=MUTED, va="bottom")
        for level, y in [(2, 2), (3, 1), (4, 0)]:
            for group, shift in [("cancer", .14), ("no_cancer", -.14)]:
                z = within[(within.nutrient == key) & (within.ch == group) & (within.fi == level)]
                assert len(z) == 1
                z = z.iloc[0]
                estimate(ax, z.estimate, z.low, z.high, y + shift,
                         COLORS[group], MARKERS[group], size=4.5)
                plotted.append({"panel": letter, "nutrient": key, "unit_display": unit,
                                "population": group, "food_security": LEVELS[level],
                                "reference": "Full food security", "fi": level,
                                "population_n": int(z.n), "category_n": int(z.group_n),
                                "estimate": z.estimate, "low": z.low, "high": z.high,
                                "pointwise_p": z.p, "residual_df": int(z.df),
                                "global_interaction_p": row.p,
                                "global_interaction_BH_p": row.p_BH_4_interactions,
                                "display_xmin": limits[0], "display_xmax": limits[1]})
        ax.set_xlabel(f"Adjusted mean difference ({unit})", labelpad=5, fontsize=7.5)

    fig.text(.035, .108, "Each category is compared with full food security within the same population.",
             fontsize=7.1, color=MUTED)
    fig.text(.035, .072, "Points and bars: mean differences and pointwise 95% CIs. Dashed lines indicate no difference.",
             fontsize=7.1, color=MUTED)
    fig.text(.035, .036, "BH adjustment covers the four overall interaction tests. DFE, dietary folate equivalents.",
             fontsize=7.1, color=MUTED)

    save(fig, out, "Figure_4")
    assert not style.QA[-1]["text_outside_canvas"], style.QA[-1]
    # TIFF submission copy is RGB on an explicitly opaque white background.
    tif = out / "Figure_4.tiff"
    with Image.open(tif) as im:
        if im.mode == "RGBA":
            assert im.getchannel("A").getextrema() == (255, 255)
        im.convert("RGB").save(tif, compression="tiff_lzw", dpi=(600, 600))
    pd.DataFrame(plotted).to_csv(root / "plotted_source.csv", index=False, float_format="%.17g")
    metadata = []
    for ext in ["png", "tiff"]:
        with Image.open(out / f"Figure_4.{ext}") as im:
            metadata.append({"file": f"Figure_4.{ext}", "size_px": list(im.size),
                             "mode": im.mode, "dpi": [float(v) for v in im.info.get("dpi", [])]})
    media = re.search(rb"/MediaBox\s*\[\s*0\s+0\s+([0-9.]+)\s+([0-9.]+)\s*\]",
                      (out / "Figure_4.pdf").read_bytes())
    assert media, "Missing Matplotlib PDF MediaBox"
    qa = {"figure": "Figure_4", "font": font, "width_mm": 180, "height_mm": 158,
          "plotted_rows": len(plotted), "all_source_rows_retained": len(plotted) == len(within),
          "no_model_refitting": True, "table_reference": "Table S14 A and C",
          "canvas_check": style.QA[-1], "images": metadata,
          "pdf_points": [float(media.group(1)), float(media.group(2))],
          "contrast_against_white": {g: contrast(c) for g, c in COLORS.items()},
          "redundant_encoding": "wine circles / navy squares; populations also named in legend",
          "software": {"python": platform.python_version(), "matplotlib": matplotlib.__version__,
                       "pandas": pd.__version__, "numpy": np.__version__}}
    (root / "render_qa.json").write_text(json.dumps(qa, indent=2))
    source_base = "aggregate_reference/age_and_dietary_analyses/diet/results/"
    sources = [{"file": str(p.relative_to(root)), "sha256": sha(p),
                "original_source": source_base + p.name} for p in sorted(data.iterdir())]
    sources.append({"file": "code/style.py", "sha256": sha(root / "code/style.py"),
                    "original_source": "figure_reproduction/code/style.py"})
    (root / "source_manifest.json").write_text(json.dumps(sources, indent=2))
    exports = [{"file": str(p.relative_to(root)), "bytes": p.stat().st_size,
                "sha256": sha(p)} for p in sorted(out.iterdir()) if p.is_file()]
    (root / "export_manifest.json").write_text(json.dumps(exports, indent=2))
    print(json.dumps({"figure": "Figure_4", "font": font, "output": str(out), "plotted_rows": len(plotted)}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=str(Path(__file__).resolve().parents[1]))
    args = parser.parse_args()
    main(args.root)
