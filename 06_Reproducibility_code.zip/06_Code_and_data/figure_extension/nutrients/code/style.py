"""Shared publication style. Rendering only; all statistical values are frozen."""
from pathlib import Path
import json
import hashlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager, ticker
from matplotlib.backends.backend_pdf import PdfPages

INK = '#252D36'
MUTED = '#657282'
NAVY = '#24557B'
WINE = '#94334F'
GRID = '#E0E6EC'
BAND = '#EFF2F5'
LINE = '#AAB5C1'
COLORS = {'cancer': WINE, 'no_cancer': NAVY}
MARKERS = {'cancer': 'o', 'no_cancer': 's'}
NAMES = {'cancer': 'Cancer survivors', 'no_cancer': 'No cancer history'}
FILES = []
QA = []
PORTFOLIO = None


def apply_style():
    # Optional task-local fonts are for rendering only, never bundled for reuse.
    font_dir = Path(__file__).resolve().parents[1]/'render_fonts'
    for path in font_dir.glob('*.ttf'):
        font_manager.fontManager.addfont(str(path))
    available = {x.name for x in font_manager.fontManager.ttflist}
    font = next((x for x in ['Arial', 'Liberation Sans', 'DejaVu Sans'] if x in available), 'DejaVu Sans')
    plt.rcParams.update({
        'font.family': 'sans-serif', 'font.sans-serif': [font],
        'font.size': 8, 'text.color': INK, 'axes.labelcolor': INK,
        'axes.edgecolor': LINE, 'xtick.color': MUTED, 'ytick.color': INK,
        'axes.titlesize': 9, 'axes.titleweight': 'bold', 'axes.labelsize': 8,
        'xtick.labelsize': 7.3, 'ytick.labelsize': 8,
        'legend.fontsize': 7.5, 'axes.linewidth': .6,
        'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none',
        'figure.facecolor': 'white', 'axes.facecolor': 'white',
        'savefig.facecolor': 'white', 'savefig.transparent': False,
        'axes.unicode_minus': True, 'mathtext.fontset': 'dejavusans',
    })
    return font


def new_figure(height_mm, width_mm=180):
    return plt.figure(figsize=(width_mm/25.4, height_mm/25.4), dpi=150)


def header(fig, title, subtitle):
    fig.text(.035, .968, title, fontsize=11.2, weight='bold', va='top')
    fig.text(.035, .919, subtitle, fontsize=7.7, color=MUTED, va='top', linespacing=1.4)


def panel_title(ax, letter, title, color=INK):
    ax.text(0, 1.065, f'{letter}  {title}', transform=ax.transAxes,
            ha='left', va='bottom', weight='bold', fontsize=8.7, color=color)


def forest_axis(ax, limits, ticks, ylim, reference=0, log=False):
    ax.set_facecolor('none')
    if log:
        ax.set_xscale('log')
    ax.set_xlim(limits)
    ax.set_ylim(ylim)
    ax.set_xticks(ticks, [f'{v:g}' for v in ticks])
    ax.xaxis.set_minor_locator(ticker.NullLocator())
    ax.set_yticks([])
    ax.spines[['left', 'right', 'top']].set_visible(False)
    ax.tick_params(axis='x', length=3, width=.6, pad=3)
    ax.set_axisbelow(True)
    ax.grid(axis='x', color=GRID, linewidth=.45)
    ax.axvline(reference, color=LINE, linestyle=(0,(3,3)), linewidth=.8, zorder=1)


def text_axis(fig, pos, ylim):
    ax=fig.add_axes(pos)
    ax.set_xlim(0,1); ax.set_ylim(ylim); ax.axis('off')
    return ax


def estimate(ax, x, low, high, y, color, marker='o', hollow=False, size=4.8):
    assert low <= x <= high
    left,right=ax.get_xlim()
    assert left <= low <= high <= right, (low,high,left,right)
    ax.errorbar(x,y,xerr=[[x-low],[high-x]],fmt=marker,ms=size,
                mfc='white' if hollow else color,mec=color,mew=.8,
                color=color,ecolor=color,elinewidth=.9,capsize=2,capthick=.7,
                linestyle='none',zorder=4)


def ci_text(x, low, high, digits=2):
    return f'{x:.{digits}f} ({low:.{digits}f} to {high:.{digits}f})'.replace('-', '−')


def save(fig, out, stem):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    fig.canvas.draw()
    renderer=fig.canvas.get_renderer()
    outside=[]
    from matplotlib.text import Text
    for artist in fig.findobj(match=Text):
        if not artist.get_visible() or not artist.get_text().strip():
            continue
        if artist.axes is not None and not artist.axes.axison:
            # Text-only table axes deliberately have no visible spines.
            pass
        box=artist.get_window_extent(renderer)
        if box.x0 < -1 or box.y0 < -1 or box.x1 > fig.bbox.width+1 or box.y1 > fig.bbox.height+1:
            outside.append(artist.get_text())
    QA.append({'figure':stem,'width_mm':round(fig.get_figwidth()*25.4,2),
               'height_mm':round(fig.get_figheight()*25.4,2),'text_outside_canvas':outside})
    for ext in ['pdf','svg','png','tiff']:
        path=out/f'{stem}.{ext}'
        opts={'pil_kwargs':{'compression':'tiff_lzw'}} if ext=='tiff' else {}
        fig.savefig(path,dpi=600,**opts)
        FILES.append({'file':str(path.name),'bytes':path.stat().st_size,
                      'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    fig.savefig(out/f'{stem}_preview.png',dpi=200)
    if PORTFOLIO is not None:
        PORTFOLIO.savefig(fig)
    plt.close(fig)
