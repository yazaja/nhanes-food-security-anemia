# Figure 4: First-Day Dietary Nutrient Intake Differences

Renders the four-panel forest plot (`Figure 4`) from the aggregate Day 1 dietary regression outputs (`N = 36,588`; `3,550` cancer survivors and `33,038` adults without a history of cancer).

## Usage

```bash
python code/draw_nutrients.py
```

Outputs (`Figure_4.pdf`, `.svg`, `.png`, `.tiff`, and `_preview.png`) are written to `figures/`.

## Input files

- `data/diet_adjusted_within_differences.csv`: Within-group energy- and covariate-adjusted mean differences and pointwise 95% CIs (`Table S14A`).
- `data/diet_global_interactions.csv`: Joint 3-df exposure-by-cancer-history Wald F tests and Benjamini–Hochberg-adjusted P values across the four nutrients (`Table S14C`).
- `data/summary.json`: Analytic sample sizes and model metadata.
- `plotted_source.csv`: Exact plotted series and values.
- `source_manifest.json`: Input file SHA-256 checksums.
