# NHANES Analysis Code and Aggregate Reference Outputs

Reproducible statistical analysis and plotting code for **Household food security and anemia by cancer history in adults: a cross-sectional study** (NHANES 2003–March 2020).

Public-use participant-level NHANES files are obtained directly from CDC/NCHS and are not redistributed in this archive. Aggregate model outputs and summary tables are provided in `aggregate_reference/` for verification and direct figure reproduction.

## Directory structure

| Directory | Contents |
|---|---|
| `core_pipeline/` | Official NHANES XPT download, SHA-256 verification, cross-cycle harmonization, dataset merging, and binary food-insecurity survivor models (`Table S4`). |
| `project/baseline_two_groups/` | Two-population survey-weighted baseline descriptive characteristics (`Table 1`). |
| `project/two_population_primary/` | Primary two-population fully interacted logistic model (`Model M2`, `Table 2`), JKn replicate-weight standardized anemia prevalences and differences (`Figure 2`, `Table S6`), and red-cell MCV morphologic analyses (`Figure S2`). |
| `project/continuous_hemoglobin/` | Two-population continuous venous hemoglobin linear regression models and contrasts (`Figure 3`, `Table S10`). |
| `project/adult_scale_sensitivity/` | Ten-item adult food security scale (`FSDAD`) sensitivity and reclassification analyses (`Table S11`). |
| `project/health_and_mi_analyses/` | Health-extended complete-case models (`Model M3`, `Tables S7–S8`) and two-population multiple imputation by chained equations (`Table S9`). |
| `project/age_and_dietary_analyses/` | Common age-range (`40–74` years) sensitivity models (`Table S12`) and Day 1 24-hour dietary recall linkage and nutrient regression models (`Figure 4`, `Tables S13–S14`). |
| `project/survivor_four_category/` | Survivor-only four-category baseline table (`Table S1`) and sequential/sensitivity/stratified survivor models (`Tables S2, S3, S5`). |
| `project/survivor_binary_subgroups/` | Formatting helper extracting sex- and age-stratified binary food-insecurity estimates for `Figure S1`. |
| `project/selection_flow/` | Sequential eligibility and complete-case participant flow counter (`Figure 1`). |
| `aggregate_reference/` | Aggregate CSV/JSON statistical outputs and R session records corresponding to each analysis module. |
| `figure_reproduction/` | Unified entrypoint rendering `Figures 1–5` and `Figures S1–S2` from aggregate outputs. |
| `figure_extension/` | Standalone plotting modules and source verification scripts for `Figure 4` (`nutrients/`) and `Figure 5` (`sensitivity/`). |
| `tools/prepare_workspace.py` | Workspace staging script that copies `project/` scripts into a user-selected working directory and substitutes local paths. |

## Software environment

- **Python** (tested with 3.12): `numpy`, `pandas`, `matplotlib`, `Pillow`, `pypdf` (see `core_pipeline/environment/requirements.txt` and `figure_reproduction/requirements.txt`).
- **R** (tested with 4.6): `survey`, `mice`, `splines`, `jsonlite` (installable via `Rscript core_pipeline/environment/install_R_dependencies.R`).

```bash
export NHANES_WORK=/path/to/empty_work_dir
python tools/prepare_workspace.py --work-root "$NHANES_WORK"
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
```

## Statistical execution order

1. **Download, harmonize, and merge public NHANES XPT files (64 core files) and run binary survivor models:**

```bash
python core_pipeline/run.py download --work-dir "$NHANES_WORK/analysis"
python core_pipeline/run.py prepare --work-dir "$NHANES_WORK/analysis"
python core_pipeline/run.py analyze --work-dir "$NHANES_WORK/analysis"
```

2. **Sequential participant flow counts and survivor-only supporting tables (`Tables S1–S3, S5` and `Figure S1` inputs):**

```bash
Rscript "$NHANES_WORK/selection_flow/count_flow.R"   "$NHANES_WORK/analysis/data/merged_expanded.csv"   "$NHANES_WORK/selection_flow/results"

Rscript "$NHANES_WORK/survivor_four_category/code/table1_four_categories.R"   "$NHANES_WORK/analysis/data/merged_expanded.csv"   "$NHANES_WORK/survivor_four_category/results"

Rscript "$NHANES_WORK/survivor_four_category/code/analyze_four_category_primary.R"   "$NHANES_WORK/analysis/data/merged_expanded.csv"   "$NHANES_WORK/survivor_four_category/results"

python "$NHANES_WORK/survivor_binary_subgroups/code/prepare_binary_subgroups.py"   --source-results "$NHANES_WORK/analysis/results"   --output-dir "$NHANES_WORK/survivor_binary_subgroups/results"
```

3. **Two-population baseline table, primary comparative anemia model + JKn standardization, and MCV morphology:**

```bash
Rscript "$NHANES_WORK/baseline_two_groups/code/baseline_two_groups.R"   "$NHANES_WORK/analysis/data/merged_expanded.csv"   "$NHANES_WORK/baseline_two_groups/results"

Rscript "$NHANES_WORK/two_population_primary/code/analyze_comparison.R"   "$NHANES_WORK/analysis/data/merged_expanded.csv"   "$NHANES_WORK/two_population_primary/results" 1

Rscript "$NHANES_WORK/two_population_primary/phenotype/analyze_phenotype.R"   "$NHANES_WORK/analysis/data/merged_expanded.csv"   "$NHANES_WORK/two_population_primary/phenotype/results"
```

4. **Health-extended complete-case models (`Model M3`) and two-population multiple imputation (`20` datasets):**

```bash
Rscript "$NHANES_WORK/health_and_mi_analyses/cc_sensitivity/code/analyze_cc.R"   "$NHANES_WORK/analysis/data/merged_expanded.csv"   "$NHANES_WORK/health_and_mi_analyses/cc_sensitivity/results" 1

Rscript "$NHANES_WORK/health_and_mi_analyses/mi/analyze_comparison_mi.R"   "$NHANES_WORK/health_and_mi_analyses/mi"   "$NHANES_WORK/analysis/data/merged_expanded.csv" final
```

5. **Continuous hemoglobin and 10-item adult food security scale models:**

```bash
Rscript "$NHANES_WORK/continuous_hemoglobin/code/analyze_hb.R"   "$NHANES_WORK/two_population_primary/results/models_and_replicates.rds"   "$NHANES_WORK/continuous_hemoglobin/results"

Rscript "$NHANES_WORK/adult_scale_sensitivity/code/analyze_adult_scale.R"   "$NHANES_WORK/two_population_primary/results/models_and_replicates.rds"   "$NHANES_WORK/adult_scale_sensitivity/results"
```

6. **Common age-range (`40–74` years) sensitivity and Day 1 24-hour dietary recall models:**

```bash
Rscript "$NHANES_WORK/age_and_dietary_analyses/age/code/analyze_age.R"
python "$NHANES_WORK/age_and_dietary_analyses/diet/code/prepare_diet.py"
Rscript "$NHANES_WORK/age_and_dietary_analyses/diet/code/analyze_diet.R"
```

Note on SAS XPT zero decoding: `prepare_diet.py` converts SAS transport subnormal representations (`|x| < 1e-70`) to exact `0.0` immediately after reading Day 1 dietary XPT files so true zero nutrient intakes are preserved accurately while zero-weight and zero-energy records are filtered cleanly.

## Direct figure reproduction from aggregate outputs

To regenerate `Figures 1–5` and `Figures S1–S2` (PDF, SVG, 600-dpi PNG, and TIFF) directly from the included aggregate CSV/JSON outputs:

```bash
python figure_reproduction/code/render_all.py --root figure_reproduction
```
