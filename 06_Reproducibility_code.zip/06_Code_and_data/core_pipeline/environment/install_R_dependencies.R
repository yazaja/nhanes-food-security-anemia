# Install the two explicit analysis dependencies into a user-selected R library.
# Run: Rscript environment/install_R_dependencies.R [LIBRARY_DIRECTORY]
# This does not install/replace R itself. Recorded R version: 4.6.1.
args <- commandArgs(trailingOnly=TRUE)
lib <- if(length(args)) args[[1]] else path.expand(Sys.getenv('R_LIBS_USER'))
if(!nzchar(lib)) stop('Specify a writable R library directory as the first argument')
dir.create(lib,recursive=TRUE,showWarnings=FALSE)
.libPaths(c(normalizePath(lib),.libPaths()))
repos <- 'https://cloud.r-project.org'
versions <- c(jsonlite='2.0.0',survey='4.5')
for(pkg in names(versions)) {
  wanted <- versions[[pkg]]
  if(requireNamespace(pkg,quietly=TRUE) && as.character(packageVersion(pkg))==wanted) next
  # CRAN's current packages resolve dependencies and platform binaries first.
  install.packages(pkg,lib=lib,repos=repos,dependencies=NA)
  installed <- tryCatch(as.character(packageVersion(pkg,lib.loc=lib)),error=function(e) '')
  if(installed!=wanted) {
    url <- sprintf('%s/src/contrib/Archive/%s/%s_%s.tar.gz',repos,pkg,pkg,wanted)
    install.packages(url,lib=lib,repos=NULL,type='source')
    installed <- tryCatch(as.character(packageVersion(pkg,lib.loc=lib)),error=function(e) '')
    if(installed!=wanted) stop('Could not install recorded ',pkg,' ',wanted,'. Check the CRAN archive/build tools; no silent version substitution is accepted.')
  }
}
cat('Analysis packages are installed in: ',normalizePath(lib),'\n',sep='')
cat('Set R_LIBS_USER to this directory when running run.py if it is not already on .libPaths().\n')
cat('Transitive dependencies and R/BLAS are not locked by this installer; record the session and validate every result.\n')
