#!/usr/bin/env python3
"""Portable entry point for the manuscript's complete analysis workflow."""
from pathlib import Path
import argparse
import datetime as dt
import hashlib
import importlib.metadata as metadata
import json
import os
import shutil
import subprocess
import sys
import time

PACKAGE=Path(__file__).resolve().parent
STAGES=['download','prepare','analyze','visualize','validate']

def parse_args():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('stage',choices=['check','all']+STAGES)
    p.add_argument('--work-dir',type=Path,default=Path('work'),help='Separate working directory for downloaded data and regenerated outputs')
    p.add_argument('--cache-dir',type=Path,help='Optional explicit directory containing the 64 original XPT files; every file is hash-checked')
    p.add_argument('--rscript',default='Rscript',help='Rscript executable name or full path')
    p.add_argument('--font-dir',type=Path,help='Optional directory of user-provided Arial .ttf files; fonts are not distributed')
    p.add_argument('--skip-download',action='store_true',help='For all: use existing WORK/raw files; preparation still verifies every hash')
    return p.parse_args()

def main():
    args=parse_args();work=args.work_dir.expanduser().resolve()
    if work==PACKAGE or any(work.is_relative_to(PACKAGE/p) for p in ['src','reference','config','environment','validation']):
        raise SystemExit('Use a separate work directory, not a source/reference directory.')
    work.mkdir(parents=True,exist_ok=True)
    for name in ['raw','data','results','figures','tables','logs','validation']:(work/name).mkdir(exist_ok=True)
    lock=work/'.pipeline.lock'
    try:
        fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
        with os.fdopen(fd,'w') as f:f.write(json.dumps({'pid':os.getpid(),'created':dt.datetime.now(dt.timezone.utc).isoformat()}))
    except FileExistsError:
        raise SystemExit(f'Another run or a stale lock exists: {lock}. Confirm no run is active before removing it.')
    run={'started_at':dt.datetime.now(dt.timezone.utc).isoformat(),'stage':args.stage,'steps':[],
         'package_code_sha256':{str(p.relative_to(PACKAGE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(PACKAGE.rglob('*')) if p.is_file() and (p.parent.name=='src' or p.name=='run.py')},
         'status':'running'}
    env=dict(os.environ,OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',MPLCONFIGDIR=str(work/'.matplotlib'))
    def invoke(name,command):
        start=time.monotonic();log=work/'logs'/f'{name}.log'
        print(f'[{name}] Running; log: {log}',flush=True)
        with log.open('w') as stream:
            proc=subprocess.run([str(x) for x in command],stdout=stream,stderr=subprocess.STDOUT,env=env,cwd=PACKAGE)
        record={'step':name,'exit_code':proc.returncode,'seconds':round(time.monotonic()-start,3),'log':str(log.relative_to(work))}
        run['steps'].append(record)
        if proc.returncode:
            print(log.read_text(errors='replace')[-5000:],file=sys.stderr)
            raise RuntimeError(f'{name} failed (exit {proc.returncode}); see {log}')
        print(f'[{name}] Complete ({record["seconds"]} s)',flush=True)
    try:
        selected=STAGES.copy() if args.stage=='all' else [args.stage]
        if args.skip_download:
            if args.stage!='all':raise ValueError('--skip-download is only applicable to all')
            selected.remove('download')
        needed={'download':[],'prepare':['numpy','pandas'],'analyze':['numpy','pandas'],'visualize':['matplotlib','Pillow'],'validate':['numpy','pandas']}
        packages=sorted(set(sum((needed.get(s,[]) for s in selected),[])))
        if args.stage=='check':packages=['numpy','pandas','matplotlib','Pillow']
        installed={}
        for package in packages:
            try:installed[package]=metadata.version(package)
            except metadata.PackageNotFoundError:raise RuntimeError(f'Missing Python dependency {package}; install environment/requirements.txt first')
        run['python']={'version':sys.version.split()[0],'packages':installed}
        if 'analyze' in selected or args.stage=='check':
            rscript=shutil.which(args.rscript)
            if rscript is None:raise RuntimeError('Rscript not found; install R and R dependencies, or specify --rscript')
            invoke('check_R',[rscript,PACKAGE/'environment/check_R_environment.R',work/'validation/R_environment.json'])
        else:rscript=args.rscript
        if args.stage=='check':
            print('Python packages and R dependencies are available. No study data were analyzed.',flush=True)
        if 'download' in selected:
            command=[sys.executable,PACKAGE/'src/download_data.py','--raw-dir',work/'raw']
            if args.cache_dir:command.extend(['--cache-dir',args.cache_dir.expanduser().resolve()])
            invoke('01_download',command)
        if 'prepare' in selected:
            invoke('02_prepare',[sys.executable,PACKAGE/'src/prepare_data.py','--raw-dir',work/'raw','--output-dir',work/'data'])
        if 'analyze' in selected:
            invoke('03_analyze',[rscript,PACKAGE/'src/analyze.R',work/'data/merged_expanded.csv',work/'results',work/'data/preparation_manifest.json'])
            invoke('04_age_interaction',[rscript,PACKAGE/'src/check_age_interaction.R',work/'results'])
            invoke('05_quality_checks',[sys.executable,PACKAGE/'src/qc.py','--data-dir',work/'data','--results-dir',work/'results'])
        if 'visualize' in selected:
            command=[sys.executable,PACKAGE/'src/plot_figures.py','--source',work/'results','--output',work/'figures']
            if args.font_dir:command.extend(['--font-dir',args.font_dir.expanduser().resolve()])
            invoke('06_figures',command)
            invoke('07_readable_tables',[sys.executable,PACKAGE/'src/export_tables.py','--results-dir',work/'results','--output-dir',work/'tables'])
        if 'validate' in selected:
            invoke('08_compare_results',[sys.executable,PACKAGE/'src/validate_results.py','--results-dir',work/'results','--figures-dir',work/'figures','--output',work/'validation/result_comparison.json'])
        run['status']='passed'
    except Exception as e:
        run['status']='failed';run['error']=str(e);print(str(e),file=sys.stderr)
    finally:
        run['finished_at']=dt.datetime.now(dt.timezone.utc).isoformat()
        (work/'validation'/f'run_{args.stage}.json').write_text(json.dumps(run,indent=2,ensure_ascii=False))
        lock.unlink(missing_ok=True)
    if run['status']!='passed':return 1
    print(f'Workflow complete. Regenerated outputs: {work}',flush=True)
    return 0

if __name__=='__main__':sys.exit(main())
