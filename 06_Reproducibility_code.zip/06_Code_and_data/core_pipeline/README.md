# Core NHANES Data Pipeline and Survivor Binary Models

Downloads the 64 public-use NHANES XPT files (2003–March 2020), verifies SHA-256 checksums against `config/source_files.json`, harmonizes variables across eight survey release units (`N = 86,618`), and fits the binary food-insecurity cancer survivor models (`Table S4`).

## Environment setup

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r environment/requirements.txt
Rscript environment/install_R_dependencies.R
```

## Execution

Run all stages sequentially into a separate working directory:

```bash
python run.py all --work-dir work
```

Or run individual stages (`check`, `download`, `prepare`, `analyze`, `visualize`, `validate`):

```bash
python run.py download --work-dir work
python run.py prepare --work-dir work
python run.py analyze --work-dir work
```

- `--cache-dir <PATH>`: Optional directory containing pre-downloaded NHANES XPT files (each verified by SHA-256).
- `--rscript <PATH>`: Custom `Rscript` executable path if not on `PATH`.
- `--font-dir <PATH>`: Optional directory containing `.ttf` font files (falls back to system Arial or DejaVu Sans).

Variable definitions are documented in `config/variable_dictionary.csv`, and reference CSV outputs are stored in `reference/tables/`.
