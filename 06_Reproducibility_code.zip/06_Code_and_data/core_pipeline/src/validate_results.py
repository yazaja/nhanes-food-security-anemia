"""Compare newly generated aggregate results with frozen audited outputs.

The reference directory is read only by this validator. It is never an input to
downloading, cleaning, statistical estimation or figure generation.
"""
from pathlib import Path
import argparse
import csv
from decimal import Decimal, InvalidOperation
import hashlib
import json
import math
import sys

REFERENCE = Path(__file__).resolve().parents[1] / "reference"
RTOL = 1e-6
ATOL = 1e-9
# Counts, category identifiers, dimensions and degrees of freedom have no tolerance.
DISCRETE_COLUMNS = {
    "n", "events", "anemia_events", "insecure_n", "insecure_events", "n_total",
    "n_available", "n_missing", "n_level", "missing_n", "excluded", "parameters",
    "df", "design_df", "residual_df", "denominator_df", "age65", "food_insecure",
    "level", "rank", "analysis_n", "m2_n", "m2_events", "m3_n", "m3_events",
    "MEC_n", "MEC_strata", "MEC_PSU", "smoking_rounding_changed_on_R_load",
    "current_smokers_n", "current_smoking_unknown_quantity_n",
    "current_smoking_exactly_20_n", "rounding_boundary_changed_n",
}


class Comparison:
    def __init__(self, label):
        self.report = {"item": label, "passed": True, "values_checked": 0,
                       "difference_count": 0, "max_absolute_numeric_difference": 0.0,
                       "max_relative_numeric_difference": 0.0, "differences": []}

    def fail(self, path, expected, actual, reason):
        self.report["passed"] = False
        self.report["difference_count"] += 1
        # Bound error size while still counting every failing comparison.
        if len(self.report["differences"]) < 100:
            self.report["differences"].append(
                {"path": path, "expected": expected, "actual": actual, "reason": reason})

    def numeric(self, path, expected, actual, exact=False):
        self.report["values_checked"] += 1
        try:
            ex, ac = Decimal(str(expected)), Decimal(str(actual))
        except (InvalidOperation, ValueError, TypeError):
            self.fail(path, expected, actual, "not numeric")
            return
        if not (ex.is_finite() and ac.is_finite()):
            self.fail(path, str(expected), str(actual), "non-finite numeric result")
            return
        delta = abs(float(ac - ex))
        relative = delta / abs(float(ex)) if ex else (0.0 if not delta else None)
        self.report["max_absolute_numeric_difference"] = max(
            self.report["max_absolute_numeric_difference"], delta)
        if relative is not None:
            self.report["max_relative_numeric_difference"] = max(
                self.report["max_relative_numeric_difference"], relative)
        matches = ex == ac if exact else math.isclose(float(ac), float(ex), rel_tol=RTOL, abs_tol=ATOL)
        if not matches:
            self.fail(path, expected, actual, "exact discrete value mismatch" if exact else "numeric tolerance exceeded")

    def value(self, path, expected, actual, exact=False):
        if isinstance(expected, bool) or expected is None or isinstance(expected, str):
            self.report["values_checked"] += 1
            if type(expected) is not type(actual) or expected != actual:
                self.fail(path, expected, actual, "value/type or missingness mismatch")
        elif isinstance(expected, (int, float)):
            if isinstance(actual, bool) or not isinstance(actual, (int, float)):
                self.fail(path, expected, actual, "numeric type mismatch")
            else:
                self.numeric(path, expected, actual, exact or isinstance(expected, int))
        elif isinstance(expected, list):
            if not isinstance(actual, list):
                self.fail(path, "list", type(actual).__name__, "type mismatch")
                return
            if len(expected) != len(actual):
                self.fail(path, len(expected), len(actual), "list length mismatch")
            for i, (ex, ac) in enumerate(zip(expected, actual)):
                self.value(f"{path}[{i}]", ex, ac, exact)
        elif isinstance(expected, dict):
            if not isinstance(actual, dict):
                self.fail(path, "object", type(actual).__name__, "type mismatch")
                return
            if set(expected) != set(actual):
                self.fail(path, sorted(expected), sorted(actual), "object keys mismatch")
            for key in expected.keys() & actual.keys():
                self.value(f"{path}.{key}", expected[key], actual[key], key in DISCRETE_COLUMNS)
        else:
            raise TypeError(type(expected))


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.reader(handle))
    if not rows:
        raise ValueError("empty CSV")
    return rows[0], rows[1:]


def compare_csv(spec, results):
    name = spec["file"]
    check = Comparison(name)
    expected_path = REFERENCE / "tables" / name
    actual_path = results / name
    try:
        if hashlib.sha256(expected_path.read_bytes()).hexdigest() != spec["sha256"]:
            check.fail("reference", "frozen SHA256", "mismatch", "reference modified")
        eh, er = read_csv(expected_path)
        ah, ar = read_csv(actual_path)
        check.report.update({"alignment": "saved_row_order", "expected_rows": len(er),
                             "actual_rows": len(ar), "expected_columns": eh})
        if eh != ah:
            check.fail("columns", eh, ah, "column names/order mismatch")
            return check.report
        if len(er) != len(ar):
            check.fail("rows", len(er), len(ar), "row count mismatch")
        for i, (ex_row, ac_row) in enumerate(zip(er, ar), 2):
            if len(ex_row) != len(eh) or len(ac_row) != len(eh):
                check.fail(f"line {i}", len(eh), len(ac_row), "row width mismatch")
                continue
            for key, ex, ac in zip(eh, ex_row, ac_row):
                path = f"line {i}:{key}"
                if ex in {"", "NA"} or ac in {"", "NA"}:
                    check.value(path, ex, ac)
                    continue
                try:
                    Decimal(ex)
                except InvalidOperation:
                    check.value(path, ex, ac)
                else:
                    check.numeric(path, ex, ac, exact=key in DISCRETE_COLUMNS)
    except (OSError, ValueError) as error:
        check.fail("file", "readable valid CSV", str(error), "read failed")
    return check.report


def compare_facts(name, expected, results):
    check = Comparison(name)
    try:
        actual = json.loads((results / name).read_text())
        # Only frozen result keys are selected; timestamps, paths, runtime versions
        # and data-file byte hashes are intentionally outside numeric equivalence.
        selected = {key: actual[key] for key in expected if key in actual}
        check.value(name, expected, selected)
    except (OSError, ValueError, TypeError) as error:
        check.fail("file", "readable valid JSON", str(error), "read failed")
    return check.report


def compare_figures(figures, results):
    check = Comparison("figures and figure_manifest.json")
    try:
        expected = json.loads((REFERENCE / "expected_figures.json").read_text())
        actual = json.loads((figures / "figure_manifest.json").read_text())
        check.report["font_used"] = actual.get("font")
        check.report["image_hash_equality_to_historical_figures_required"] = False
        for key in ["displayed_estimates", "data_changed", "models_refit", "text_boundary_checks"]:
            check.value(key, expected[key], actual.get(key))
        actual_files = actual.get("files", [])
        ef = {item["file"]: item for item in expected["files"]}
        af = {item["file"]: item for item in actual_files}
        if len(actual_files) != 9 or set(ef) != set(af):
            check.fail("files", sorted(ef), sorted(af), "expected nine distinct PNG/PDF/SVG outputs")
        for name in ef.keys() & af.keys():
            check.value(name, ef[name], {key: af[name].get(key) for key in ef[name]})
            path = figures / name
            content = path.read_bytes()
            check.value(f"{name}:nonempty", True, bool(content))
            # Check a new manifest against its own files, not against old pixels.
            check.value(f"{name}:manifest_content_integrity", af[name].get("sha256"), hashlib.sha256(content).hexdigest())
        sources = actual.get("sources", [])
        check.value("source_names", ["participant_flow.csv", "model_results.csv", "formal_results.json"],
                    [row.get("file") for row in sources])
        for row in sources:
            name = row["file"]
            if name not in {"participant_flow.csv", "model_results.csv", "formal_results.json"}:
                continue
            check.value(f"source:{name}", hashlib.sha256((results / name).read_bytes()).hexdigest(), row.get("sha256"))
        header, rows = read_csv(results / "model_results.csv")
        models = {dict(zip(header, row))["model"]: dict(zip(header, row)) for row in rows}
        for shown in actual.get("displayed_estimates", []):
            model = models.get(shown.get("model"))
            if model is None:
                check.fail("displayed_estimates", "model in generated results", shown.get("model"), "model not found")
                continue
            for source_key, shown_key in [("n", "n"), ("anemia_events", "events"),
                                          ("estimate", "estimate"), ("CI_low", "CI_low"), ("CI_high", "CI_high")]:
                check.numeric(f"display:{shown['model']}:{shown_key}", model[source_key], shown.get(shown_key),
                              exact=shown_key in {"n", "events"})
    except (OSError, ValueError, KeyError, TypeError) as error:
        check.fail("figure_artifacts", "readable complete artifacts", str(error), "read/structure failed")
    return check.report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results-dir", required=True)
    parser.add_argument("--figures-dir", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    results, figures, output = Path(args.results_dir), Path(args.figures_dir), Path(args.output)
    inventory = json.loads((REFERENCE / "csv_inventory.json").read_text())
    facts = json.loads((REFERENCE / "expected_facts.json").read_text())
    checks = [compare_csv(spec, results) for spec in inventory]
    checks += [compare_facts(name, expected, results) for name, expected in facts.items() if name.endswith(".json")]
    checks.append(compare_figures(figures, results))
    report = {"all_passed": all(check["passed"] for check in checks), "csv_files": len(inventory),
              "rtol": RTOL, "atol": ATOL, "counts_categories_and_df": "exact",
              "scope": "All 15 aggregate CSVs, final numerical facts, all fitted-model diagnostics, nonlinear age interaction and all 9 figure exports.",
              "reference_policy": "Frozen audited aggregate outputs; read only by validation, never by estimation.",
              "tolerance_note": "Floating tolerance permits very small numerical/library variation. A failure must be investigated; tolerance is not automatically widened.",
              "checks": checks}
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False) + "\n")
    print(json.dumps({"all_passed": report["all_passed"], "items_checked": len(checks),
                      "failed_items": [check["item"] for check in checks if not check["passed"]]}, ensure_ascii=False))
    return 0 if report["all_passed"] else 1


if __name__ == "__main__":
    sys.exit(main())
