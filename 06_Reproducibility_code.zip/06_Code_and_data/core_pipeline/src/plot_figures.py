"""Redraw frozen NHANES results. Layout only; no statistical estimation.

Usage: python redraw_figures_v2.py --source /path/to/tables --output /path/to/figures
The source must contain participant_flow.csv, model_results.csv and formal_results.json.
Optionally supply --font-dir for locally available Arial regular/bold/italic font files.
"""
from pathlib import Path
import argparse, csv, hashlib, json, platform
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Rectangle, FancyArrowPatch
from matplotlib.ticker import FixedLocator, FixedFormatter, NullLocator
from PIL import Image

parser=argparse.ArgumentParser()
parser.add_argument('--source',required=True)
parser.add_argument('--output',required=True)
parser.add_argument('--font-dir')
args=parser.parse_args()
src=Path(args.source);out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
if args.font_dir:
    for p in Path(args.font_dir).glob('*.ttf'):font_manager.fontManager.addfont(p)
available={f.name for f in font_manager.fontManager.ttflist}
font='Arial' if 'Arial' in available else 'DejaVu Sans'
INK='#253640';MUTED='#63747E';LINE='#D5DFE2';TEAL='#167C80';SLATE='#536D80';PALE='#EDF6F5';GRAY_FILL='#F4F7F8'
plt.rcParams.update({'font.family':font,'font.size':8.4,'font.weight':'normal',
    'text.color':INK,'axes.labelcolor':MUTED,'xtick.color':MUTED,'ytick.color':MUTED,
    'figure.facecolor':'white','savefig.facecolor':'white','axes.linewidth':.55,
    'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','axes.unicode_minus':True})
def read(name):
    with (src/name).open(newline='') as f:return list(csv.DictReader(f))
flow=read('participant_flow.csv');models={r['model']:r for r in read('model_results.csv')}
formal=json.loads((src/'formal_results.json').read_text())
sources=['participant_flow.csv','model_results.csv','formal_results.json']
before={f:hashlib.sha256((src/f).read_bytes()).hexdigest() for f in sources}
for prev,row in zip(flow,flow[1:]):assert int(prev['n'])-int(row['excluded'])==int(row['n'])
assert int(flow[-1]['n'])==int(models['M2_socioeconomic']['n'])
files=[];text_checks=[];displayed=[]

def make_page(height):
    fig=plt.figure(figsize=(170/25.4,height/25.4))
    ax=fig.add_axes([0,0,1,1]);ax.set(xlim=(0,170),ylim=(0,height));ax.axis('off')
    return fig,ax
def text(ax,x,y,s,size=8.4,color=INK,weight='normal',ha='left',**kwargs):
    return ax.text(x,y,s,fontsize=size,color=color,weight=weight,ha=ha,va='center',**kwargs)
def line(ax,x1,y1,x2,y2,color=LINE,lw=.55,**kwargs):
    return ax.plot([x1,x2],[y1,y2],color=color,lw=lw,solid_capstyle='butt',**kwargs)
def arrow(ax,start,end):
    ax.add_patch(FancyArrowPatch(start,end,arrowstyle='-|>',mutation_scale=6.3,
        linewidth=.6,color='#A3B2BA',shrinkA=0,shrinkB=0))
def export(fig,stem,rows):
    fig.canvas.draw();renderer=fig.canvas.get_renderer();bounds=fig.bbox
    violations=[]
    for ax in fig.axes:
        for obj in ax.texts:
            if not obj.get_text():continue
            bb=obj.get_window_extent(renderer)
            if bb.x0<bounds.x0-1 or bb.x1>bounds.x1+1 or bb.y0<bounds.y0-1 or bb.y1>bounds.y1+1:
                violations.append(obj.get_text())
    assert not violations,violations
    text_checks.append({'figure':stem,'all_text_within_page':True})
    for ext in ['png','pdf','svg']:
        target=out/f'{stem}.{ext}'
        fig.savefig(target,dpi=600 if ext=='png' else 300)
        record={'file':target.name,'format':ext,'width_mm':170,'height_mm':round(fig.get_figheight()*25.4,3),
                'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'displayed_rows':rows}
        assert record['bytes']<10_000_000
        if ext=='png':
            with Image.open(target) as im:record.update(pixels=list(im.size),dpi=list(im.info['dpi']))
        files.append(record)
    plt.close(fig)

# Flow diagram: conventional thin-outline cohort boxes and exclusion branches.
fig,ax=make_page(166)
text(ax,6,158,'Retained participants',size=8.2,weight='bold')
text(ax,99,158,'n',size=8.2,weight='bold',ha='right')
text(ax,112,158,'Excluded',size=8.2,weight='bold')
text(ax,166,158,'n',size=8.2,weight='bold',ha='right')
line(ax,5,154,101,154);line(ax,111,154,166,154)
ys=[144,124,104,84,64,42,19]
heights=[13,13,13,13,13,18,18]
labels=['Participants interviewed','Adults aged ≥20 years','Reported cancer or malignancy',
        'After excluding known pregnancy','MEC examination with positive weight',
        'Hemoglobin and household\nfood security available','Primary complete-case analysis\nM2 model']
reasons=['Age <20 years','No reported cancer history\nor unknown cancer status','Known pregnancy',
         'No MEC examination or\nnon-positive / missing weight','Missing hemoglobin or\nhousehold food security',
         'Missing one or more\nM2 covariates']
for i,(y,h,label) in enumerate(zip(ys,heights,labels)):
    final=i>=5
    ax.add_patch(Rectangle((5,y-h/2),96,h,facecolor='white',edgecolor='#9AA9B1',linewidth=.6))
    text(ax,9,y,label,size=8.3 if i<5 else 8.4,weight='bold' if i==6 else 'normal',linespacing=1.4)
    n=int(flow[i]['n'])
    text(ax,97,y+(2.3 if final else 0),f'{n:,}',size=9.2,ha='right',weight='bold' if final else 'normal',color=INK)
    if final:
        events=formal['anemia_events'] if i==5 else formal['m2_events']
        text(ax,97,y-4.1,f'{events:,} anemia cases',size=7.1,ha='right',color=MUTED)
    if i<6:
        next_y=ys[i+1];start=y-h/2;end=next_y+heights[i+1]/2
        mid=(start+end)/2
        arrow(ax,(53,start-.6),(53,end+.6))
        arrow(ax,(53,mid),(107,mid))
        text(ax,112,mid,reasons[i],size=7.5,color=MUTED,linespacing=1.35)
        text(ax,166,mid,f"{int(flow[i+1]['excluded']):,}",size=8.4,ha='right')
export(fig,'Figure_1_participant_flow',[r['step'] for r in flow])

def forest(height,limits,ticks,axis_bottom,axis_top):
    fig,tx=make_page(height)
    plot_left=69.5;plot_width=61.5
    ax=fig.add_axes([plot_left/170,axis_bottom/height,plot_width/170,(axis_top-axis_bottom)/height])
    ax.set_facecolor('none');ax.set_xscale('log');ax.set_xlim(limits);ax.set_ylim(axis_bottom,axis_top)
    ax.xaxis.set_major_locator(FixedLocator(ticks));ax.xaxis.set_major_formatter(FixedFormatter([f'{x:g}' for x in ticks]))
    ax.xaxis.set_minor_locator(NullLocator());ax.yaxis.set_visible(False)
    for side in ['top','left','right']:ax.spines[side].set_visible(False)
    ax.spines['bottom'].set_color('#A9B7BE');ax.spines['bottom'].set_linewidth(.55)
    ax.tick_params(axis='x',labelsize=7.5,length=2.5,width=.55,pad=3)
    ax.axvline(1,color='#8D9DA5',linestyle=(0,(3.5,3.5)),lw=.8,zorder=1)
    text(tx,100.25,4.0,'Odds ratio (log scale)',size=7.5,ha='center',color=MUTED)
    text(tx,6,height-6,'Model' if height==79 else 'Subgroup',size=8.2,weight='bold')
    text(tx,52.7,height-6,'n / anemia cases',size=7.7,weight='bold',ha='center')
    text(tx,166,height-6,'OR (95% CI)',size=8.2,weight='bold',ha='right')
    line(tx,5,height-10,166,height-10)
    return fig,tx,ax
def draw_effect(ax,row,y,primary=False):
    est,lo,hi=[float(row[k]) for k in ['estimate','CI_low','CI_high']]
    assert 0<lo<est<hi
    color=TEAL if primary else SLATE
    ax.errorbar(est,y,xerr=[[est-lo],[hi-est]],fmt='o',markersize=3.9 if primary else 3.7,
        capsize=2.0,elinewidth=1.05 if primary else .85,markeredgewidth=.75,ecolor=color,color=color,zorder=4)
def draw_numbers(tx,row,y,primary=False):
    text(tx,52.7,y,f"{int(row['n']):,} / {int(row['anemia_events']):,}",size=8.1,ha='center',color=MUTED)
    text(tx,166,y,f"{float(row['estimate']):.2f} ({float(row['CI_low']):.2f}–{float(row['CI_high']):.2f})",
         size=8.5,ha='right',weight='bold' if primary else 'normal',color=TEAL if primary else INK)

# Main adjusted models: primary model is emphasized without changing any estimate.
fig,tx,ax=forest(79,(.8,5.5),[1,2,3,4,5],14,67)
keys=['M0_cycle','M1_demographic','M2_socioeconomic','M3_additional_health']
names=['Cycle adjusted','Demographic','Primary model','Extended model']
ys=[60,47,34,21]
for i,(key,name,y) in enumerate(zip(keys,names,ys)):
    row=models[key];primary=i==2
    text(tx,8,y,f'M{i}',size=7.5,color=TEAL if primary else MUTED,weight='bold' if primary else 'normal')
    text(tx,16,y,name,size=8.4,weight='bold' if primary else 'normal')
    draw_numbers(tx,row,y,primary);draw_effect(ax,row,y,primary)
    displayed.append({'figure':'Figure_2_main_models','model':key,'n':int(row['n']),'events':int(row['anemia_events']),
                      'estimate':float(row['estimate']),'CI_low':float(row['CI_low']),'CI_high':float(row['CI_high'])})
export(fig,'Figure_2_main_models',keys)

# Exploratory strata: all use the original separately fitted stratum models.
fig,tx,ax=forest(94,(.5,8.5),[.5,1,2,4,8],14,76)
for y,label in [(78,'Sex'),(45,'Age, years')]:
    line(tx,32,y,166,y,color=LINE,lw=.45)
    text(tx,8,y,label,size=7.8,weight='bold',color=MUTED)
keys=['subgroup_female_0','subgroup_female_1','subgroup_age65_0','subgroup_age65_1']
names=['Male','Female','20–64','≥65'];ys=[66,54,33,21]
for key,name,y in zip(keys,names,ys):
    row=models[key]
    text(tx,10,y,name,size=8.4)
    draw_numbers(tx,row,y);draw_effect(ax,row,y)
    displayed.append({'figure':'Figure_3_exploratory_subgroups','model':key,'n':int(row['n']),'events':int(row['anemia_events']),
                      'estimate':float(row['estimate']),'CI_low':float(row['CI_low']),'CI_high':float(row['CI_high'])})
export(fig,'Figure_3_exploratory_subgroups',keys)

assert before=={f:hashlib.sha256((src/f).read_bytes()).hexdigest() for f in sources}
manifest={'version':'visual_v2','rendered_on':'shared Python server','python':platform.python_version(),'matplotlib':matplotlib.__version__,
          'font':font,'minimum_font_pt':7.1,'pdf_fonts':'TrueType embedding requested; final resource verification separate',
          'script':'redraw_figures_v2.py','sources':[{'file':f,'sha256':before[f]} for f in sources],
          'files':files,'displayed_estimates':displayed,'text_boundary_checks':text_checks,
          'data_changed':False,'models_refit':False,'visual_review':'pending'}
(out/'figure_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'figures':3,'files':len(files),'font':font,'output':str(out),'all_source_hashes_unchanged':True}))
