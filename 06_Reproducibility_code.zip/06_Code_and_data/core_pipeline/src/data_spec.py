"""Frozen data specification and input-integrity helpers.

The cycle, variable, and optional-field definitions are copied from the audited
production preparation script. config/source_files.json records its SHA-256 and
that of the verbatim harmonization/derivation block used by prepare_data.py.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

CYCLES=[(2003,'C',2.0),(2005,'D',2.0),(2007,'E',2.0),(2009,'F',2.0),(2011,'G',2.0),(2013,'H',2.0),(2015,'I',2.0),(2017,'P',3.2)]
TOTAL_YEARS=17.2
FIELDS={
 'DEMO':['SEQN','RIDAGEYR','RIAGENDR','RIDRETH1','DMDEDUC2','INDFMPIR','RIDEXPRG','RIDSTATR','WTMEC2YR','WTMECPRP','SDMVSTRA','SDMVPSU'],
 'MCQ':['SEQN','MCQ220','MCQ230A','MCQ230B','MCQ230C','MCQ230D'],
 'FSQ':['SEQN','FSDHH','FSDAD'],
 'CBC':['SEQN','LBXHGB','LBXMCVSI'],
 'BMX':['SEQN','BMXBMI'],
 'SMQ':['SEQN','SMQ020','SMQ040','SMD070','SMD650','SMD641'],
 'BIOPRO':['SEQN','LBXSCR'],
 'DIQ':['SEQN','DIQ010'],
}
OPTIONAL={'WTMEC2YR','WTMECPRP','SMD070','SMD650','SMD641','MCQ230D'}


REGISTRY_PATH = Path(__file__).resolve().parents[1] / "config" / "source_files.json"


class IntegrityError(RuntimeError):
    """The supplied bytes or registry differ from the frozen study inputs."""


def load_source_registry() -> dict:
    registry = json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
    records = registry["files"]
    expected = {(year, table) for year, _, _ in CYCLES for table in FIELDS}
    actual = {(record["cycle_start"], record["table"]) for record in records}
    if len(records) != 64 or actual != expected or len({record["file"] for record in records}) != 64:
        raise IntegrityError("The source registry must contain the original 64 unique cycle-component files")
    for record in records:
        if Path(record["file"]).name != record["file"]:
            raise IntegrityError("Source filenames must not contain directory components")
        if not record["source_url"].startswith("https://wwwn.cdc.gov/"):
            raise IntegrityError("Only official CDC source URLs are permitted")
    return registry


def verify_file(path: Path, record: dict) -> None:
    if not path.is_file():
        raise FileNotFoundError(f"Missing input {record['file']}; run download_data.py first")
    if path.stat().st_size != record["bytes"]:
        raise IntegrityError(f"{record['file']}: size differs from frozen source; do not overwrite the registry to bypass this check")
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        header = handle.read(80)
        if not header.startswith(b"HEADER RECORD"):
            raise IntegrityError(f"{record['file']}: not an XPT transport file")
        digest.update(header)
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    if digest.hexdigest() != record["sha256"]:
        raise IntegrityError(f"{record['file']}: SHA-256 differs from frozen source; source drift or corruption requires investigation")
