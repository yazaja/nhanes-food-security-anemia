"""Validate, clean, harmonize, and merge the frozen NHANES source files.

Usage: python src/prepare_data.py --raw-dir work/raw --output-dir work/data
This step never accesses the network or searches an implicit cache. It preserves
all selected raw fields (including original age and creatinine), the production
column order, and the audited derivation rules. Audit tables are descriptive;
they neither impute nor delete observations.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

import numpy as np
import pandas as pd

from data_spec import CYCLES, FIELDS, OPTIONAL, TOTAL_YEARS, IntegrityError, load_source_registry, verify_file


def read_source(raw_dir: Path, record: dict) -> tuple:
    path = raw_dir / record["file"]
    verify_file(path, record)
    frame = pd.read_sas(path, format="xport")
    frame.columns = frame.columns.str.upper()
    # The transport reader may decode zero as an extremely small subnormal.
    # This is the original audited normalization; NA values are never filled.
    ncols = frame.select_dtypes(include="number").columns
    near = (frame[ncols].abs() < 1e-50) & frame[ncols].notna()
    nz = int(near.sum().sum())
    frame[ncols] = frame[ncols].mask(near, 0.0)
    if len(frame) != record["rows"]:
        raise IntegrityError(f"{record['file']}: decoded row count differs from source registry")
    if frame.SEQN.isna().any() or frame.SEQN.duplicated().any():
        raise IntegrityError(f"{record['file']}: SEQN must be nonmissing and unique")
    table = record["table"]
    missing = set(FIELDS[table]) - set(frame.columns)
    essential_missing = missing - OPTIONAL
    if essential_missing:
        raise IntegrityError(f"{record['file']}: missing required columns {sorted(essential_missing)}")
    if sorted(missing) != record["optional_columns_absent"]:
        raise IntegrityError(f"{record['file']}: optional column availability differs from the source registry")
    for column in missing:
        frame[column] = np.nan
    if table == "DEMO":
        weight_column = "WTMECPRP" if record["cycle_start"] == 2017 else "WTMEC2YR"
        if frame[weight_column].isna().all():
            raise IntegrityError(f"{record['file']}: missing cycle-specific MEC weight")
    log_record = {**record, "numeric_zeros_restored": nz, "input_hash_verified": True}
    print(json.dumps({"file": record["file"], "rows": len(frame), "input_hash_verified": True}), flush=True)
    return record["cycle_start"], table, frame[FIELDS[table]], log_record


def component_join_audit(parts: list) -> pd.DataFrame:
    """Report DEMO-left one-to-one joins, including absent component records."""
    rows = []
    for year, letter, _ in CYCLES:
        tables = {table: frame for y, table, frame, _ in parts if y == year}
        demo = tables["DEMO"]
        demo_keys = pd.Index(demo.SEQN)
        for table, frame in tables.items():
            keys = pd.Index(frame.SEQN)
            data_columns = [column for column in FIELDS[table] if column != "SEQN"]
            matched = frame.SEQN.isin(demo_keys)
            rows.append({
                "cycle": f"{year}-{year + 1}" if letter != "P" else "2017-March2020",
                "table": table,
                "demo_rows": len(demo),
                "component_rows": len(frame),
                "duplicate_component_seqn": int(frame.SEQN.duplicated().sum()),
                "missing_component_seqn": int(frame.SEQN.isna().sum()),
                "matched_demo_rows": int(demo_keys.isin(keys).sum()),
                "demo_rows_without_component": int((~demo_keys.isin(keys)).sum()),
                "component_rows_outside_demo": int((~keys.isin(demo_keys)).sum()),
                "matched_rows_all_selected_component_values_missing": int(frame.loc[matched, data_columns].isna().all(axis=1).sum()),
                "rows_after_demo_left_join": len(demo),
            })
    return pd.DataFrame(rows)


def derive_data(parts: list) -> pd.DataFrame:
    # BEGIN VERBATIM PRODUCTION HARMONIZATION / DERIVATION BLOCK (apart from indentation)
    frames=[]
    for year,letter,duration in CYCLES:
     subtables={t:df for y,t,df,_ in parts if y==year}
     df=subtables.pop('DEMO')
     for table,table_df in subtables.items():df=df.merge(table_df,on='SEQN',how='left',validate='one_to_one')
     df['cycle']=f'{year}-{year+1}' if letter!='P' else '2017-March2020'
     df['cycle_duration_years']=duration
     df['source_mec_weight']=df.WTMECPRP if letter=='P' else df.WTMEC2YR
     df['weight']=df.source_mec_weight*duration/TOTAL_YEARS
     df['original_age_years']=df.RIDAGEYR
     df['RIDAGEYR']=df.RIDAGEYR.clip(upper=80)
     df['creatinine_raw']=df.LBXSCR
     df['creatinine_calibration']='-0.016 + 0.978 * raw' if year==2005 else ('1.051 * raw - 0.06945 (Cobas to prior platform)' if year==2017 else 'no additional adjustment specified')
     if year==2005:df['LBXSCR']=-0.016+0.978*df.creatinine_raw
     # P_BIOPRO uses Cobas 6000 throughout. CDC recommends this backward bridge
     # when combining the new platform with earlier cycles; raw values stay intact.
     if year==2017:df['LBXSCR']=1.051*df.creatinine_raw-0.06945
     frames.append(df)
    d=pd.concat(frames,ignore_index=True)
    assert not d.SEQN.duplicated().any()
    assert len(set(d.cycle))==8 and '2017-2018' not in set(d.cycle)
    d['strata_id']=d.cycle+':'+d.SDMVSTRA.astype('Int64').astype(str)
    d['psu_id']=d.strata_id+':'+d.SDMVPSU.astype('Int64').astype(str)
    d['eligible_age']=(d.RIDAGEYR>=20).astype(int)
    d['cancer']=(d.MCQ220==1).astype(int)
    d['known_pregnant']=(d.RIDEXPRG==1).astype(int)
    d['food_insecure']=np.where(d.FSDHH.isin([1,2,3,4]),d.FSDHH.isin([3,4]).astype(int),np.nan)
    d['adult_food_insecure']=np.where(d.FSDAD.isin([1,2,3,4]),d.FSDAD.isin([3,4]).astype(int),np.nan)
    d['anemia']=np.where(d.LBXHGB.notna()&d.RIAGENDR.isin([1,2]),((d.LBXHGB<13)&d.RIAGENDR.eq(1))|((d.LBXHGB<12)&d.RIAGENDR.eq(2)),np.nan)
    d['age10']=d.RIDAGEYR/10
    d['female']=np.where(d.RIAGENDR.isin([1,2]),d.RIAGENDR.eq(2).astype(int),np.nan)
    d['race']=d.RIDRETH1.where(d.RIDRETH1.isin([1,2,3,4,5]))
    d['education']=np.select([d.DMDEDUC2.isin([1,2,3]),d.DMDEDUC2.eq(4),d.DMDEDUC2.eq(5)],[1.,2.,3.],default=np.nan)
    d['pir']=d.INDFMPIR
    d['smoking']=np.select([d.SMQ020.eq(2),d.SMQ020.eq(1)&d.SMQ040.eq(3),d.SMQ020.eq(1)&d.SMQ040.isin([1,2])],[0.,1.,2.],default=np.nan)
    d['bmi']=d.BMXBMI
    d['log_creatinine']=np.log(d.LBXSCR.where(d.LBXSCR>0))
    d['diabetes']=np.select([d.DIQ010.eq(1),d.DIQ010.isin([2,3])],[1.,0.],default=np.nan)
    ctype=d[['MCQ230A','MCQ230B','MCQ230C']]
    d['nmsc_only']=((ctype==32).any(axis=1)&ctype.apply(lambda x:x.isna()|(x==32)).all(axis=1)&d.MCQ230D.isna()).astype(int)
    d['eligible']=(d.eligible_age.eq(1)&d.cancer.eq(1)&d.known_pregnant.eq(0)&d.RIDSTATR.eq(2)&d.weight.gt(0)&d.food_insecure.notna()&d.anemia.notna()).astype(int)
    # Prespecified WHO2024 smoking-corrected Hb sensitivity; retain original main definition.
    q650=d.SMD650.where(d.SMD650.between(1,95))
    q070=d.SMD070.where(d.SMD070.between(1,95))
    d['cigarettes_quantity']=q650.combine_first(q070)
    d['cigarettes_quantity_source']=np.select([q650.notna(),q070.notna()],['SMD650','SMD070'],default='unknown')
    d['hb_smoking_deduction']=np.select([d.smoking.isin([0,1]),d.smoking.eq(2)&d.cigarettes_quantity.ge(20),d.smoking.eq(2)&d.cigarettes_quantity.between(10,19),d.smoking.eq(2)],[0.,.6,.5,.3],default=np.nan)
    d['hb_smoking_corrected_unrounded']=d.LBXHGB-d.hb_smoking_deduction
    d['hb_smoking_corrected']=np.round(d.hb_smoking_corrected_unrounded,1)
    d['anemia_smoking_corrected']=np.where(d.hb_smoking_corrected.notna()&d.RIAGENDR.isin([1,2]),((d.hb_smoking_corrected<13)&d.RIAGENDR.eq(1))|((d.hb_smoking_corrected<12)&d.RIAGENDR.eq(2)),np.nan)
    d['anemia_smoking_unrounded']=np.where(d.hb_smoking_corrected_unrounded.notna()&d.RIAGENDR.isin([1,2]),((d.hb_smoking_corrected_unrounded<13)&d.RIAGENDR.eq(1))|((d.hb_smoking_corrected_unrounded<12)&d.RIAGENDR.eq(2)),np.nan)
    d['smoking_rounding_changed']=((d.anemia_smoking_unrounded!=d.anemia_smoking_corrected)&d.anemia_smoking_unrounded.notna()&d.anemia_smoking_corrected.notna()).astype(int)
    # Preserve every raw dose field and the source used; SMD650 measures smoking-day dose.
    # END VERBATIM PRODUCTION HARMONIZATION / DERIVATION BLOCK
    return d


def variable_audits(data: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Report every output field for each cycle and cohort, without filtering it.

    Range flags apply only to mathematical bounds or fixed recode categories.
    They are not clinical plausibility exclusions. Unspecified raw-variable
    ranges are reported as observed minima/maxima with rule 'not specified'.
    """
    raw_names = {name for fields in FIELDS.values() for name in fields}
    binary = {"eligible_age", "cancer", "known_pregnant", "food_insecure", "adult_food_insecure", "anemia", "female", "diabetes", "nmsc_only", "eligible", "anemia_smoking_corrected", "anemia_smoking_unrounded", "smoking_rounding_changed"}
    categories = {name: {0, 1} for name in binary}
    categories.update({"race": {1, 2, 3, 4, 5}, "education": {1, 2, 3}, "smoking": {0, 1, 2}})
    bounds = {"RIDAGEYR": (0, 80), "age10": (0, 8), "weight": (0, None), "source_mec_weight": (0, None), "cigarettes_quantity": (1, 95), "cycle_duration_years": (2, 3.2)}
    missing_rows, range_rows = [], []
    scopes = [("all_interviewed", data), ("analysis_eligible", data.loc[data.eligible.eq(1)])]
    for cohort_name, cohort in scopes:
        groups = [("ALL", cohort)] + list(cohort.groupby("cycle", sort=True))
        for cycle, subset in groups:
            for column in subset.columns:
                values = subset[column]
                common = {"cohort": cohort_name, "cycle": cycle, "variable": column, "kind": "source_selected" if column in raw_names else "derived_or_provenance", "n_rows": len(values)}
                observed = values.dropna()
                missing_rows.append({**common, "n_missing": int(values.isna().sum()), "n_nonmissing": int(values.notna().sum()), "missing_fraction": float(values.isna().mean()) if len(values) else None})
                numeric = pd.api.types.is_numeric_dtype(values)
                minimum = float(observed.min()) if numeric and len(observed) else None
                maximum = float(observed.max()) if numeric and len(observed) else None
                invalid_n, rule = None, "not specified"
                if column in categories:
                    invalid_n = int((~observed.isin(categories[column])).sum())
                    rule = "nonmissing values in " + ",".join(str(value) for value in sorted(categories[column]))
                elif column in bounds:
                    low, high = bounds[column]
                    bad = observed.lt(low)
                    if high is not None:
                        bad = bad | observed.gt(high)
                    invalid_n = int(bad.sum())
                    rule = f"nonmissing values >= {low}" + (f" and <= {high}" if high is not None else "")
                range_rows.append({**common, "n_nonmissing": len(observed), "n_unique_nonmissing": int(observed.nunique()), "minimum": minimum, "maximum": maximum, "n_infinite": int(np.isinf(observed).sum()) if numeric else None, "range_rule": rule, "n_outside_rule": invalid_n})
    return pd.DataFrame(missing_rows), pd.DataFrame(range_rows)


def atomic_csv(frame: pd.DataFrame, destination: Path) -> None:
    temporary = destination.with_name("." + destination.name + ".tmp")
    try:
        frame.to_csv(temporary, index=False)
        os.replace(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--raw-dir", type=Path, required=True, help="Directory containing all frozen source XPT files")
    parser.add_argument("--output-dir", type=Path, required=True, help="Directory for merged data, preparation manifest, and audit tables")
    args = parser.parse_args()
    registry = load_source_registry()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    parts = [read_source(args.raw_dir, record) for record in registry["files"]]
    joins = component_join_audit(parts)
    data = derive_data(parts)
    missing, ranges = variable_audits(data)
    subset = data[data.eligible.eq(1)]
    manifest_keys = ["source", "target_cycles", "survey_years", "period", "weighting", "why_exclude_1999_2002", "why_exclude_2021_2023", "age", "creatinine", "definitions"]
    manifest = {key: registry[key] for key in manifest_keys}
    manifest["download_records"] = [part[3] for part in parts]
    manifest["checks"] = {
        "unique_SEQN": not data.SEQN.duplicated().any(),
        "no_JP_overlap_by_construction": True,
        "n_all_interviewed": len(data),
        "n_MEC": int(data.RIDSTATR.eq(2).sum()),
        "n_analysis": len(subset),
        "smoking_rounding_boundary_changed_analysis_n": int(subset.smoking_rounding_changed.sum()),
        "anemia_events": int(subset.anemia.sum()),
        "source_weight_positive_iff_MEC": bool((data.weight.gt(0) == data.RIDSTATR.eq(2)).all()),
        "all_64_input_hashes_verified": True,
    }
    manifest["by_cycle"] = subset.groupby("cycle").agg(n=("SEQN", "size"), events=("anemia", "sum"), insecure_n=("food_insecure", "sum")).reset_index().to_dict("records")
    manifest["original_preparation_source"] = registry["original_preparation_source"]
    manifest["audit_files"] = ["component_join_audit.csv", "variable_missingness_audit.csv", "variable_range_audit.csv"]
    atomic_csv(data, args.output_dir / "merged_expanded.csv")
    atomic_csv(joins, args.output_dir / "component_join_audit.csv")
    atomic_csv(missing, args.output_dir / "variable_missingness_audit.csv")
    atomic_csv(ranges, args.output_dir / "variable_range_audit.csv")
    temporary = args.output_dir / ".preparation_manifest.json.tmp"
    temporary.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    os.replace(temporary, args.output_dir / "preparation_manifest.json")
    print("DATA_PREPARATION_COMPLETE", json.dumps(manifest["checks"], sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
