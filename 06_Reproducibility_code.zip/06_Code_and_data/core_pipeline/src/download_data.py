"""Download the 64 frozen public NHANES source files; never silently accept drift.

Usage: python src/download_data.py --raw-dir work/raw
An existing cache is used only when --cache-dir is explicitly supplied. Every
existing, cached, and downloaded file is checked against config/source_files.json.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import json
import os
from pathlib import Path
import shutil
import tempfile
import time
from urllib.error import URLError
from urllib.request import Request, urlopen

from data_spec import IntegrityError, load_source_registry, verify_file


def atomic_copy(source: Path, destination: Path, record: dict) -> None:
    """Copy only verified bytes and publish the complete file atomically."""
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=destination.parent, prefix=".copy-", delete=False) as handle:
            temporary = Path(handle.name)
            with source.open("rb") as source_handle:
                shutil.copyfileobj(source_handle, handle)
        verify_file(temporary, record)
        os.replace(temporary, destination)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def fetch(record: dict, raw_dir: Path, cache_dir: Path | None, timeout: float, retries: int) -> dict:
    destination = raw_dir / record["file"]
    if destination.exists():
        verify_file(destination, record)
        return {**record, "acquisition": "verified_existing_raw"}

    # A cache is a convenience explicitly chosen by the operator, not a hidden
    # dependency. Both conventional extension capitalizations are supported.
    if cache_dir is not None:
        candidates = [cache_dir / record["file"], cache_dir / Path(record["file"]).with_suffix(".XPT")]
        for candidate in candidates:
            if candidate.exists():
                verify_file(candidate, record)
                atomic_copy(candidate, destination, record)
                return {**record, "acquisition": "verified_explicit_cache"}

    for attempt in range(retries):
        temporary = None
        try:
            request = Request(record["source_url"], headers={"User-Agent": "NHANES-Reproducibility/1.0"})
            with urlopen(request, timeout=timeout) as response:
                with tempfile.NamedTemporaryFile(dir=raw_dir, prefix=".download-", delete=False) as handle:
                    temporary = Path(handle.name)
                    size = 0
                    while chunk := response.read(1024 * 1024):
                        size += len(chunk)
                        if size > record["bytes"]:
                            raise IntegrityError(f"{record['file']}: response exceeds frozen file size; source may have changed")
                        handle.write(chunk)
            # Integrity mismatches fail immediately. Only transport failures are
            # retried; rerunning cannot silently update the frozen source hashes.
            verify_file(temporary, record)
            os.replace(temporary, destination)
            return {**record, "acquisition": "downloaded_from_official_source"}
        except (URLError, TimeoutError, ConnectionError):
            if attempt + 1 >= retries:
                raise
            time.sleep(min(2 ** attempt, 16))
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)
    raise RuntimeError("Unreachable download retry state")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--raw-dir", type=Path, required=True, help="Destination for the 64 source XPT files")
    parser.add_argument("--cache-dir", type=Path, help="Optional explicitly selected directory containing original XPT files")
    parser.add_argument("--timeout", type=float, default=120, help="Network connect/read timeout in seconds (default: 120)")
    parser.add_argument("--retries", type=int, default=4, help="Total transport attempts per file (default: 4)")
    parser.add_argument("--workers", type=int, default=4, help="Concurrent downloads (default: 4)")
    args = parser.parse_args()
    if args.timeout <= 0 or args.retries < 1 or args.workers < 1:
        parser.error("timeout must be positive; retries and workers must be at least one")
    if args.cache_dir is not None and not args.cache_dir.is_dir():
        parser.error("--cache-dir must name an existing directory")
    return args


def main() -> None:
    args = parse_args()
    registry = load_source_registry()
    args.raw_dir.mkdir(parents=True, exist_ok=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        records = list(pool.map(lambda record: fetch(record, args.raw_dir, args.cache_dir, args.timeout, args.retries), registry["files"]))
    # No private path, machine name, credential, or cache location is serialized.
    manifest = {
        "source": "CDC NHANES official public XPT",
        "all_input_hashes_verified": True,
        "n_files": len(records),
        "download_records": records,
    }
    temporary = args.raw_dir / ".download_manifest.json.tmp"
    temporary.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, args.raw_dir / "download_manifest.json")
    print(json.dumps({"status": "DOWNLOAD_COMPLETE", "verified_files": len(records)}, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
