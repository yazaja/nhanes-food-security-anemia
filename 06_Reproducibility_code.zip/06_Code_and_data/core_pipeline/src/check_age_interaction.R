# Diagnostic follow-up fixed after observing age nonlinearity in the expanded analysis.
# Not a prespecified confirmatory test. It adds no new subgroup or cutoff.
suppressPackageStartupMessages(library(survey));suppressPackageStartupMessages(library(jsonlite))
args<-commandArgs(trailingOnly=TRUE);out<-args[[1]]
models<-readRDS(file.path(out,'formal_models.rds'))
base<-models$sensitivity_nonlinear_age10
fit<-svyglm(update(formula(base),. ~ . + age65 + food_insecure:age65),design=base$survey.design,family=quasibinomial())
test<-regTermTest(fit,~food_insecure:age65,method='Wald')
contrasts<-list()
for(lev in 0:1) {
 L<-setNames(rep(0,length(coef(fit))),names(coef(fit)));L['food_insecure']<-1;L['food_insecure:age65']<-lev
 b<-sum(L*coef(fit));se<-sqrt(as.numeric(t(L)%*%vcov(fit)%*%L));crit<-qt(.975,fit$df.residual)
 contrasts[[as.character(lev)]]<-data.frame(age65=lev,OR=exp(b),CI_low=exp(b-crit*se),CI_high=exp(b+crit*se))
}
res<-list(history='Added after seeing expanded-sample age nonlinearity and linear-age interaction; reports both, no outcome-selected cutoff.',model='M2 plus 2 nonlinear natural-spline age components, age65 main term and food_insecure:age65',n=nrow(base$survey.design$variables),events=sum(base$survey.design$variables$anemia),F=as.numeric(test$Ftest),df=as.numeric(test$df),denominator_df=as.numeric(test$ddf),p_interaction=as.numeric(test$p),conditional_contrasts=do.call(rbind,contrasts),converged=fit$converged,rank=fit$rank,parameters=length(coef(fit)))
write_json(res,file.path(out,'age_interaction_nonlinearity_check.json'),pretty=TRUE,auto_unbox=TRUE,digits=12)
write.csv(summary(fit)$coefficients,file.path(out,'age_interaction_nonlinearity_coefficients.csv'))
write.csv(do.call(rbind,contrasts),file.path(out,'age_interaction_nonlinearity_contrasts.csv'),row.names=FALSE)
saveRDS(fit,file.path(out,'age_interaction_nonlinearity_model.rds'))
j<-fromJSON(file.path(out,'formal_results.json'),simplifyVector=FALSE);j$post_diagnostic_age_interaction_check<-res
write_json(j,file.path(out,'formal_results.json'),pretty=TRUE,auto_unbox=TRUE,na='null',digits=12)
print(res)
