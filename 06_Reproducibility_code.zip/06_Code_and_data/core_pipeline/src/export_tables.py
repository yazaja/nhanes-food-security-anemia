"""Render regenerated aggregate CSV tables as standalone HTML; no model fitting."""
from pathlib import Path
import argparse,csv,html,json,hashlib

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--results-dir',type=Path,required=True)
    p.add_argument('--output-dir',type=Path,required=True)
    args=p.parse_args();args.output_dir.mkdir(parents=True,exist_ok=True)
    css='body{font-family:Arial,sans-serif;margin:32px;color:#222}h1{font-size:20px}table{border-collapse:collapse;font-size:13px}th,td{padding:7px 10px;border-bottom:1px solid #ddd;text-align:left}thead{background:#f2f3f4}p{max-width:1100px;line-height:1.5}.numeric{font-variant-numeric:tabular-nums}'
    def read(name):
        with (args.results_dir/name).open(newline='',encoding='utf-8') as f:return list(csv.DictReader(f))
    def emit(name,title,headers,rows,note):
        body='<tr>'+''.join('<th>'+html.escape(x)+'</th>' for x in headers)+'</tr>'
        data=''.join('<tr>'+''.join('<td>'+html.escape(str(x))+'</td>' for x in row)+'</tr>' for row in rows)
        text=f'<!doctype html><html lang="en"><meta charset="utf-8"><title>{html.escape(title)}</title><style>{css}</style><h1>{html.escape(title)}</h1><table><thead>{body}</thead><tbody>{data}</tbody></table><p>{html.escape(note)}</p></html>'
        (args.output_dir/name).write_text(text,encoding='utf-8')
    rows=read('table1_display.csv')
    descriptive_n=json.loads((args.results_dir/'formal_results.json').read_text())['analysis_n']
    headers=['Characteristic','Overall','Food secure','Food insecure']
    emit('Table1.html','Table 1. Characteristics of adult cancer survivors',headers,
         [[r['label'],r['display.Overall'],r['display.Secure'],r['display.Insecure']] for r in rows],
         f'Continuous variables: survey-weighted mean (SD). Categorical variables: unweighted n (survey-weighted %). Available denominators and missing counts are retained in table1_long.csv. Descriptive sample: {descriptive_n:,} participants; regression samples are defined separately.')
    models=read('model_results.csv')
    table=[]
    for r in models:
        digits=3 if r['kind']!='OR' else 2
        table.append([r['model'],r['n'],r['anemia_events'],r['insecure_n'],r['insecure_events'],r['kind'],
                     f"{float(r['estimate']):.{digits}f}",f"{float(r['CI_low']):.{digits}f} to {float(r['CI_high']):.{digits}f}",f"{float(r['p']):.3g}"])
    emit('Table2.html','Table 2. Survey-weighted models and sensitivity analyses',
         ['Model','N','Anemia n','Exposed n','Exposed anemia n','Measure','Estimate','95% CI','P'],table,
         'M0–M2 use the same complete cases; M3 additionally requires BMI, calibrated creatinine and diabetes. Continuous hemoglobin is reported as a mean difference in g/dL; anemia-event counts in that row describe the sample and are not its modeled endpoint. Subgroup models and pooled interaction tests are distinct.')
    for source,title in [('complete_case_comparison_display.csv','Complete-case comparison'),('missingness.csv','Missingness'),('participant_flow.csv','Participant flow'),('interaction_tests.csv','Interaction tests'),('prevalence_binary.csv','Weighted anemia prevalence')]:
        data=read(source)
        if data:emit(source.replace('.csv','.html'),title,list(data[0]),[list(x.values()) for x in data],f'Generated from {source}; original precision CSV remains in results/.')
    records={x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in args.output_dir.glob('*.html')}
    (args.output_dir/'table_manifest.json').write_text(json.dumps({'tables':records,'purpose':'Readable views of regenerated aggregate tables; not a byte-identical reconstruction of the former Excel layout'},indent=2))
    print(f'Exported {len(records)} standalone HTML tables')

if __name__=='__main__':main()
