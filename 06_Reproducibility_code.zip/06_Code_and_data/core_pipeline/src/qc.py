"""Run the original 16 post-analysis QC checks in a user-selected workspace."""
from pathlib import Path
import argparse
import pandas as pd,numpy as np,json,hashlib
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--data-dir',required=True)
parser.add_argument('--results-dir',required=True)
args=parser.parse_args()
data_dir=Path(args.data_dir);results_dir=Path(args.results_dir)
d=pd.read_csv(data_dir/'merged_expanded.csv');j=json.loads((results_dir/'formal_results.json').read_text());r=pd.read_csv(results_dir/'model_results.csv');m=pd.read_csv(results_dir/'missingness.csv');flow=pd.read_csv(results_dir/'participant_flow.csv')
a=d[d.eligible.eq(1)].copy();current=a[a.smoking.eq(2)]
checks={
 'unique_ids':not d.SEQN.duplicated().any(),
 'eight_nonoverlapping_release_blocks':d.cycle.nunique()==8 and '2017-2018' not in set(d.cycle),
 'all_mec_weights_match_status':bool((d.weight.gt(0)==d.RIDSTATR.eq(2)).all()),
 'weights_match_duration_formula':bool(np.allclose(d.weight,d.source_mec_weight*d.cycle_duration_years/17.2,equal_nan=True)),
 'age_harmonized_at_80':bool((d.RIDAGEYR<=80).all()),
 'creatinine_2005_formula':bool(np.allclose(d.loc[d.cycle.eq('2005-2006'),'LBXSCR'],-.016+.978*d.loc[d.cycle.eq('2005-2006'),'creatinine_raw'],equal_nan=True)),
 'creatinine_P_platform_bridge':bool(np.allclose(d.loc[d.cycle.eq('2017-March2020'),'LBXSCR'],1.051*d.loc[d.cycle.eq('2017-March2020'),'creatinine_raw']-.06945,equal_nan=True)),
 'core_N_consistent':len(a)==j['analysis_n']==int(flow.iloc[-2]['n']),
 'main_n_consistent':j['m2_n']==int(flow.iloc[-1]['n'])==int(r[r.model.eq('M2_socioeconomic')].iloc[0]['n']),
 'all_model_converged':all(x['converged'] for x in j['diagnostics'].values()),
 'all_models_full_rank':all(not x['rank_deficient'] for x in j['diagnostics'].values()),
 'all_coefficients_finite':all(x['all_coefficients_finite'] and x['all_SE_finite'] for x in j['diagnostics'].values()),
 'all_residual_df_positive':all(x['residual_df']>0 for x in j['diagnostics'].values()),
 'anemia_corrected_never_below_uncorrected':bool((a.loc[a.anemia_smoking_corrected.notna(),'anemia_smoking_corrected']>=a.loc[a.anemia_smoking_corrected.notna(),'anemia']).all()),
 'anemia_corrected_matches_rounded_measurement':bool(((d.anemia_smoking_corrected == (((d.hb_smoking_corrected<13)&d.RIAGENDR.eq(1))|((d.hb_smoking_corrected<12)&d.RIAGENDR.eq(2)))) | d.anemia_smoking_corrected.isna()).all()),
 'source_manifest_64files':len(j['metadata']['download_records'])==64,
}
summary={'checks':checks,'all_passed':all(checks.values()),'main_missing_fields':m[['variable','missing_n','missing_weighted_percent']].to_dict('records'),'current_smokers_n':len(current),'current_smoking_unknown_quantity_n':int(current.cigarettes_quantity.isna().sum()),'current_smoking_exactly_20_n':int(current.cigarettes_quantity.eq(20).sum()),'current_quantity_sources':current.cigarettes_quantity_source.value_counts(dropna=False).to_dict(),'rounding_boundary_changed_n':int(a.smoking_rounding_changed.sum()),'figures':[x.name for x in results_dir.glob('*.png')],'data_sha256':hashlib.sha256((data_dir/'merged_expanded.csv').read_bytes()).hexdigest()}
(results_dir/'quality_checks.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False,default=lambda x: bool(x) if isinstance(x,np.bool_) else int(x) if isinstance(x,np.integer) else x));print(json.dumps(summary,indent=2))
assert summary['all_passed']
