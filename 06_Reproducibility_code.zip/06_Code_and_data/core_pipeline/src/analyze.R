# Parameterized formal basic analysis. Execute only on the analysis workstation.
suppressPackageStartupMessages(library(survey))
suppressPackageStartupMessages(library(jsonlite))
suppressPackageStartupMessages(library(splines))
args <- commandArgs(trailingOnly=TRUE)
if(length(args)<2) stop('Usage: Rscript formal_analysis.R INPUT_CSV OUTPUT_DIR [META_JSON]')
infile<-args[[1]]; out<-args[[2]];dir.create(out,recursive=TRUE,showWarnings=FALSE)
meta<-if(length(args)>=3) fromJSON(args[[3]],simplifyVector=FALSE) else list(scope='Awaiting externally verified cycle and weight specification')
d<-read.csv(infile,stringsAsFactors=FALSE)
# Respect the CBC 0.1 g/dL measurement precision before classifying corrected Hb.
old_smoking_anemia<-d$anemia_smoking_corrected
d$hb_smoking_corrected<-round(d$LBXHGB-d$hb_smoking_deduction,1)
d$anemia_smoking_corrected<-ifelse(is.na(d$hb_smoking_corrected),NA_real_,ifelse(d$RIAGENDR==1,d$hb_smoking_corrected<13,d$hb_smoking_corrected<12))
smoking_rounding_changed_on_R_load<-sum(old_smoking_anemia!=d$anemia_smoking_corrected,na.rm=TRUE)
required<-c('SEQN','RIDAGEYR','RIAGENDR','RIDSTATR','weight','cycle','strata_id','psu_id','cancer','known_pregnant','food_insecure','adult_food_insecure','anemia','age10','female','race','education','pir','smoking','bmi','log_creatinine','diabetes','LBXHGB','LBXSCR','nmsc_only','FSDHH')
stopifnot(all(required %in% names(d)), !anyDuplicated(d$SEQN))
options(survey.lonely.psu='fail')
d$cycle<-factor(d$cycle);d$race<-relevel(factor(d$race,levels=1:5),ref='3');d$education<-factor(d$education,levels=1:3);d$smoking<-factor(d$smoking,levels=0:2)
d$age65<-as.integer(d$RIDAGEYR>=65)
d$eligible<-as.integer(d$RIDAGEYR>=20 & d$cancer==1 & d$known_pregnant==0 & d$RIDSTATR==2 & d$weight>0 & !is.na(d$food_insecure) & !is.na(d$anemia))
d$eligible[is.na(d$eligible)]<-0
v2<-c('anemia','food_insecure','cycle','age10','female','race','education','pir','smoking')
v3<-c(v2,'bmi','log_creatinine','diabetes')
d$complete2<-as.integer(complete.cases(d[,v2]));d$complete3<-as.integer(complete.cases(d[,v3]))
# Construct the nonlinear component of a 3-df natural spline. Residualization removes
# the intercept and linear span, leaving exactly two nonlinear df. No outcome is used.
nonlinear_specs<-list()
for(v in c('age10','pir')) {
 xx<-d[[v]];use<-d$eligible==1 & d$complete2==1
 sb<-ns(xx[use],df=3); lin<-cbind(1,xx[use]);coef_resid<-qr.solve(lin,sb)
 resid_basis<-sb-lin%*%coef_resid;q<-qr(resid_basis,tol=1e-8);stopifnot(q$rank==2)
 columns<-q$pivot[1:2];ok<-is.finite(xx)
 fullbasis<-ns(xx[ok],knots=attr(sb,'knots'),Boundary.knots=attr(sb,'Boundary.knots'))-cbind(1,xx[ok])%*%coef_resid
 for(j in 1:2) {name<-paste0(v,'_NL',j);d[[name]]<-NA_real_;d[[name]][ok]<-fullbasis[,columns[j]]}
 nonlinear_specs[[v]]<-list(knots=attr(sb,'knots'),boundary_knots=attr(sb,'Boundary.knots'),residualization=unname(coef_resid),retained_columns=columns)
}
mec<-subset(d,RIDSTATR==2 & weight>0 & !is.na(strata_id) & !is.na(psu_id))
des<-svydesign(ids=~psu_id,strata=~strata_id,weights=~weight,nest=TRUE,data=mec)
a<-subset(des,eligible==1);a2<-subset(des,eligible==1 & complete2==1);a3<-subset(des,eligible==1 & complete3==1)
stopifnot(nrow(a2$variables)>0,degf(des)>0)
forms<-list(M0_cycle=anemia~food_insecure+cycle,
 M1_demographic=anemia~food_insecure+cycle+age10+female+race,
 M2_socioeconomic=anemia~food_insecure+cycle+age10+female+race+education+pir+smoking,
 M3_additional_health=anemia~food_insecure+cycle+age10+female+race+education+pir+smoking+bmi+log_creatinine+diabetes)
fits<-list();rows<-list();coefrows<-list();errors<-list()
extract<-function(fit,name,design,term='food_insecure',kind='OR',eventvar='anemia') {
 b<-unname(coef(fit)[term]);se<-unname(sqrt(diag(vcov(fit)))[term]);df<-fit$df.residual
 crit<-qt(.975,df);low<-b-crit*se;high<-b+crit*se
 stopifnot(length(b)==1,is.finite(b),is.finite(se),df>0)
 data.frame(model=name,term=term,kind=kind,n=nrow(design$variables),event_definition=eventvar,anemia_events=sum(design$variables[[eventvar]]),insecure_n=sum(design$variables[[term]]==1),insecure_events=sum(design$variables[[eventvar]][design$variables[[term]]==1]),coefficient=b,SE=se,estimate=if(kind=='OR') exp(b) else b,CI_low=if(kind=='OR') exp(low) else low,CI_high=if(kind=='OR') exp(high) else high,p=2*pt(abs(b/se),df,lower.tail=FALSE),design_df=degf(design),residual_df=df,parameters=length(coef(fit)),converged=fit$converged)
}
record<-function(name,formula,design,term='food_insecure',family=quasibinomial(),kind='OR',eventvar='anemia') {
 fit<-svyglm(formula,design=design,family=family)
 fits[[name]]<<-fit;rows[[name]]<<-extract(fit,name,design,term,kind,eventvar)
 cc<-summary(fit)$coefficients;coefrows[[name]]<<-data.frame(model=name,term=rownames(cc),cc,row.names=NULL,check.names=FALSE)
 invisible(fit)
}
for(name in names(forms)) record(name,forms[[name]],if(name=='M3_additional_health') a3 else a2)
record('sensitivity_adult_definition',anemia~adult_food_insecure+cycle+age10+female+race+education+pir+smoking,subset(des,eligible==1 & complete2==1 & !is.na(adult_food_insecure)),term='adult_food_insecure')
record('sensitivity_exclude_nmsc_only',forms$M2_socioeconomic,subset(des,eligible==1 & complete2==1 & nmsc_only==0))
record('sensitivity_smoking_corrected_hb',anemia_smoking_corrected~food_insecure+cycle+age10+female+race+education+pir+smoking,subset(des,eligible==1 & complete2==1 & !is.na(anemia_smoking_corrected)),eventvar='anemia_smoking_corrected')
nonlinearity<-list()
for(v in c('age10','pir')) {
 name<-paste0('sensitivity_nonlinear_',v)
 f<-update(forms$M2_socioeconomic,paste0('.~.+',v,'_NL1+',v,'_NL2'))
 fit<-record(name,f,a2)
 test<-regTermTest(fit,as.formula(paste0('~',v,'_NL1+',v,'_NL2')),method='Wald')
 nonlinearity[[v]]<-data.frame(variable=v,F=as.numeric(test$Ftest),df=as.numeric(test$df),denominator_df=as.numeric(test$ddf),p=as.numeric(test$p))
}
record('secondary_continuous_hb',LBXHGB~food_insecure+cycle+age10+female+race+education+pir+smoking,a2,family=gaussian(),kind='Hb_difference_g_dL')
interaction_rows<-list();interaction_contrasts<-list()
for(v in c('female','age65')) {
 f<-if(v=='female') update(forms$M2_socioeconomic,.~.+food_insecure:female) else update(forms$M2_socioeconomic,.~.+age65+food_insecure:age65)
 fit<-svyglm(f,design=a2,family=quasibinomial());fits[[paste0('interaction_',v)]]<-fit
 cc<-summary(fit)$coefficients;coefrows[[paste0('interaction_',v)]]<-data.frame(model=paste0('interaction_',v),term=rownames(cc),cc,row.names=NULL,check.names=FALSE)
 # Contrasts from the same interaction model accompany fully stratified fits.
 # They answer different adjustment assumptions and must not be mixed silently.
 for(lev in 0:1) {
  contrast<-setNames(rep(0,length(coef(fit))),names(coef(fit)));contrast['food_insecure']<-1
  contrast[paste0('food_insecure:',v)]<-lev
  bb<-sum(contrast*coef(fit));ss<-sqrt(as.numeric(t(contrast)%*%vcov(fit)%*%contrast));crit<-qt(.975,fit$df.residual)
  interaction_contrasts[[paste(v,lev)]]<-data.frame(modifier=v,level=lev,OR=exp(bb),CI_low=exp(bb-crit*ss),CI_high=exp(bb+crit*ss),model='pooled interaction with common nuisance coefficients')
 }
 test<-regTermTest(fit,as.formula(paste0('~food_insecure:',v)),method='Wald')
 interaction_rows[[v]]<-data.frame(modifier=v,n=nrow(a2$variables),events=sum(a2$variables$anemia),F=as.numeric(test$Ftest),df=as.numeric(test$df),denominator_df=as.numeric(test$ddf),p_interaction=as.numeric(test$p))
 for(level in 0:1) {
  sg<-a2[a2$variables[[v]]==level,]
  sgf<-if(v=='female') update(forms$M2_socioeconomic,.~.-female) else forms$M2_socioeconomic
  name<-paste0('subgroup_',v,'_',level)
  tryCatch(record(name,sgf,sg),error=function(e) errors[[name]]<<-list(n=nrow(sg$variables),events=sum(sg$variables$anemia),message=conditionMessage(e)))
 }
}
results<-do.call(rbind,rows);rownames(results)<-NULL
write.csv(results,file.path(out,'model_results.csv'),row.names=FALSE)
write.csv(do.call(rbind,coefrows),file.path(out,'all_coefficients.csv'),row.names=FALSE)
write.csv(do.call(rbind,interaction_rows),file.path(out,'interaction_tests.csv'),row.names=FALSE)
write.csv(do.call(rbind,interaction_contrasts),file.path(out,'interaction_model_contrasts.csv'),row.names=FALSE)
write.csv(do.call(rbind,nonlinearity),file.path(out,'nonlinearity_tests.csv'),row.names=FALSE)
# Weighted Table 1 with available-case denominators. No baseline p-value screening.
continuous<-c(RIDAGEYR='Age, years',pir='Family income-to-poverty ratio',bmi='BMI, kg/m2',LBXSCR='Creatinine, mg/dL',LBXHGB='Hemoglobin, g/dL')
categories<-list(female=c('0'='Male','1'='Female'),age65=c('0'='Age <65','1'='Age >=65'),race=c('1'='Mexican American','2'='Other Hispanic','3'='Non-Hispanic White','4'='Non-Hispanic Black','5'='Other race including multiracial'),education=c('1'='High school or less','2'='Some college/associate degree','3'='College graduate or above'),smoking=c('0'='Never','1'='Former','2'='Current'),diabetes=c('0'='No/borderline','1'='Yes'),anemia=c('0'='No anemia','1'='Anemia'),cycle=setNames(levels(d$cycle),levels(d$cycle)))
make_table<-function(designs) {
 outrows<-list();k<-0
 for(g in names(designs)) {
  ad<-designs[[g]];n<-nrow(ad$variables)
  for(v in names(continuous)) {
   xx<-ad$variables[[v]];n_avail<-sum(!is.na(xx));if(n_avail<2) next
   mu<-svymean(as.formula(paste0('~',v)),ad,na.rm=TRUE);va<-svyvar(as.formula(paste0('~',v)),ad,na.rm=TRUE)
   k<-k+1;outrows[[k]]<-data.frame(group=g,variable=v,level='',label=continuous[[v]],type='continuous',n_total=n,n_available=n_avail,n_missing=n-n_avail,n_level=NA_integer_,weighted_estimate=as.numeric(coef(mu)),SE=as.numeric(SE(mu)),weighted_SD=sqrt(as.numeric(va)),display=sprintf('%.2f (%.2f)',as.numeric(coef(mu)),sqrt(as.numeric(va))))
  }
  for(v in names(categories)) for(lev in names(categories[[v]])) {
   xx<-as.character(ad$variables[[v]]);ad$variables$.table_indicator<-ifelse(is.na(xx),NA_real_,as.numeric(xx==lev));n_avail<-sum(!is.na(xx))
   if(n_avail==0) next
   mu<-svymean(~.table_indicator,ad,na.rm=TRUE);nn<-sum(xx==lev,na.rm=TRUE)
   k<-k+1;outrows[[k]]<-data.frame(group=g,variable=v,level=lev,label=categories[[v]][[lev]],type='categorical',n_total=n,n_available=n_avail,n_missing=n-n_avail,n_level=nn,weighted_estimate=as.numeric(coef(mu)),SE=as.numeric(SE(mu)),weighted_SD=NA_real_,display=sprintf('%d (%.1f%%)',nn,100*as.numeric(coef(mu))))
  }
 }
 do.call(rbind,outrows)
}
tab1<-make_table(list(Overall=a,Secure=subset(a,food_insecure==0),Insecure=subset(a,food_insecure==1)))
write.csv(tab1,file.path(out,'table1_long.csv'),row.names=FALSE)
wide<-reshape(tab1[,c('group','variable','level','label','type','display')],idvar=c('variable','level','label','type'),timevar='group',direction='wide')
write.csv(wide,file.path(out,'table1_display.csv'),row.names=FALSE)
# Complete-case comparison: retain the same weighted descriptive convention and denominators.
cc_tab<-make_table(list(Complete_M2=subset(a,complete2==1),Incomplete_M2=subset(a,complete2==0)))
# Add exposure to complete-case comparison without changing Table 1 definitions.
for(g in c('Complete_M2','Incomplete_M2')) {
 ad<-if(g=='Complete_M2') subset(a,complete2==1) else subset(a,complete2==0)
 mu<-svymean(~food_insecure,ad);nn<-sum(ad$variables$food_insecure)
 cc_tab<-rbind(cc_tab,data.frame(group=g,variable='food_insecure',level='1',label='Household food insecurity',type='categorical',n_total=nrow(ad$variables),n_available=nrow(ad$variables),n_missing=0,n_level=nn,weighted_estimate=as.numeric(coef(mu)),SE=as.numeric(SE(mu)),weighted_SD=NA_real_,display=sprintf('%d (%.1f%%)',nn,100*as.numeric(coef(mu)))))
}
write.csv(cc_tab,file.path(out,'complete_case_comparison_long.csv'),row.names=FALSE)
cc_wide<-reshape(cc_tab[,c('group','variable','level','label','type','display')],idvar=c('variable','level','label','type'),timevar='group',direction='wide')
write.csv(cc_wide,file.path(out,'complete_case_comparison_display.csv'),row.names=FALSE)
miss<-list()
for(v in unique(c(v2,v3,'adult_food_insecure'))) {
 ad<-a;ad$variables$.miss<-as.numeric(is.na(ad$variables[[v]]));mu<-svymean(~.miss,ad)
 miss[[v]]<-data.frame(variable=v,n_total=nrow(ad$variables),missing_n=sum(ad$variables$.miss),missing_unweighted_percent=100*mean(ad$variables$.miss),missing_weighted_percent=100*as.numeric(coef(mu)),SE_weighted_percent=100*as.numeric(SE(mu)))
}
miss<-do.call(rbind,miss);rownames(miss)<-NULL;write.csv(miss,file.path(out,'missingness.csv'),row.names=FALSE)
# Exposure-specific weighted anemia prevalence for main text, with logit CI.
prev<-list()
for(lev in 0:1) {
 ad<-subset(a,food_insecure==lev);pr<-svyciprop(~anemia,ad,method='logit',df=degf(ad));ci<-confint(pr)
 prev[[as.character(lev)]]<-data.frame(food_insecure=lev,n=nrow(ad$variables),events=sum(ad$variables$anemia),prevalence=as.numeric(coef(pr)),CI_low=ci[1],CI_high=ci[2])
}
prev<-do.call(rbind,prev);rownames(prev)<-NULL;write.csv(prev,file.path(out,'prevalence_binary.csv'),row.names=FALSE)
overall_pr<-svyciprop(~anemia,a,method='logit',df=degf(a));overall_ci<-confint(overall_pr)
overall_prev<-data.frame(group='Overall',n=nrow(a$variables),events=sum(a$variables$anemia),prevalence=as.numeric(coef(overall_pr)),CI_low=overall_ci[1],CI_high=overall_ci[2])
write.csv(overall_prev,file.path(out,'prevalence_overall.csv'),row.names=FALSE)
# Sequential flow and combined core-variable missingness, avoiding double counted exclusions.
condition<-rep(TRUE,nrow(d));flow<-list();addflow<-function(label,cond) {before<-sum(condition);condition<<-condition&cond;condition[is.na(condition)]<<-FALSE;flow[[length(flow)+1]]<<-data.frame(step=label,n=sum(condition),excluded=before-sum(condition))}
addflow('All interviewed participants',rep(TRUE,nrow(d)))
addflow('Adults aged 20 years or older',d$RIDAGEYR>=20)
addflow('Ever told cancer or malignancy',d$cancer==1)
addflow('Exclude known pregnancy',d$known_pregnant==0)
addflow('MEC examined with positive analysis weight',d$RIDSTATR==2 & d$weight>0)
addflow('Hemoglobin and household food security available',!is.na(d$LBXHGB)&!is.na(d$food_insecure))
addflow('M2 complete-case primary model',d$complete2==1)
flow<-do.call(rbind,flow);write.csv(flow,file.path(out,'participant_flow.csv'),row.names=FALSE)
stopifnot(tail(flow$n,1)==nrow(a2$variables))
diag<-lapply(fits,function(f) {co<-coef(f);se<-sqrt(diag(vcov(f)));list(converged=f$converged,rank=f$rank,parameters=length(co),rank_deficient=f$rank<length(co),all_coefficients_finite=all(is.finite(co)),all_SE_finite=all(is.finite(se)),max_abs_coefficient=max(abs(co),na.rm=TRUE),max_SE=max(se,na.rm=TRUE),fitted_range=range(fitted(f)),design_df=degf(f$survey.design),residual_df=f$df.residual)})
summary<-list(status='executed_basic_formal_analyses',date=as.character(Sys.Date()),metadata=meta,smoking_rounding_changed_on_R_load=smoking_rounding_changed_on_R_load,cycles=levels(d$cycle),analysis_n=nrow(a$variables),anemia_events=sum(a$variables$anemia),m2_n=nrow(a2$variables),m2_events=sum(a2$variables$anemia),m3_n=nrow(a3$variables),m3_events=sum(a3$variables$anemia),MEC_n=nrow(mec),MEC_strata=length(unique(mec$strata_id)),MEC_PSU=length(unique(mec$psu_id)),design_df=degf(des),models=results,interaction_tests=do.call(rbind,interaction_rows),interaction_model_contrasts=do.call(rbind,interaction_contrasts),nonlinearity_tests=do.call(rbind,nonlinearity),nonlinear_basis_specification=nonlinear_specs,prevalence_binary=prev,prevalence_overall=overall_prev,flow=flow,missingness=miss,diagnostics=diag,errors=errors,table_convention='Continuous: weighted mean (SD); categorical: unweighted n (weighted %); estimates use available cases, with denominators/missingness in long table. No baseline significance screening.',analysis_history='These supplemental analyses were fixed after viewing the 2011-2018 pilot; not a preregistered confirmatory analysis.',versions=list(R=R.version.string,survey=as.character(packageVersion('survey'))))
write_json(summary,file.path(out,'formal_results.json'),pretty=TRUE,auto_unbox=TRUE,na='null',digits=12)
saveRDS(fits,file.path(out,'formal_models.rds'))
sink(file.path(out,'R_sessionInfo.txt'));sessionInfo();sink()
# Basic manuscript figures. Detailed design/caption information lives in the report.
forest<-function(rr,labels,path,title) {
 png(path,width=1650,height=max(700,120*nrow(rr)+260),res=150);par(mar=c(5,17,4,3));y<-rev(seq_len(nrow(rr)));lim<-range(c(.9,rr$CI_low,rr$CI_high))
 plot(rr$estimate,y,log='x',pch=19,col='#2f6582',xlim=lim,ylim=c(.4,nrow(rr)+.6),yaxt='n',ylab='',xlab='Odds ratio (95% CI)',main=title)
 segments(rr$CI_low,y,rr$CI_high,y,col='#2f6582');abline(v=1,lty=2,col='gray50');axis(2,at=y,labels=labels,las=1,cex.axis=.85);dev.off()
}
rr<-results[results$model %in% names(forms),];forest(rr,c('M0: survey cycle','M1: demographics','M2: socioeconomic (primary)','M3: additional health'),file.path(out,'figure2_main_models.png'),'Household food insecurity and anemia')
rr<-results[grepl('^subgroup_',results$model),];labs<-c(subgroup_female_0='Male',subgroup_female_1='Female',subgroup_age65_0='Age <65 years',subgroup_age65_1='Age >=65 years')
forest(rr,paste0(labs[rr$model],' (events/N: ',rr$anemia_events,'/',rr$n,')'),file.path(out,'figure3_subgroups.png'),'Prespecified limited subgroup analyses')
png(file.path(out,'figure1_participant_flow.png'),width=1450,height=1500,res=150);par(mar=c(1,1,3,1));plot.new();plot.window(xlim=c(0,1),ylim=c(0,1));title('Participant selection')
yseq<-seq(.92,.08,length.out=nrow(flow))
for(i in seq_len(nrow(flow))) {y<-yseq[i];rect(.1,y-.045,.9,y+.045,col=if(i==nrow(flow)) '#d4e9ef' else '#f0f3f5',border='#486372');text(.5,y,paste0(flow$step[i],'\nn = ',format(flow$n[i],big.mark=',')),cex=.95);if(i<nrow(flow)) arrows(.5,y-.046,.5,yseq[i+1]+.046,length=.07);if(i>1)text(.9,(yseq[i-1]+y)/2,paste0('Excluded: ',format(flow$excluded[i],big.mark=',')),pos=2,cex=.75,col='#555555')}
dev.off()
cat('FORMAL_ANALYSIS_COMPLETE\n');print(results);print(do.call(rbind,interaction_rows));print(do.call(rbind,nonlinearity));print(flow)
